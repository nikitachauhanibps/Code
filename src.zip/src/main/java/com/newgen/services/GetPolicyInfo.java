package com.newgen.services;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.newgen.omni.jts.cmgr.XMLParser;
import com.newgen.util.*;

/**
 * 
 * @author prakhar.saxena
 *
 */
public class GetPolicyInfo {
	
	public static Properties propertiesFileData;
	static Logger logger = Logger.getLogger(CommonFunctions.class.getName()); 
	
	public String getPolicyInfo(String policyNo) throws FileNotFoundException, IOException {
		String query, inputXML, outputXML, response = "", cabinetName="";
		XMLParser xml = new XMLParser();
		propertiesFileData = new Properties();
		Properties props = new Properties();
		String configPath = System.getProperty("user.dir") + File.separator + "CreateWorkitemService\\log4j.properties";
		String sessionID="";
		try {

			props.load(new FileInputStream(configPath));
			PropertyConfigurator.configure(props);

			configPath = System.getProperty("user.dir") + File.separator + "CreateWorkitemService\\config.properties";
			FileReader reader = new FileReader(configPath);

			logger.info("configPath: " + configPath);

			propertiesFileData = new Properties();
			propertiesFileData.load(reader);
			
			cabinetName = propertiesFileData.getProperty("cabinetName");
			String ipAddress = propertiesFileData.getProperty("ipAddress");
			String username = propertiesFileData.getProperty("username");
			String password = propertiesFileData.getProperty("password");
			logger.info("cabinetName: policyInfo " + cabinetName);

			query = "EXEC NG_SP_NB_CREATE_JSON '" + policyNo + "'";
			
			//getting sessionID
//	    	inputXML = XMLGen.get_WMConnect_Input(cabinetName,username,password,"N");
//	        logger.info("get_WMConnect_Input_inputXML: "+inputXML);      
//	        outputXML = callRestAPI_JTS(inputXML);
//	        String sessionID = outputXML.substring(outputXML.indexOf("<SessionId>")+11,outputXML.indexOf("</SessionId>"));
//	        logger.info("get_WMConnect_Input_outputXML: "+outputXML);
			
			sessionID = CommonFunctions.getSessionID();
	        
			inputXML = XMLGen.APSelectWithColumnNames(cabinetName, query,sessionID);
			logger.info("inputXML: policyInfo " + inputXML);
			outputXML = CommonFunctions.callRestAPI_JTS(inputXML);
			logger.info("outputXML: policyInfo " + outputXML);
			xml.setInputXML(outputXML);

			response = xml.getValueOf("SUCCESS").trim();

			if (response.equalsIgnoreCase("SUCCESS")) {
				query = "SELECT PolicyAgentCustomerInfo,PersonalInformation,ProductandPaymentInformation,MedicalAndPreviousPolicyinformation FROM NG_NB_JSON_CALLBACK(NOLOCK) WHERE POLICY_NO='" + policyNo
						+ "'";
				//getting sessionID
//		    	inputXML = XMLGen.get_WMConnect_Input(cabinetName,username,password,"N");
//		        logger.info("get_WMConnect_Input_inputXML: "+inputXML);      
//		        outputXML = callRestAPI_JTS(inputXML);
//		        sessionID = outputXML.substring(outputXML.indexOf("<SessionId>")+11,outputXML.indexOf("</SessionId>"));
//		        logger.info("get_WMConnect_Input_outputXML: "+outputXML);
		        
				inputXML = XMLGen.APSelectWithColumnNames(cabinetName, query,sessionID);
				logger.info("inputXML: policyInfo " + inputXML);
				outputXML = CommonFunctions.callRestAPI_JTS(inputXML);
				logger.info("outputXML: policyInfo " + outputXML);
				xml.setInputXML(outputXML);
				response = xml.getValueOf("PolicyAgentCustomerInfo")+xml.getValueOf("PersonalInformation")+xml.getValueOf("ProductandPaymentInformation")+xml.getValueOf("MedicalAndPreviousPolicyinformation");
			}

		} catch (Exception e) {
			System.out.println(e);
		}
		
		//disconnecting user
        logger.info("Disconnecting User...");
		 	String ipXML = XMLGen.get_WMDisConnect_Input(cabinetName,sessionID);
        logger.info("ipXMLDisconnect_inputXML: "+ipXML);
        //String outputXML = WFCallBroker.execute(inputXML, "192.168.54.97", 3333, 1);
        String opXML = CommonFunctions.callRestAPI_JTS(ipXML);
        logger.info("ipXMLDisconnect_outputXML: "+opXML);     
		
		return response;
	}		
}
