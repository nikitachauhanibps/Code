package com.newgen.services;

import java.util.HashMap;

import Jdts.Parser.XMLParser;

public class TestClass {
	
	public static void main(String[] args) {
		String xmlString="<note><to>Tove</to><from>Jani</from><heading>Reminder</heading><body>Don't forget me this weekend!</body></note>";
		XMLParser xml = new XMLParser(xmlString);
		String from = xml.getFirstValueOf("from");
		System.out.println(from);
		
		HashMap hm = new HashMap();
		
		hm.put("from", "jani");
		
		System.out.println(getXMLTag("from","jani"));
		System.out.println(getXMLTag("value",2));
		
		System.out.println(getXMLTag("from",2));
		
	}
	
	
	
	private static <E> String getXMLTag(String key,E value)  {
		String xml="";
		xml = "<"+key+">"+value+"</"+key+">";
		return xml;
	}

}
