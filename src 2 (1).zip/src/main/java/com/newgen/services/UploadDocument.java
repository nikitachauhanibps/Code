package com.newgen.services;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.json.JSONException;
import org.json.XML;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.newgen.util.*;

/**
 * 
 * @author prakhar.saxena
 *
 */
public class UploadDocument {

	public static Properties propertiesFileData;
	static Logger logger = Logger.getLogger(CommonFunctions.class.getName());

	public String addDocument(InputStream incomingData) throws FileNotFoundException, IOException {
		propertiesFileData = new Properties();
		Properties props = new Properties();

		String configPath = System.getProperty("user.dir") + File.separator + "CreateWorkitemService\\log4j.properties";
		props.load(new FileInputStream(configPath));
		PropertyConfigurator.configure(props);

		configPath = System.getProperty("user.dir") + File.separator + "CreateWorkitemService\\config.properties";
		FileReader reader = new FileReader(configPath);

		logger.info("configPath: " + configPath);

		propertiesFileData = new Properties();
		propertiesFileData.load(reader);

		String cabinetName = propertiesFileData.getProperty("cabinetName");
		String ipAddress = propertiesFileData.getProperty("ipAddress");
		String username = propertiesFileData.getProperty("username");
		String password = propertiesFileData.getProperty("password");
		String volID = propertiesFileData.getProperty("volID");

		StringBuilder inputJSON = new StringBuilder();
		String result = "";
		try {
			BufferedReader in = new BufferedReader(new InputStreamReader(incomingData));
			String line = null;
			while ((line = in.readLine()) != null) {
				inputJSON.append(line);
			}

			logger.info("Data Received: " + inputJSON.toString());
			String DocumentName = "", ProposalNumber = "", DocumentCategory = "", documentData = "",
					createdByAppName = "", DocumentNameOD = "";
			String folderIndex = "", documentDetailsJSON;

			String outputXML = "", inputXML = "", query = "";
			String proposalFolderIndex = "";

			// documentDetailsJSON="{\"DocumentName\":\"test.txt\",\"ProposalNumber\":\"123456789\",\"DocumentCategory\":\"Others\",\"DocumentData\":\"dGVzdERhdGE=\"}";
			documentDetailsJSON = inputJSON.toString();

			JSONParser jsonParser = new JSONParser();
			JSONObject json = (JSONObject) jsonParser.parse(documentDetailsJSON);

			ProposalNumber = (String) json.get("ProposalNumber");
			query="SELECT itemindex FROM NG_NB_EXT_TABLE(NOLOCK) WHERE Proposal_Number = '"+ ProposalNumber +"' ";

			// getting sessionID
//        inputXML = XMLGen.get_WMConnect_Input(cabinetName,username,password,"N");
//        logger.info("get_WMConnect_Input_inputXML: "+inputXML);      
//        outputXML = callRestAPI_JTS(inputXML);
//        String sessionID = outputXML.substring(outputXML.indexOf("<SessionId>")+11,outputXML.indexOf("</SessionId>"));
//        logger.info("get_WMConnect_Input_outputXML: "+outputXML);        

			String sessionIDJSON = json.get("SessionID").toString();
			String sessionID = "";
			if (!sessionIDJSON.equalsIgnoreCase("") && sessionIDJSON != null) {
				sessionID = sessionIDJSON;
			} else
				sessionID = CommonFunctions.getSessionID();

			// select call
			inputXML = XMLGen.APSelectWithColumnNames(cabinetName,query,sessionID);
			logger.info(inputXML + " " + ProposalNumber);
			outputXML = CommonFunctions.callRestAPI_JTS(inputXML);

			// WI already exists for given Proposal number
        if(outputXML.indexOf("<itemindex>")!=-1) {
//			if (1 == 1) {sd
				folderIndex = outputXML.substring(outputXML.indexOf("<itemindex>") + 11,
						outputXML.indexOf("</itemindex>"));
				// attaching documents to WI corresponding to the given Proposal Number
				JSONArray DocumentsArray;
				DocumentsArray = (JSONArray) json.get("Documents");

				for (Object j : DocumentsArray) {
					JSONObject jsonObj = (JSONObject) j;
					// attributesXML = attributesXML +
					DocumentCategory = (String) jsonObj.get("DocumentCategory");
					documentData = (String) jsonObj.get("DocumentDataBase64");
					DocumentName = (String) jsonObj.get("DocumentName");

					createdByAppName = DocumentName.substring(DocumentName.indexOf(".") + 1, DocumentName.length());
					DocumentNameOD = DocumentName.substring(0, DocumentName.indexOf("."));
					// changed here by prakhar
					String docData = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:ngo=\"http://bdo.ws.jts.omni.newgen.com/NGOAddDocumentService/\"><soapenv:Header/><soapenv:Body>"
							+ "<ngo:NGOAddDocumentBDO>" + "<cabinetName>" + cabinetName + "</cabinetName>"
							+ "<documentPath></documentPath>" + "<folderIndex>" + folderIndex + "</folderIndex>"
							// + "<folderIndex>"+""+"</folderIndex>"
							+ "<documentName>" + DocumentCategory + "." + createdByAppName + "</documentName>"
							+ "<userDBId>" + sessionID + "</userDBId>" + "<volumeId>" + volID + "</volumeId>"
							+ "<creationDateTime></creationDateTime>" + "<versionFlag>N</versionFlag>"
							+ "<accessType>S</accessType>" + "<documentType>N</documentType>" + "<createdByAppName>"
							+ createdByAppName + "</createdByAppName>" + "<enableLog>Y</enableLog>" + "<comment>"
							+ DocumentNameOD + "</comment>" + "<author></author>" + "<FTSFlag>Y</FTSFlag>"
							+ "<groupIndex></groupIndex>" + "<ownerIndex></ownerIndex>" + "<nameLength></nameLength>"
							+ "<duplicateName></duplicateName>" + "<textAlsoFlag></textAlsoFlag>"
							+ "<imageData></imageData>"
							+ "<transactionRequired></transactionRequired><ownerType></ownerType>"
							+ "<signFlag></signFlag><thumbNailFlag></thumbNailFlag>" + "<userName></userName>"
							+ "<encrFlag></encrFlag><passAlgoType></passAlgoType>" + "<userPassword></userPassword>"
							+ "<document>" + documentData + "</document>"
							+ "</ngo:NGOAddDocumentBDO></soapenv:Body></soapenv:Envelope>";
					String docResult = CommonFunctions.uploadDoc(docData);
//					String docResult = NGOAddDocumentServiceClient.uploadDocToOD(sessionID);
					// Inserting doc data to table
					String documentType = "", isIndex = "", noOfPages = "", documentSize = "", createdByApp = "",
							comment = "", createdDateTime = "", proposalNumber = "", DocIndex = "",
							parentFolderIndex = "";
					documentType = docResult.substring(docResult.indexOf("<documentName>") + 14,
							docResult.indexOf("</documentName>"));
					isIndex = docResult.substring(docResult.indexOf("<isIndex>") + 9, docResult.indexOf("</isIndex>"));
					isIndex = isIndex.substring(0, isIndex.length() - 1); // removing last #
					noOfPages = docResult.substring(docResult.indexOf("<noOfPages>") + 11,
							docResult.indexOf("</noOfPages>"));
					documentSize = docResult.substring(docResult.indexOf("<documentSize>") + 14,
							docResult.indexOf("</documentSize>"));
					createdByApp = docResult.substring(docResult.indexOf("<createdByAppName>") + 18,
							docResult.indexOf("</createdByAppName>"));
					comment = docResult.substring(docResult.indexOf("<comment>") + 9, docResult.indexOf("</comment>"));
					createdDateTime = docResult.substring(docResult.indexOf("<createdDateTime>") + 17,
							docResult.indexOf("</createdDateTime>"));
					proposalNumber = ProposalNumber;
					DocIndex = docResult.substring(docResult.indexOf("<documentIndex>") + 15,
							docResult.indexOf("</documentIndex>"));
					parentFolderIndex = docResult.substring(docResult.indexOf("<parentFolderIndex>") + 19,
							docResult.indexOf("</parentFolderIndex>"));

					// bug 1080317
					// bug 1080316
					query = "INSERT INTO NG_NB_DOCUMENTS_UPLOADED (DOCUMENT_TYPE, IS_INDEX, NO_OF_PAGES, DOCUMENT_SIZE, CREATED_BY_APP,"
							+ " COMMENT, CREATED_DATE_TIME, PROPOSAL_NUMBER, DOC_INDEX, PARENT_FOLDER_INDEX, IS_ASSOCIATED)\r\n"
							+ "VALUES ('" + documentType + "', '" + isIndex + "', '" + noOfPages + "', '" + documentSize
							+ "', '" + createdByApp + "'," + " '" + comment + "', '" + createdDateTime + "', '"
							+ proposalNumber + "', '" + DocIndex + "', '" + parentFolderIndex + "', 'Y')";
//            	//getting sessionID
//            	inputXML = XMLGen.get_WMConnect_Input(cabinetName,username,password,"N");
//                logger.info("get_WMConnect_Input_inputXML: "+inputXML);      
//                outputXML = callRestAPI_JTS(inputXML);
//                sessionID = outputXML.substring(outputXML.indexOf("<SessionId>")+11,outputXML.indexOf("</SessionId>"));
//                logger.info("get_WMConnect_Input_outputXML: "+outputXML);
					// select call
					inputXML = XMLGen.APSelectWithColumnNames(cabinetName, query, sessionID);
					logger.info("APSelectWithColumnNames_Input_inputXML: " + inputXML);
					// outputXML = WFCallBroker.execute(inputXML, "192.168.54.97", 3333, 1);
					outputXML = CommonFunctions.callRestAPI_JTS(inputXML);
					logger.info("APSelectWithColumnNames_outputXML: " + outputXML);

					result = result + docResult;
					logger.info(docData);
					logger.info(result);
				}
			}

			// Else block Commented by Prakhar on 3rd October 2020
			/*
			 * //WI not exists for given Proposal Number else { //create a folder with the
			 * name of Proposal Number try { //proposalFolderIndex =
			 * CommonFunctions.createFolder(ProposalNumber,sessionID);
			 * 
			 * JSONArray DocumentsArray; DocumentsArray=(JSONArray)json.get("Documents");
			 * 
			 * for (Object j : DocumentsArray) { JSONObject jsonObj=(JSONObject)j;
			 * //attributesXML = attributesXML + DocumentCategory = (String)
			 * jsonObj.get("DocumentCategory"); documentData = (String)
			 * jsonObj.get("DocumentDataBase64"); DocumentName = (String)
			 * jsonObj.get("DocumentName");
			 * 
			 * createdByAppName = DocumentName.substring(DocumentName.indexOf(".")+1,
			 * DocumentName.length()); DocumentNameOD = DocumentName.substring(0,
			 * DocumentName.indexOf("."));
			 * 
			 * //Adding document to Image Server and inserting the entries to
			 * NG_NB_DOCUMENTS_UPLOADED table to //associate with the Workitem later in case
			 * of no error.
			 * 
			 * String filePath = CommonFunctions.base64toFile(documentData, ProposalNumber,
			 * DocumentName); String isIndex = CommonFunctions. AddDocument_MT(filePath);
			 * if(isIndex.equalsIgnoreCase("Error")) { String
			 * statusCode="Error in adding doument to image server. Check SMS logs."; return
			 * statusCode; }
			 * 
			 * 
			 * //Adding data to NG_NB_DOCUMENTS_UPLOADED String
			 * documentType="",noOfPages="",documentSize="",createdByApp="",comment="",
			 * createdDateTime="", proposalNumber="",DocIndex="",parentFolderIndex="";
			 * documentType =
			 * DocumentCategory;//docResult.substring(docResult.indexOf("<documentName>")+14
			 * ,docResult.indexOf("</documentName>")); //isIndex = IsIndex.m_nDocIndex+ "#"+
			 * IsIndex.m_sVolumeId; noOfPages =
			 * "";//docResult.substring(docResult.indexOf("<noOfPages>")+11,docResult.
			 * indexOf("</noOfPages>")); documentSize =
			 * "";//docResult.substring(docResult.indexOf("<documentSize>")+14,docResult.
			 * indexOf("</documentSize>")); createdByApp =
			 * createdByAppName;//docResult.substring(docResult.indexOf("<createdByAppName>"
			 * )+18,docResult.indexOf("</createdByAppName>")); comment =
			 * DocumentNameOD;//docResult.substring(docResult.indexOf("<comment>")+9,
			 * docResult.indexOf("</comment>")); Date date = (Date)
			 * Calendar.getInstance().getTime(); DateFormat dateFormat = new
			 * SimpleDateFormat("MM/dd/yyyy"); createdDateTime =dateFormat.format(date);
			 * //docResult.substring(docResult.indexOf("<createdDateTime>")+17,docResult.
			 * indexOf("</createdDateTime>")); proposalNumber = ProposalNumber; DocIndex =
			 * "";//docResult.substring(docResult.indexOf("<documentIndex>")+15,docResult.
			 * indexOf("</documentIndex>")); parentFolderIndex = "";
			 * 
			 * query =
			 * "INSERT INTO NG_NB_DOCUMENTS_UPLOADED (DOCUMENT_TYPE, IS_INDEX, NO_OF_PAGES, DOCUMENT_SIZE, CREATED_BY_APP,"
			 * +
			 * " COMMENT, CREATED_DATE_TIME, PROPOSAL_NUMBER, DOC_INDEX, PARENT_FOLDER_INDEX, IS_ASSOCIATED)\r\n"
			 * + "VALUES ('"+documentType+"', '"+isIndex+"', '"+noOfPages+"', '"
			 * +documentSize+"', '"+createdByApp+"'," +
			 * " '"+comment+"', '"+createdDateTime+"', '"+proposalNumber+"', '"
			 * +DocIndex+"', '"+parentFolderIndex+"', 'N')"; // //getting sessionID //
			 * inputXML = XMLGen.get_WMConnect_Input(cabinetName,username,password,"N"); //
			 * logger.info("get_WMConnect_Input_inputXML: "+inputXML); // outputXML =
			 * callRestAPI_JTS(inputXML); // sessionID =
			 * outputXML.substring(outputXML.indexOf("<SessionId>")+11,outputXML.indexOf(
			 * "</SessionId>")); //
			 * logger.info("get_WMConnect_Input_outputXML: "+outputXML); //select call
			 * inputXML = XMLGen.APSelectWithColumnNames(cabinetName,query,sessionID);
			 * logger.info("APSelectWithColumnNames_Input_inputXML: "+inputXML); //outputXML
			 * = WFCallBroker.execute(inputXML, "192.168.54.97", 3333, 1); outputXML =
			 * CommonFunctions.callRestAPI_JTS(inputXML);
			 * logger.info("APSelectWithColumnNames_outputXML: "+outputXML);
			 * 
			 * 
			 * //result = result + docResult;
			 * logger.info("Image added to Image Server having Image Index "+isIndex); //
			 * logger.info(result); }
			 * 
			 * 
			 * //disconnecting user logger.info("Disconnecting User..."); String ipXML =
			 * XMLGen.get_WMDisConnect_Input(cabinetName,sessionID);
			 * logger.info("ipXMLDisconnect_inputXML: "+ipXML); //String outputXML =
			 * WFCallBroker.execute(inputXML, "192.168.54.97", 3333, 1); String opXML =
			 * CommonFunctions.callRestAPI_JTS(ipXML);
			 * logger.info("ipXMLDisconnect_outputXML: "+opXML); } catch(Exception ex) {
			 * ex.printStackTrace(); } }
			 */

		} catch (Exception e) {
			logger.info(e.toString());
		}

		// converting xml to json
//		org.json.JSONObject jsonObj = null;
//		try {
//			jsonObj = XML.toJSONObject(result);
//		} catch (JSONException e) {
//			e.printStackTrace();
//		}
		try {
			result = XML.toJSONObject(result).toString(4);
		} catch (JSONException e) {
			e.printStackTrace();
		}

		return result;
	}
}
