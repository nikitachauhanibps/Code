package com.newgen.services;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.newgen.util.*;

/**
 * 
 * @author prakhar.saxena
 *
 */
public class AXISDOCUPDATE {
	public static Properties propertiesFileData;
	static Logger logger = Logger.getLogger(CommonFunctions.class.getName()); 
	
	public String AXISDOCUPDATE(String docIndex, String status, String sessionId) throws FileNotFoundException, IOException {
		
		propertiesFileData = new Properties();
		Properties props = new Properties();
		
		String configPath = System.getProperty("user.dir") + File.separator + "CreateWorkitemService\\log4j.properties";
		props.load(new FileInputStream(configPath));
		PropertyConfigurator.configure(props);		
		
		configPath = System.getProperty("user.dir") + File.separator + "CreateWorkitemService\\config.properties";
        FileReader reader = new FileReader(configPath);
        
         logger.info("configPath: "+configPath);
        
        propertiesFileData = new Properties();
		propertiesFileData.load(reader);		 
		
		String cabinetName = propertiesFileData.getProperty("cabinetName");		
		
		String winame = "";
		
		String query = "EXEC NG_SP_NB_AXIS_DOC_PROC '"+docIndex+"','" + status +"'";
		String inputXML = XMLGen.APSelectWithColumnNames(cabinetName,query,sessionId);
		logger.info("APSelectWithColumnNames_Input_inputXML: "+inputXML);
		String outputXML = CommonFunctions.callRestAPI_JTS(inputXML);
		logger.info("APSelectWithColumnNames_Output_outputXML: "+outputXML);
		
		
		
		if(outputXML.indexOf("SUCCESS")!=-1) {
			String Result = outputXML.substring(outputXML.indexOf("SUCCESS")+8, outputXML.indexOf("</SUCCESS>"));
			winame=Result;
			
		}
		else
			winame="FAILURE";
		return winame;
	}
}
