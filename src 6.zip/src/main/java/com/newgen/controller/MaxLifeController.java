package com.newgen.controller;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.json.JSONException;
import org.json.simple.parser.ParseException;

import com.newgen.services.*;
import com.newgen.util.*;

@Path("/Services")
public class MaxLifeController {

    CommonFunctions commonFunctions = new CommonFunctions();

    CreateWI createWorkitem = new CreateWI();

    @POST
    @Path("/createWorkitem")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public Response createWI(InputStream incomingData) throws IOException, Exception {
        String result = createWorkitem.createWI(incomingData);
        return Response.status(200).entity(result).build();
    }

    UploadDocument uploadDoc = new UploadDocument();

    @POST
    @Path("/addDocument")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response addDocument(InputStream incomingData) throws FileNotFoundException, IOException {
        String result = uploadDoc.addDocument(incomingData);
        return Response.status(200).entity(result).build();
    }

    UpdateWorkitem updateWI = new UpdateWorkitem();

    @POST
    @Path("/updateWorkitem")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response updateWorkitem(InputStream incomingData)
            throws FileNotFoundException, IOException, JSONException, ParseException {
        String result = updateWI.updateWI(incomingData);
        return Response.status(200).entity(result).build();
    }

    GetPolicyInfo getInfo = new GetPolicyInfo();

    @GET
    @Path("/policyInfo")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getPolicyInfo(@QueryParam("policyNo") String policyNo)
            throws FileNotFoundException, IOException, JSONException, ParseException {
        String result = getInfo.getPolicyInfo(policyNo);
        return Response.status(200).entity(result).build();
    }

    GetWIName getWIName = new GetWIName();

    @GET
    @Path("/getWIname")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getWIName(@QueryParam("policyNo") String policyNo, @HeaderParam("sessionId") String sessionId)
            throws FileNotFoundException, IOException, JSONException, ParseException {
        String result = getWIName.getWIFromPolicyNo(policyNo, sessionId);
        return Response.status(200).entity(result).build();
    }
    
    
    
    MproMov MproMov = new MproMov();

    @GET
    @Path("/MproMov")
    @Produces(MediaType.APPLICATION_JSON)
    public Response MproMov(@QueryParam("policyNo") String policyNo,@QueryParam("policyFolder") String policyfolder,@QueryParam("docName") String docname,@QueryParam("docSize") String docsize,@QueryParam("docIndex") String docindex, @HeaderParam("sessionId") String sessionId)
            throws FileNotFoundException, IOException, JSONException, ParseException {
        String result = MproMov.MproMovement(policyNo,policyfolder,docname,docsize,docindex, sessionId);
        return Response.status(200).entity(result).build();
    }

    GetClientLevel getClientLevelser = new GetClientLevel();

    @POST
    @Path("/clientLevel")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    
    public Response getClientLevel(InputStream incomingData)
            throws FileNotFoundException, IOException, JSONException, ParseException {
        String result = getClientLevelser.getClientLevel(incomingData);
    	//String Result=sessionId;
        return Response.status(200).entity(result).build();
    }

    @POST
    @Path("/generateSessionID")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response getSessionID(InputStream incomingData, @HeaderParam("password") String password)
            throws FileNotFoundException, IOException, JSONException, ParseException {
        String result = commonFunctions.generateSessionID(incomingData, password);
        return Response.status(200).entity(result).build();
    }
    AMLBackFlow amlBackFlow = new AMLBackFlow();
    
    @POST
    @Path("/amlBackFlow")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public Response amlBackFlow(InputStream incomingData, @HeaderParam("sessionId") String sessionId) throws IOException, Exception {
        String result = amlBackFlow.amlBackFlow(incomingData, sessionId);
        return Response.status(200).entity(result).build();
    }
    
AXISDOCGEN AXISDOCGEN = new AXISDOCGEN();
    

@GET
@Path("/DocSharing")
@Produces(MediaType.APPLICATION_JSON)
public Response AXISDOCGEN(@HeaderParam("sessionId") String sessionId)
        throws FileNotFoundException, IOException, JSONException, ParseException {
    String result = AXISDOCGEN.AXISDOCGEN(sessionId);
    return Response.status(200).entity(result).build();
}


AXISDOCUPDATE AXISDOCUPDATE = new AXISDOCUPDATE();

@GET
@Path("/AXISDOCUPDATE")
@Produces(MediaType.APPLICATION_JSON)
public Response AXISDOCUPDATE(@QueryParam("docIndex") String docIndex, @QueryParam("status") String status, @HeaderParam("sessionId") String sessionId)
        throws FileNotFoundException, IOException, JSONException, ParseException {
    String result = AXISDOCUPDATE.AXISDOCUPDATE(docIndex, status, sessionId);
    return Response.status(200).entity(result).build();
}

//added by sparsh 
MyMoneyBackFlow myMoneyBackFlow = new MyMoneyBackFlow();

@POST
@Path("/myMoneyBackFlow")
@Produces(MediaType.APPLICATION_JSON)
//@Consumes(MediaType.APPLICATION_JSON)
public Response myMoneyBackFlow(InputStream incomingData, @HeaderParam("sessionId") String sessionId) throws IOException, Exception {
    String result = myMoneyBackFlow.myMoneyBackFlow(incomingData, sessionId);
    return Response.status(200).entity(result).build();
}

    //for testing pupose
//	TestClass testClass = new TestClass();
//	@POST
//	@Path("/testMethod")
//	@Consumes(MediaType.APPLICATION_JSON)
//	@Produces(MediaType.APPLICATION_JSON)
//	public Response getResult(InputStream incomingData)
//			throws FileNotFoundException, IOException, JSONException, ParseException {
//		String result = testClass.result(incomingData);
//		
//		return Response.status(200).entity(result).build();
//	}
InsertDetailsAfterMraWorkstep insertDetailsAfterMraWorkstep = new InsertDetailsAfterMraWorkstep();
@POST
@Path("/mraBackFlow")
@Produces(MediaType.APPLICATION_JSON)
//@Consumes(MediaType.APPLICATION_JSON)
public Response mraBackFlow(InputStream incomingData, @HeaderParam("sessionId") String sessionId) throws IOException, Exception {
   
	String result = insertDetailsAfterMraWorkstep.mraBackFlowService(incomingData,sessionId);
    return Response.status(200).entity(result).build();
}

//added by Farman 
FetchDocStatus fetchDocStatus = new FetchDocStatus();
@POST
@Path("/fetchDoc")
@Produces(MediaType.APPLICATION_JSON)
//@Consumes(MediaType.APPLICATION_JSON)
public Response fetchDocStatus(InputStream incomingData, @HeaderParam("sessionId") String sessionId) throws IOException, Exception {
   
	String result = fetchDocStatus.fetchDocStatusService(incomingData,sessionId);
    return Response.status(200).entity(result).build();



}


NPSMproMov NPSMproMov = new NPSMproMov();

@POST
@Path("/NPSMproMov")
@Produces(MediaType.APPLICATION_JSON)
public Response NPSMproMov(InputStream incomingData, @HeaderParam("sessionId") String sessionId) throws IOException, Exception{
    String result = NPSMproMov.MproMovement(incomingData, sessionId);
    return Response.status(200).entity(result).build();
}

PreQCMov PreQCMov = new PreQCMov();

@GET
@Path("/PreQCMov")
@Produces(MediaType.APPLICATION_JSON)
public Response PreQCMov(@QueryParam("policyNo") String policyNo,@QueryParam("policyFolder") String policyfolder,@QueryParam("docName") String docname,@QueryParam("docSize") String docsize,@QueryParam("docIndex") String docindex, @HeaderParam("sessionId") String sessionId)
        throws FileNotFoundException, IOException, JSONException, ParseException {
    String result = PreQCMov.PreQCMovement(policyNo,policyfolder,docname,docsize,docindex, sessionId);
    return Response.status(200).entity(result).build();
}


}
