package com.newgen.validations;

import java.awt.List;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import com.newgen.util.CommonFunctions;

class BusinessLogicDao {
	static Logger logger = Logger.getLogger(BusinessLogicDao.class.getName());
	private String whereClause="";
	private String whereClauseWithoutTable;
	static String source; // JSON OR IFORM
	static QueryExecutor queryExecutor = new QueryExecutor();
	private String channel;
	private String subChannel;
	private String sub_Channel;
	String productDating;
	//private String jointLife;  //DR-28247 sparsh
	private String riderFlag="N";
	static String productType="ULIP";
	private String planCode;

	// Constructors
	/*
	private BusinessLogicDao() {
	}
	*/
	public BusinessLogicDao(String planCode, String channel, String sub_Channel, String source, String sessionId,
			String cabinetName,String DefenceChannelCase) {
		//super();
		queryExecutor.setSessionID(sessionId);
		queryExecutor.setCabinetName(cabinetName);
		
		sub_Channel = queryExecutor.getSubChannelDescFromVal(channel,DefenceChannelCase, source);
		logger.info("sub_Channel: " + sub_Channel); 
		
		Date date = new Date();
		this.planCode = planCode;
		logger.info("planCode: " + planCode); 
		this.channel = channel;
		logger.info("channel: " + channel); 
		this.sub_Channel = sub_Channel;
		logger.info("sub_Channel: " + sub_Channel); 
		String effectiveDate = new SimpleDateFormat("MM/dd/yyyy").format(date);
		this.whereClause = " FROM NG_NB_MS_ULIP(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + channel
				+ "' AND Sub_Channel='" + sub_Channel + "' AND Is_Active_Ind='Y'";// AND
		this.whereClauseWithoutTable = 	 " WHERE Plan_Code='" + planCode + "' AND Channel='" + channel
				+ "' AND Sub_Channel='" + sub_Channel + "'"	;															
		logger.info("whereClause: " + whereClause); // ";
		String query = "SELECT ISNULL(Product_Dating,'') AS 'Product_Dating'"+this.whereClause;
		this.productDating=queryExecutor.runDBQuery("JSON",query, "Product_Dating");
		
		this.source = source;
	}
	
	//Another Constructor specific to Riders
	public BusinessLogicDao(String channel,String DefenceChannelCase, String source, String sessionId, String cabinetName, String ProductName) {
		//super();
		this.riderFlag="Y";
		String tableName="NG_NB_MS_ULIP";
		
		queryExecutor.setSessionID(sessionId);
		queryExecutor.setCabinetName(cabinetName);
		
		this.planCode=ProductName;
		
		this.channel=channel;
		this.subChannel = queryExecutor.getSubChannelDescFromVal(channel,DefenceChannelCase, source);
		
//		this.whereClause = " FROM NG_NB_MS_ULIP(NOLOCK) WHERE Plan_Code='" + ProductName + "' AND Channel='" + channel
//				+ "' AND Sub_Channel='" + subChannel + "' AND Is_Active_Ind='Y'";// AND
		
		String query = "SELECT PRODUCT_TYPE FROM NG_NB_MS_PLAN_CODE(NOLOCK) WHERE PLAN_CODE = '"+ProductName+"'";
		this.productType = queryExecutor.runDBQuery("JSON",query, "PRODUCT_TYPE");
		
		if(productType.equals("TRAD"))
			tableName="NG_NB_MS_TRAD";
		if(productType.equals("JOINT"))
			tableName="NG_NB_MS_JOINT";
		if(productType.equals("ANNUITY"))
			tableName="NG_NB_MS_ANNUITANT";
		if(productType.equals("HEALTH"))
			tableName="NG_NB_MS_HEALTH";
		
		query = "SELECT ISNULL(Product_Dating,'') AS 'Product_Dating' FROM NG_NB_MS_ULIP(NOLOCK) WHERE Plan_Code='"+ProductName+"' "
				+ "AND Channel='"+channel+"' AND Sub_Channel='"+this.subChannel+"'";
		if(productType.equals("TRAD"))
		{
			query = "SELECT ISNULL(Product_Dating,'') AS 'Product_Dating' FROM NG_NB_MS_TRAD(NOLOCK) WHERE Plan_Code='"+ProductName+"' "
					+ "AND Channel='"+channel+"' AND Sub_Channel='"+this.subChannel+"'";
		}
		if(productType.equals("ANNUITY"))
		{
			query = "SELECT ISNULL(Product_Dating,'') AS 'Product_Dating' FROM NG_NB_MS_ANNUITANT(NOLOCK) WHERE Plan_Code='"+ProductName+"' "
					+ "AND Channel='"+channel+"' AND Sub_Channel='"+this.subChannel+"'";
		}
		if(productType.equals("HEALTH"))
		{
			query = "SELECT ISNULL(Product_Dating,'') AS 'Product_Dating' FROM NG_NB_MS_HEALTH(NOLOCK) WHERE Plan_Code='"+ProductName+"' "
					+ "AND Channel='"+channel+"' AND Sub_Channel='"+this.subChannel+"'";
		}
		//mofdified by Aanchal 28MArch21
		this.productDating=queryExecutor.runDBQuery("JSON",query, "Product_Dating");
		
		this.source = source;
	}
	//End of Constructor
	

	// methods
	
	public String validateEffectiveDate(String effectiveDate, String customerSignDate) {
		EffectiveDate effectiveDt = new EffectiveDate(effectiveDate,customerSignDate,whereClause);
		effectiveDt.validateField();
		return effectiveDt.getResult();
	}

	public String validateSumAssured(String value,String CoverageMultiple, String ATP,String riderClass,String  baseSA, String ExactIncome) {
		SumAssured sumAssured = new SumAssured(value,CoverageMultiple,ATP,riderClass, baseSA, whereClause, riderFlag,planCode, ExactIncome);
		sumAssured.validateField();
		logger.info("log1 AANCHAL ");
		return sumAssured.getResult();
	}

	public String validateCoverageTerm(String coverageTerm, String insuredDOB,String effectiveDate) {
		// initializing values
		CoverageTerm coverageTrm = new CoverageTerm(coverageTerm, insuredDOB,effectiveDate,whereClause,productDating);
		// validating
		coverageTrm.validateField();
		// returning message
		return coverageTrm.getResult();
	}

	public String validateModalPremium(String modalPremium, String modeOfPay) {
		ModalPremium mp = new ModalPremium(modalPremium, modeOfPay, whereClause);
		mp.validateField();
		return mp.getResult();
	}

	public Map<String, String> validateCommaSeparatedValues(String fieldValue, Map<String, String> hm) {
		CommaSeparatedValues commaSeparatedValues = new CommaSeparatedValues();
		commaSeparatedValues.getValidKeyValues(hm.get("MDM_ColumnName"), hm.get("masterTableName"),
				hm.get("masterValue"), hm.get("masterLabel"), whereClause);
		return commaSeparatedValues.getResult();
	}

	public String validatePremiumPaymentTerm(String premiumPaymentTerm, String insuredDOB, String coverageTerm,String effectiveDate) {
		PremiumPaymentTerm premiumPPT = new PremiumPaymentTerm(premiumPaymentTerm, insuredDOB, coverageTerm, whereClauseWithoutTable,effectiveDate, whereClause,productDating);
		premiumPPT.validateField();
		return premiumPPT.getResult();
	}

	public String validateIssueAge(String insuredDob,String propDOB, String coverageTerm, String effectiveDate) {
		IssueAge issueAge = new IssueAge(insuredDob, propDOB, coverageTerm,effectiveDate,whereClause,productDating);
		issueAge.validateField();
		logger.info("logger2:validateIssueAge: "+issueAge);
		return issueAge.getResult();
	}

	public boolean isDiscountApplicable(String discount, String discountType) {
		Discount dscnt = new Discount(discount, discountType, whereClause);
		return dscnt.isApplicable();
	}

	public boolean isFieldApplicable(String fieldValue, String mdmColName) {
		CheckFieldVisible checkFieldVisible = new CheckFieldVisible(fieldValue, mdmColName, whereClause);
		return checkFieldVisible.isVisible();
	}

	public String validateCoverageMultiple(String coverageMultiple, String coverageTerm, String propDOB,String effectiveDate,String planCode) {
		CoverageMultiple coverageMult = new CoverageMultiple(coverageMultiple, coverageTerm, propDOB,effectiveDate, whereClause, productDating,planCode);
		coverageMult.validateField();
		return coverageMult.getResult();
	}

	public String validatePlanPayOptionCode(String premiumPaymentTerm, String coverageTerm) {
		PlanPayOptionCode planPayOptionCode = new PlanPayOptionCode(premiumPaymentTerm, coverageTerm, whereClause);
		planPayOptionCode.validateField();
		return planPayOptionCode.getMessage();
	}

	public String validateBenefitRiders(JSONArray riderDetailsArr) {
		BenefitRiders benefitRiders = new BenefitRiders(riderDetailsArr,whereClause);
		benefitRiders.validateRiders();
		return benefitRiders.getMessage();
	}

	public String validateRiders(JSONArray riderDetailsArr,String effectiveDate, String customerSignDate) {
		Riders riders = new Riders(riderDetailsArr,effectiveDate,customerSignDate,whereClause,productDating);
		riders.validateRiders();
		return riders.getMessage();
	}

	//Rider Fxns
	public String validateRiderCoverageTerm(String CoverageTerm, String insuredDob,String proposerDOB,String effectiveDate,String baseCoverageTerm,String basePPT,String JointLife) {
		RiderCT riderCT = new RiderCT(CoverageTerm,insuredDob,proposerDOB,effectiveDate,baseCoverageTerm,basePPT,whereClause,productDating,JointLife); //DR-2
		riderCT.validateCT();
		return riderCT.getMessage();
	}
	
	public String validateRiderPPT(String PPT,String baseCoverageTerm,String basePPT,String insuredDob,String effectiveDate,String CoverageTerm) {
		RiderPPT riderPPT = new RiderPPT(PPT,baseCoverageTerm,basePPT,insuredDob,effectiveDate,CoverageTerm, whereClause,productDating);
		riderPPT.validatePPT();
		return riderPPT.getMessage();
	}
	
	//Rider Fxns End	
	
	public String validateFunds(JSONArray fundsGridArr, String systematicTransferFund, String dynamicfundallocation,
			String lifeStylePortfolioStrategy, String lifescycleFund1, String lifecycleFund2,
			String triggerPortfolioStrategy, String trigger_Fund1, String trigger_Fund2, String SystematicTransferFund,
			String TriggerPortfolioStrategy, String LifeStylePortfolioStrategy, String modeOfPayment,String movementPercentage) {

		Funds funds = new Funds(fundsGridArr, systematicTransferFund, dynamicfundallocation, lifeStylePortfolioStrategy,
				lifescycleFund1, lifecycleFund2, triggerPortfolioStrategy, trigger_Fund1, trigger_Fund2, planCode,
				SystematicTransferFund, TriggerPortfolioStrategy, LifeStylePortfolioStrategy,modeOfPayment,movementPercentage,whereClause);
		funds.validateFunds();
		return funds.getMessage();
	}
	
	public boolean validateFund() {
		String query = "SELECT COUNT(*) AS TOTAL_COUNT " + whereClause;
		return BusinessLogicDao.queryExecutor.validateFundQuery(query, source);
	}

	static // util methods
	String CalculateYears(String insuredDOB, String effectiveDate, String productDating) {
		String years = "";
		try {
			
			Date inDate = null;
			Date currentDate = new Date();
			new SimpleDateFormat("yyyy-MM-dd").format(currentDate);
			
			if(productDating.equalsIgnoreCase("ED"))
				currentDate=new SimpleDateFormat("yyyy-MM-dd").parse(effectiveDate);
			
			inDate = new SimpleDateFormat("yyyy-MM-dd").parse(insuredDOB);
			/*long diff = currentDate.getTime() - inDate.getTime();
			int diffInYears = (int) (diff / (60 * 60 * 1000 * 24 * 30.41666666 * 12));
			years = String.valueOf(diffInYears);*/
			
			LocalDate fromDate=inDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
			LocalDate toDate=currentDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
			
			if(productDating.equalsIgnoreCase("CD")){
	            if(inDate!=null)
	                years =  String.valueOf(getAge(inDate,null));
	        }
	        else
	        {   if(inDate!=null && effectiveDate!=null)
	                years =  String.valueOf(getAge(inDate,currentDate));
	        } 
			
			//int diffYears=Period.between(fromDate, toDate).getYears();
			//years=String.valueOf(diffYears);
			/*try {
				inDate = new SimpleDateFormat("dd/MM/YYY").parse(insuredDOB);
				long diff = currentDate.getTime() - inDate.getTime();
				int diffInYears = (int) (diff / (60 * 60 * 1000 * 24 * 30.41666666 * 12));
				years = String.valueOf(diffInYears);
				return years;
			} catch (Exception e) {
				e.printStackTrace();
			}*/

				
			
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return years;
	}
	
	private static int getAge(Date dateOfBirth, Date effectiveDate) {

	    Calendar today = Calendar.getInstance();
	    Calendar birthDate = Calendar.getInstance();
            Calendar effDate = Calendar.getInstance();

	    int age = 0;

	    birthDate.setTime(dateOfBirth);
                        
            if(effectiveDate!=null){
                effDate.setTime(effectiveDate);
                today=effDate;
            }
            
            
	    if (birthDate.after(today)) {
	        throw new IllegalArgumentException("Can't be born in the future");
	    }

	    age = today.get(Calendar.YEAR) - birthDate.get(Calendar.YEAR);

	    // If birth date is greater than todays date (after 2 days adjustment of leap year) then decrement age one year   
	    if ( (birthDate.get(Calendar.DAY_OF_YEAR) - today.get(Calendar.DAY_OF_YEAR) > 3) ||
	            (birthDate.get(Calendar.MONTH) > today.get(Calendar.MONTH ))){
	        age--;

	     // If birth date and todays date are of same month and birth day of month is greater than todays day of month then decrement age
	    }else if ((birthDate.get(Calendar.MONTH) == today.get(Calendar.MONTH )) &&
	              (birthDate.get(Calendar.DAY_OF_MONTH) > today.get(Calendar.DAY_OF_MONTH ))){
	        age--;
	    }
	    return age;
	}
	
	//Rider Starts
	
	//To Check whether the rider is present in the master or not 
	public String validateRiderInMaster(String riderCode,String queryId) {
		//return row.getReturnVal();
		String returnVal="",query = "",columnName = "";
		if(queryId.equals("1")){
			query="SELECT ISNULL(Rider_Type,'') AS 'Rider_Type' FROM NG_NB_MS_RIDER_BENEFIT_CODE_DESC(NOLOCK) WHERE Rider_Code='"+riderCode+"'";
			columnName="Rider_Type";
		}
		else if(queryId.equals("2")){
			query="SELECT COUNT(*) AS 'Count' "+whereClause;
			columnName="Count";
		}
		returnVal=BusinessLogicDao.queryExecutor.runDBQuery("JSON", query, columnName);
		return returnVal;
	}
	
	public String validateRiderIndicator(String riderCode) {
		String query = "SELECT ISNULL(Is_Active_Ind,'') AS 'Is_Active_Ind'  "+ whereClause,
				message="",
		activeIndicator= BusinessLogicDao.queryExecutor.runDBQuery("JSON", query, "Is_Active_Ind");
		if(!activeIndicator.equalsIgnoreCase("Y"))
			message="Rider is switched Off";
		
		return message;
	}
	
	public String getRiderTermCalcCode(String riderCode){
		String query = "SELECT ISNULL(Term_Calc_Cd,'') AS 'Term_Calc_Cd'  "+ whereClause,
		termCalcCode= BusinessLogicDao.queryExecutor.runDBQuery("JSON", query, "Term_Calc_Cd");
		return termCalcCode;	
	}
	
	//Rider End
	
	//added by Prakhar for concurrency issue on 31Jan21
	public String getWhereClause() {
		return this.whereClause;
	}
	
	//added by Prakhar on 31Jan21 for rider where Clause set
	public void setWhereClause(String RiderType,String EffectiveDate) {
		String effectiveDateObj="";
		if(BusinessLogicDao.productType.equalsIgnoreCase("ULIP")){
			try {
				Date d1=new Date();
				effectiveDateObj = new SimpleDateFormat("yyyy-MM-dd").format(d1);
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}
		else
			effectiveDateObj = EffectiveDate;
		
		this.whereClause = " FROM NG_NB_MS_RIDER_BENEFIT_SET_UP(NOLOCK) WHERE Plan_Code='"
				+ RiderType + "' AND Channel='" + this.channel + "' AND Sub_Channel='"
				+ this.subChannel + "' and '"+effectiveDateObj+"' between rider_effective_Date and rider_Expiry_Date ";
	}

}

//Check whether row exists in Table or not
/*
class RowExistance extends BusinessLogicDao {
	String param,returnVal,query,columnName;
	
	public void setRowExistance(String param,String queryId){
		if(queryId.equals("1")){
			query="SELECT ISNULL(Rider_Type,'') AS 'Rider_Type' FROM NG_NB_MS_RIDER_BENEFIT_CODE_DESC(NOLOCK) WHERE Rider_Code='"+param+"'";
			columnName="Rider_Type";
		}
		else if(queryId.equals("2")){
			query="SELECT COUNT(*) AS 'Count' "+whereClause;
			columnName="Count";
		}
	}
	
	public void executeQuery(){
		returnVal=BusinessLogicDao.queryExecutor.runDBQuery("JSON", query, columnName);
	}
	
	public String getReturnVal() {
		return returnVal;
	}
}*/


class Funds {
	
	private static Logger logger = Logger.getLogger("Funds");

	String message;
	String message2;
	JSONArray fundsGridArr;
	String systematicTransferFund;
	String dynamicfundallocation;
	String lifeStylePortfolioStrateg;
	String lifecycleFund1;
	String lifecycleFund2;
	String triggerPortfolioStrategy;
	String trigger_Fund1;
	String trigger_Fund2;
	String planCode;
	String SystematicTransferFund;
	String TriggerPortfolioStrategy;
	String LifeStylePortfolioStrategy;
	String modeOfPayment;
	String movementPercentage;
	String whereClause="";
	
	public Funds(JSONArray fundsGridArr, String systematicTransferFund, String dynamicfundallocation,
			String lifeStylePortfolioStrateg, String lifecycleFund1, String lifecycleFund2,
			String triggerPortfolioStrategy, String trigger_Fund1, String trigger_Fund2, String planCode,
			String SystematicTransferFund, String TriggerPortfolioStrategy, String LifeStylePortfolioStrategy, String modeOfPayment,String movementPercentage,
			String whereClause) {
		super();
		this.whereClause=whereClause;
		this.fundsGridArr = fundsGridArr;
		this.systematicTransferFund = systematicTransferFund;
		this.dynamicfundallocation = dynamicfundallocation;
		this.lifeStylePortfolioStrateg = lifeStylePortfolioStrateg;
		this.lifecycleFund1 = lifecycleFund1;
		this.lifecycleFund2 = lifecycleFund2;
		this.triggerPortfolioStrategy = triggerPortfolioStrategy;
		this.trigger_Fund1 = trigger_Fund1;
		this.trigger_Fund2 = trigger_Fund2;
		this.planCode = planCode;
		this.SystematicTransferFund = SystematicTransferFund;
		this.TriggerPortfolioStrategy = TriggerPortfolioStrategy;
		this.LifeStylePortfolioStrategy = LifeStylePortfolioStrategy;
		this.modeOfPayment=modeOfPayment;
		this.movementPercentage=movementPercentage;

	}

	public void validateFunds() {
		message = "";
		message2 = "";
		String query = "";
		query = "SELECT Fund_Applicable" + whereClause;
		String Fund_Applicable = BusinessLogicDao.queryExecutor.runDBQuery(BusinessLogicDao.source, query,
				"Fund_Applicable");
		query = "SELECT STP_Applicable" + whereClause;
		String STP_Applicable = BusinessLogicDao.queryExecutor.runDBQuery(BusinessLogicDao.source, query,
				"STP_Applicable");
		query = "SELECT DFA_Applicable" + whereClause;
		String DFA_Applicable = BusinessLogicDao.queryExecutor.runDBQuery(BusinessLogicDao.source, query,
				"DFA_Applicable");
		query = "SELECT Lifecycle_Portfolio_Strategy" + whereClause;
		String Lifecycle_Portfolio_Strategy = BusinessLogicDao.queryExecutor.runDBQuery(BusinessLogicDao.source, query,
				"Lifecycle_Portfolio_Strategy");
		query = "SELECT Trigger_Based_Portfolio_Strategy" + whereClause;
		String Trigger_Based_Portfolio_Strategy = BusinessLogicDao.queryExecutor.runDBQuery(BusinessLogicDao.source,
				query, "Trigger_Based_Portfolio_Strategy");
		query = "SELECT ISNULL(Movement_Percentage,'') AS 'Movement_Percentage'" + whereClause;
		String movementPercentageApplicable = BusinessLogicDao.queryExecutor.runDBQuery(BusinessLogicDao.source,
				query, "Movement_Percentage");
		
		ArrayList<String> validFunds = new ArrayList<String>();
		if (Fund_Applicable.equalsIgnoreCase("Y"))
			validFunds.add("Fund_Applicable");
		if (STP_Applicable.equalsIgnoreCase("Y"))
			validFunds.add("STP_Applicable");
		if (DFA_Applicable.equalsIgnoreCase("Y"))
			validFunds.add("DFA_Applicable");
		if (Lifecycle_Portfolio_Strategy.equalsIgnoreCase("Y"))
			validFunds.add("Lifecycle_Portfolio_Strategy");
		if (Trigger_Based_Portfolio_Strategy.equalsIgnoreCase("Y"))
			validFunds.add("Trigger_Based_Portfolio_Strategy");

		ArrayList<String> selectedFunds = new ArrayList<String>();
		if (dynamicfundallocation.equalsIgnoreCase("Y"))
			selectedFunds.add("DFA_Applicable");
		if (SystematicTransferFund.equalsIgnoreCase("Y"))
			selectedFunds.add("STP_Applicable");
		if (TriggerPortfolioStrategy.equalsIgnoreCase("Y"))
			selectedFunds.add("Trigger_Based_Portfolio_Strategy");
		if (LifeStylePortfolioStrategy.equalsIgnoreCase("Y"))
			selectedFunds.add("Lifecycle_Portfolio_Strategy");

		boolean isBlankGrid = true;
		if (fundsGridArr.size() != 0) {
			for (Object fund : fundsGridArr) {
				JSONObject jsonObj = (JSONObject) fund;
				if ((!jsonObj.get("FundName").equals("") && !jsonObj.get("InitialAllocation").equals("0"))
						|| (!jsonObj.get("FundName").equals("") && !jsonObj.get("InitialAllocation").equals("0")))
					isBlankGrid = false;
			}
		}

		if (fundsGridArr.size() != 0 && !isBlankGrid)
			selectedFunds.add("Fund_Applicable");	//Manual Fund

		if ((selectedFunds.isEmpty() || !validFunds.containsAll(selectedFunds)) && !validFunds.isEmpty()) {
			logger.info("selectedFunds: " +selectedFunds);
			logger.info("validFunds: " +validFunds);
			message2 = "Valid fund has not been selected or inserted!";
		}
		
		if (validFunds.containsAll(selectedFunds) && selectedFunds.size()>1) {
			message2 = "More than one valid funds are selected";
		}

		if (message2.equals("")) {
			if (Fund_Applicable.equalsIgnoreCase("Y") && fundsGridArr.size() != 0 && selectedFunds.contains("Fund_Applicable") 
					&& !selectedFunds.contains("STP_Applicable")) {
				String fundApplicableQuery = "";
				if (selectedFunds.contains("Fund_Applicable")) {
					fundApplicableQuery = "SELECT FA.Fund_Code, FN.FUND_LABEL FROM NG_NB_MS_PLAN_FUND_ASSOC FA, NG_NB_MS_FUND_NAME FN "
							+ "WHERE FA.Plan_Code='" + planCode
							+ "' AND (FA.Fund_Applicable='Y') AND FA.Fund_Code=FN.FUND_VALUE";
				} 
//				if(selectedFunds.contains("STP_Applicable") && validFunds.contains("STP_Applicable")){ // STP_Applicable = Y
//					fundApplicableQuery = "SELECT FA.Fund_Code, FN.FUND_LABEL FROM NG_NB_MS_PLAN_FUND_ASSOC FA, NG_NB_MS_FUND_NAME FN "
//							+ "WHERE FA.Plan_Code='" + planCode
//							+ "' AND (FA.Fund_Applicable='Y' OR FA.STP_Fund='Y') AND FA.Fund_Code=FN.FUND_VALUE";
//				}
				Map<String, String> hm = new HashMap<String, String>();
				hm = BusinessLogicDao.queryExecutor.runFundsQuery(BusinessLogicDao.source, fundApplicableQuery);
				// hm-> UEBL1:Balanced Fund-Pr Driven
				boolean isInvalid = false;
				if (!hm.isEmpty()) {
					for (Object fund : fundsGridArr) {
						JSONObject jsonObj = (JSONObject) fund;
						if (!jsonObj.get("FundName").equals("") && !jsonObj.get("InitialAllocation").equals("0")) {
							if (!hm.keySet().contains(jsonObj.get("FundName"))) {
								isInvalid = true;
							}
						}
					}
					if (isInvalid) {
						message = "Invalid Fund is present in the grid. Please select the valid funds: " + hm.keySet();
					}
					int allocation=0;
					if(!isInvalid) {	//funds are valid
						for (Object fund : fundsGridArr) {
							JSONObject jsonObj = (JSONObject) fund;
							if (!jsonObj.get("FundName").equals("") && !jsonObj.get("InitialAllocation").equals("")) {
							String allocationStr = 	(String) jsonObj.get("InitialAllocation");	
							if(allocationStr.equals(""))
								allocationStr="0";
							allocation = allocation + Integer.parseInt(allocationStr);						
							}
						}
						if(allocation!=100)
							message = "Total Allocated funds should be 100" ;
					}
				}else{
					message = "No Valid Fund found in MDM for given plan." ;
				}

			}

//			if (STP_Applicable.equalsIgnoreCase("Y") && fundsGridArr.size() != 0 && selectedFunds.contains("STP_Applicable")) {
//				String STP_ApplicableQuery = "SELECT FA.Fund_Code, FN.FUND_LABEL FROM NG_NB_MS_PLAN_FUND_ASSOC FA, NG_NB_MS_FUND_NAME FN "
//						+ "WHERE FA.Plan_Code='" + planCode + "' AND FA.STP_Fund='Y' AND FA.Fund_Code=FN.FUND_VALUE";
//				Map<String, String> hm = new HashMap<String, String>();
//				hm = BusinessLogicDao.queryExecutor.runFundsQuery(BusinessLogicDao.source, STP_ApplicableQuery);
//				// hm-> UEBL1:Balanced Fund-Pr Driven
//				boolean isInvalid = true;
//				if (!hm.isEmpty()) {
//					for (Object fund : fundsGridArr) {
//						JSONObject jsonObj = (JSONObject) fund;
//						if (!jsonObj.get("FundName").equals("") && !jsonObj.get("InitialAllocation").equals("0")) {
//							if (hm.keySet().contains(jsonObj.get("FundName"))) {
//								isInvalid = false;
//							}
//						}
//					}
//					if (isInvalid) {
//						message = message + " Valid STP fund is not present. Valid STP funds are: " + hm.keySet();
//					}
//				}
//			}

			if (DFA_Applicable.equalsIgnoreCase("Y") && dynamicfundallocation.equals("Y")) {
				if (dynamicfundallocation.equalsIgnoreCase("")) {
					message = message + " Please correct the Dynamicfundallocation value.";
				}
			}

			if (Lifecycle_Portfolio_Strategy.equalsIgnoreCase("Y")
					&& LifeStylePortfolioStrategy.equalsIgnoreCase("Y")) {
				String lifeCycleQuery = "SELECT FA.Fund_Code, FN.FUND_LABEL FROM NG_NB_MS_PLAN_FUND_ASSOC FA, NG_NB_MS_FUND_NAME FN "
						+ "WHERE FA.Plan_Code='" + planCode
						+ "' AND (FA.Lifecycle_Fund_Details='Y' OR FA.Lifecycle_Fund_Details_2='Y') AND FA.Fund_Code=FN.FUND_VALUE";
				Map<String, String> hm = new HashMap<String, String>();
				hm = BusinessLogicDao.queryExecutor.runFundsQuery(BusinessLogicDao.source, lifeCycleQuery);
				boolean isInvalid = false;
				if (!hm.isEmpty()) {
					if (!hm.keySet().contains(lifecycleFund1))
						isInvalid = true;
					if (!hm.keySet().contains(lifecycleFund2))
						isInvalid = true;
					if (isInvalid) {
						message = message + " Please select the valid Lifecycle Funds (Fund1 and Fund2) funds: "
								+ hm.keySet();
					}
				}
			}

			if (Trigger_Based_Portfolio_Strategy.equalsIgnoreCase("Y") && TriggerPortfolioStrategy.equals("Y")) {
				String triggerFundeQuery = "SELECT FA.Fund_Code, FN.FUND_LABEL FROM NG_NB_MS_PLAN_FUND_ASSOC FA, NG_NB_MS_FUND_NAME FN "
						+ "WHERE FA.Plan_Code='" + planCode
						+ "' AND (FA.Trigger_Based_Fund_Details='Y' OR FA.Trigger_Based_Fund_Details_2='Y' )"
						+ "	 AND FA.Fund_Code=FN.FUND_VALUE";
				Map<String, String> hm = new HashMap<String, String>();
				hm = BusinessLogicDao.queryExecutor.runFundsQuery(BusinessLogicDao.source, triggerFundeQuery);
				boolean isInvalid = false;
				if (!hm.isEmpty()) {
					if (!hm.keySet().contains(trigger_Fund1))
						isInvalid = true;
					if (!hm.keySet().contains(trigger_Fund2))
						isInvalid = true;
					if (isInvalid) {
						message = message
								+ " Please select the valid Trigger Portfolio Funds (Trigger_Fund1 and Trigger_Fund2) funds: "
								+ hm.keySet();
					}
				}
			}
			
			//validate STP if mode of payment is not annual
			if(SystematicTransferFund.equalsIgnoreCase("Y")) {
				if(!modeOfPayment.equals("12")) {
					message=message+"STP Fund can not be selected for Mode of Payment other than Annual!";
				}
			}
			
			if(Trigger_Based_Portfolio_Strategy.equalsIgnoreCase("Y") && TriggerPortfolioStrategy.equalsIgnoreCase("Y")
					&& !movementPercentageApplicable.equalsIgnoreCase("") && movementPercentage.equalsIgnoreCase("")){
				message=message+" Please provide Movement Percentage!";
			}
			
		}

	}

	public String getMessage() {
		if (!message2.equals(""))
			return message2;
		return message;
	}

}

class Riders {
	JSONArray riderDetailsArr;
	Date effectiveDateOfCov;
	Date CustomerSignDate;
	String message;
	String whereClause,productDating;

	public Riders(JSONArray riderDetailsArr,String effectiveDate,String customerSigndDte,String whereClause,String productDating) {
		this.riderDetailsArr = riderDetailsArr;
		this.whereClause=whereClause;
		this.productDating=productDating;
		
		try {
			this.effectiveDateOfCov=new SimpleDateFormat("yyyy-MM-dd").parse(effectiveDate);
			this.CustomerSignDate=new SimpleDateFormat("yyyy-MM-dd").parse(customerSigndDte);
		} catch (ParseException e) {
			e.printStackTrace();
			this.effectiveDateOfCov=new Date();
			this.CustomerSignDate=new Date();
		};
		
	}

	void validateRiders() {
		message = "";
		ArrayList<String> invalidRiders = new ArrayList<String>();
		HashMap<String, String> riderHashMap=new HashMap<>();
		String rider,isMandatory,effectiveDate,expiryDate,jsonRider;
		Date riderEffectiveDate,riderExpiryDate;
		int limit=10;
		if(BusinessLogicDao.productType.equalsIgnoreCase("ULIP"))
		{
			limit=20;
		}
		for (int i = 1; i <= 20; i++) {
			String riderQuery = "SELECT ISNULL(Riders" + i + ",'') AS 'Riders',ISNULL(Is_Rider"+i+"_Mandatory,'') AS 'Is_Rider_Mandatory',"
					+ "CONVERT(VARCHAR,ISNULL(Rider"+i+"_Expiry_Plan,''),101) AS 'Rider_Expiry_Plan',"
					+ "CONVERT(VARCHAR,ISNULL(Rider"+i+"_Effective_Plan,''),101) AS 'Rider_Effective_Plan'" 
					+ whereClause + " AND Is_Active_Rider" + i
					+ "='Y' ";
			riderHashMap = BusinessLogicDao.queryExecutor.runRiderQuery(riderQuery,BusinessLogicDao.source);
			
			if(!riderHashMap.isEmpty()){
				rider=riderHashMap.get("Riders");
				isMandatory=riderHashMap.get("Is_Rider_Mandatory");
				effectiveDate=riderHashMap.get("Rider_Effective_Plan");
				expiryDate=riderHashMap.get("Rider_Expiry_Plan");
				
				for (Object obj : riderDetailsArr) {
					JSONObject jsonObj = (JSONObject) obj;
					jsonRider=jsonObj.getOrDefault("RiderType","").toString();
					if(jsonRider.equalsIgnoreCase(rider) && isMandatory.equalsIgnoreCase("N")){
						
						try {
							riderEffectiveDate=new SimpleDateFormat("MM/dd/yyyy").parse(effectiveDate);
							riderExpiryDate=new SimpleDateFormat("MM/dd/yyyy").parse(expiryDate);
						} catch (ParseException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
							riderEffectiveDate=new Date();
							riderExpiryDate=new Date();
						}
						
						if(productDating.equalsIgnoreCase("ED") && (effectiveDateOfCov.before(riderEffectiveDate) ||  
								effectiveDateOfCov.after(riderExpiryDate))){
							message+=jsonRider+" Rider is not Effective or Expired!";
							
						}
						else if(productDating.equalsIgnoreCase("CD") && (effectiveDateOfCov.before(riderEffectiveDate) ||  
								CustomerSignDate.after(riderExpiryDate))){
							message+=jsonRider+" Rider is not Effective or Expired!";
						}
					}
				}
			}
			
			/*for (Object obj : riderDetailsArr) {
				JSONObject jsonObj = (JSONObject) obj;

				// if (k != 0 && k != 1) { // skipping first and second riders.
				if (!jsonObj.get("RiderType").equals("")) {
					if (!rider.equals(""))
						if (!rider.equals(jsonObj.get("RiderType").toString()))
							invalidRiders.add((String) jsonObj.get("RiderType"));
				}
				// }
				// k++;
			}
		}
		if (!invalidRiders.isEmpty())
			message = "Invalid/Inactive Riders present: " + invalidRiders;*/
	}
		
		//added by Aanchal
		
		for (Object obj : riderDetailsArr) {
			JSONObject jsonObj = (JSONObject) obj;
			String ridermatch="N";
			for (int i = 1; i <= 20; i++) {
			String riderQuery = "SELECT ISNULL(Riders" + i + ",'') AS 'Riders',ISNULL(Is_Rider"+i+"_Mandatory,'') AS 'Is_Rider_Mandatory',"
					+ "CONVERT(VARCHAR,ISNULL(Rider"+i+"_Expiry_Plan,''),101) AS 'Rider_Expiry_Plan',"
					+ "CONVERT(VARCHAR,ISNULL(Rider"+i+"_Effective_Plan,''),101) AS 'Rider_Effective_Plan'" 
					+ whereClause + " AND Is_Active_Rider" + i
					+ "='Y' ";
			riderHashMap = BusinessLogicDao.queryExecutor.runRiderQuery(riderQuery,BusinessLogicDao.source);
			
			
			// if (k != 0 && k != 1) { // skipping first and second riders.
			if(!riderHashMap.isEmpty()){
				rider=riderHashMap.get("Riders");
					if (!jsonObj.get("RiderType").equals("")) {
						if (!rider.equals(""))
							if (rider.equals(jsonObj.get("RiderType").toString()))
								ridermatch="Y";
								
					}
			}
			}
			if(ridermatch.equals("N"))
			{
				invalidRiders.add((String) jsonObj.get("RiderType"));
			}
				
			// 
			// k++;
		}
		if (!invalidRiders.isEmpty())
			message = "Invalid/Inactive Riders present: " + invalidRiders;
		
		}
	
	//added by Aanchal

	public String getMessage() {
		return message;
	}

}

class BenefitRiders {
	JSONArray riderDetailsArr;
	String message="";
	String whereClause;

	public BenefitRiders(JSONArray riderDetailsArr, String whereClause) {
		this.riderDetailsArr = riderDetailsArr;
		this.whereClause=whereClause;
	}

	void validateRiders() {
		//message = "";
		Map<String, String> hm = new HashMap<String, String>();
		String benefit1Query = "SELECT Benefit1" + whereClause
				+ " AND Is_Active_Benefit1='Y' AND Is_Benefit1_Mandatory='Y'";
		String Benefit1 = BusinessLogicDao.queryExecutor.runDBQuery(BusinessLogicDao.source, benefit1Query, "Benefit1");
		String benefit2Query = "SELECT Benefit2" + whereClause
				+ " AND Is_Active_Benefit2='Y' AND Is_Benefit2_Mandatory='Y'";
		String Benefit2 = BusinessLogicDao.queryExecutor.runDBQuery(BusinessLogicDao.source, benefit2Query, "Benefit2");
		Boolean isValidBenefit1 = false;
		Boolean isValidBenefit2 = false;
		for (Object obj : riderDetailsArr) {
			JSONObject jsonObj = (JSONObject) obj;

			if (!Benefit1.equals(""))
				if (jsonObj.get("RiderType").equals(Benefit1))
					isValidBenefit1 = true;

			if (!Benefit2.equals(""))
				if (jsonObj.get("RiderType").equals(Benefit2))
					isValidBenefit2 = true;
		}
		if (!isValidBenefit1 && !Benefit1.equals(""))
			this.message = "Benefit Rider not present: " + Benefit1;

		if (!isValidBenefit2 && !Benefit2.equals(""))
			this.message = "Benefit Rider not present: " + Benefit2;

		if (!isValidBenefit1 && !isValidBenefit2 && !Benefit1.equalsIgnoreCase("") && !Benefit2.equalsIgnoreCase(""))
			this.message = "Valid Benefit Riders not present: " + Benefit1 + "," + Benefit2;

	}

	public String getMessage() {
		return this.message;
	}
}

class PlanPayOptionCode {
	String premiumPaymentTerm;
	String coverageTerm;
	String message="",whereClause;

	public PlanPayOptionCode(String premiumPaymentTerm, String coverageTerm, String whereClause) {
		this.premiumPaymentTerm = premiumPaymentTerm;
		this.coverageTerm = coverageTerm;
		this.whereClause = whereClause;
	}

	public void validateField() {
		message = "";

		String query = "SELECT Plan_Pay_Option_Code_Desc" + whereClause;
		String Plan_Pay_Option_Code_Desc = BusinessLogicDao.queryExecutor.runDBQuery(BusinessLogicDao.source, query,
				"Plan_Pay_Option_Code_Desc");

		if (Plan_Pay_Option_Code_Desc.equalsIgnoreCase("RGLR")) {
			if (Float.parseFloat(premiumPaymentTerm) != Float.parseFloat(coverageTerm))
				message = "Premium Payment Term and Coverage Term should be same as the Plan Pay Option Code is RGLR.";
		} else if (Plan_Pay_Option_Code_Desc.equalsIgnoreCase("LTD")
				|| Plan_Pay_Option_Code_Desc.equalsIgnoreCase("SNGL")) {
			if (Float.parseFloat(premiumPaymentTerm) == Float.parseFloat(coverageTerm))
				message = "Premium Payment Term and Coverage Term can not be same as the Plan Pay Option Code is LTD/SNGL.";
		}

	}

	public String getMessage() {
		return this.message;
	}
}

class CoverageMultiple {
	String fieldValue;
	String coverageTerm;
	String propDOB;
	String effectiveDate;
	String message;
	String whereClause;
	String productDating;
	String planCode; // by mansi dr-39228
	
	public CoverageMultiple(String fieldValue, String coverageTerm, String propDOB,String effectiveDate, String whereClause, String productDating, String planCode) {
		this.fieldValue = fieldValue;
		this.coverageTerm = coverageTerm;
		this.propDOB = propDOB;
		this.effectiveDate = effectiveDate;
		this.whereClause = whereClause;
		this.productDating = productDating;
		this.planCode= planCode; // by mansi dr-39228
	}

	public void validateField() {
		message = "";
		String query = "SELECT Is_Cover_Multiple_App" + whereClause;
		String isCoverMultipleAppQuery = BusinessLogicDao.queryExecutor.runDBQuery(BusinessLogicDao.source, query,
				"Is_Cover_Multiple_App");
		query = "SELECT Dur_Typ_Cd" + whereClause;
		String Dur_Typ_Cd = BusinessLogicDao.queryExecutor.runDBQuery(BusinessLogicDao.source, query, "Dur_Typ_Cd");
		ArrayList<String> Cover_Multiple = new ArrayList<String>();
		query = "SELECT Cover_Multiple" + whereClause;
		Cover_Multiple = BusinessLogicDao.queryExecutor.runCoverMultipleQuery(query, BusinessLogicDao.source); // return
																												// list
																												// of
																												// Cover_Multiple
																												// from
																												// MDM
		String propAge = BusinessLogicDao.CalculateYears(propDOB,effectiveDate,productDating);

		if (isCoverMultipleAppQuery.equals("Y")) {
			if (Dur_Typ_Cd.equals("N")) {
				if (!Cover_Multiple.contains(fieldValue))
					message = "Please enter the correct value. Valid value are: " + Cover_Multiple;
			} 
			else if (Dur_Typ_Cd.equals("A")) {
				
					message = "";
			}
			else { // if Dur_Typ_Cd is Y -> then e have to check the table ->
						// NG_NB_MS_MIN_MAX_COVER_MULTIPLE
				Map<String, String> hm = new HashMap<>();
				Boolean matched = false;
				query = "SELECT Minimum_Cov_Mul, Maximum_Cov_Mul FROM NG_NB_MS_MIN_MAX_COVER_MULTIPLE(NOLOCK) WHERE "
						+ "MIN_TERM<=" + coverageTerm + " AND MAX_TERM>=" + coverageTerm + " " + "AND AGE_DURATION="
						+ propAge; //+" AND PLAN_CODE='"+planCode+"'"; // by mansi dr-39228
				hm = BusinessLogicDao.queryExecutor.runMinMaxCovMulQuery(query, BusinessLogicDao.source);
				String Minimum_Cov_Mul = hm.get("Minimum_Cov_Mul"); // float
				String Maximum_Cov_Mul = hm.get("Maximum_Cov_Mul"); // float

				for (String cover_multiple : Cover_Multiple) {

					if (Float.parseFloat(cover_multiple) >= Float.parseFloat(Minimum_Cov_Mul)
							&& Float.parseFloat(cover_multiple) <= Float.parseFloat(Maximum_Cov_Mul)) {
						if (cover_multiple.equals(fieldValue))
							matched = true;
					}
				}
				if (!matched)
					message = "Please enter the correct value.";
			}
		} else
			message = "";
	}

	public String getResult() {
		return message;
	}

}

class CheckFieldVisible {
	String fieldValue;
	String mdmColName;
	String whereClause;

	public CheckFieldVisible(String fieldValue, String mdmColName, String whereClause) {
		this.fieldValue = fieldValue;
		this.mdmColName = mdmColName;
		this.whereClause=whereClause;
	}

	public boolean isVisible() {

		String query = "SELECT " + mdmColName + whereClause;
		String result = BusinessLogicDao.queryExecutor.runIsVisibleQuery(query, BusinessLogicDao.source, mdmColName);

		if(mdmColName.equalsIgnoreCase("Income_Frequency")){
			if(!result.equalsIgnoreCase("") && fieldValue.equals("")){
				return true;
			}
			return false;	
		}
		else if (!result.equals(""))
			if (result.equalsIgnoreCase("Y") && fieldValue.equals("")) // field is blank but in mdm its Y then error
																		// will be thrown
				return true;
		return false;
	}
}

class Discount {
	String discount;
	String discountType,whereClause;

	public Discount(String discount, String discountType, String whereClause) {
		this.discount = discount;
		this.discountType = discountType;
		this.whereClause=whereClause;
	}

	public boolean isApplicable() {

		String query = "SELECT Discount" + whereClause;
		ArrayList list = new ArrayList();
		list = BusinessLogicDao.queryExecutor.runDiscountQuery(query, BusinessLogicDao.source);

		if (!list.isEmpty())
			if (list.contains(discountType) && discount.equals(""))
				return true;

		return false;
	}
}

class IssueAge {
	static Logger logger = Logger.getLogger(BusinessLogicDao.class.getName());
	String insuredDob;
	String propDOB;
	String coverageTerm;
	String message = "";
	String effectiveDate = "1900-01-01";
	String whereClause,productDating;
	
	public IssueAge(String insuredDob,String propDOB, String coverageTerm, String effectiveDate, String whereClause, String productDating) {
		this.insuredDob = insuredDob;
		this.coverageTerm = coverageTerm;
		this.effectiveDate = effectiveDate;
		this.whereClause=whereClause;
		this.productDating=productDating;
		this.propDOB=propDOB;
	}

	void validateField() {
		message = "";
		String ageOfInsured = BusinessLogicDao.CalculateYears(insuredDob, effectiveDate,productDating);
		Map<String, String> hm = new HashMap<>();
		logger.info("logger4:validateField: "+ageOfInsured);
		
		String query = "SELECT ISNULL(Min_Issue_Age,0) AS 'Min_Issue_Age',ISNULL(Max_Issue_Age,0) AS 'Max_Issue_Age' ,"
				+ "ISNULL(Minimum_Expiry_Age,0) AS 'Minimum_Expiry_Age' ,ISNULL(Maximum_Expiry_Age,0) AS 'Maximum_Expiry_Age',ISNULL(Term_Calc_Cd,'') AS 'Term_Calc_Cd'"
				+ whereClause;
		hm = BusinessLogicDao.queryExecutor.runIssueAgeQuery(query, BusinessLogicDao.source);
		if(hm.get("Min_Issue_Age").equalsIgnoreCase("") || hm.get("Min_Issue_Age").isEmpty()  )
		{
			 query = "SELECT ISNULL(Min_Issue_Age,0) AS 'Min_Issue_Age',ISNULL(Max_Issue_Age,0) AS 'Max_Issue_Age' ,"
					+ "ISNULL(Minimum_Expiry_Age,0) AS 'Minimum_Expiry_Age' ,ISNULL(Maximum_Expiry_Age,0) AS 'Maximum_Expiry_Age',ISNULL(Term_Calc_Code,'') AS 'Term_Calc_Cd'"
					+ whereClause;
			hm = BusinessLogicDao.queryExecutor.runIssueAgeQuery(query, BusinessLogicDao.source);
		}
		
		logger.info("logger5:validateField: "+query);
		logger.info("logger6:validateField: "+hm);
		logger.info("logger6:validateField: "+whereClause);
	
		if (hm != null) {
			String minimunIssueAge = hm.getOrDefault("Min_Issue_Age", "0");
			String maximumIssueAge = hm.get("Max_Issue_Age");
			String termcalcd=hm.get("Term_Calc_Cd");
			if(termcalcd.equalsIgnoreCase("PCALC"))
			{
				ageOfInsured=BusinessLogicDao.CalculateYears(propDOB, effectiveDate,productDating);
			}
			if (minimunIssueAge != null && maximumIssueAge != null) {
				if (Integer.parseInt(ageOfInsured) < Integer.parseInt(minimunIssueAge)
						|| Integer.parseInt(ageOfInsured) > Integer.parseInt(maximumIssueAge)) {
					message += "Age of Insured/Proposer must lie between " + minimunIssueAge + " and " + maximumIssueAge
							+ ". Please correct!  ";
					// ifr.setValue("Q_L2BI_DETAILS.DOB", "");
				}
			}
			
			logger.info("logger7:validateField: "+minimunIssueAge);
			logger.info("logger8:validateField: "+maximumIssueAge);
			logger.info("logger9:validateField: "+termcalcd);
			logger.info("logger10:validateField: "+ageOfInsured);
			logger.info("logger10:validateField: "+message);

			// Expiry Age check
			String Min_Expiry_Age = "", Max_Expiry_Age = "";
			Min_Expiry_Age = hm.get("Minimum_Expiry_Age");
			Max_Expiry_Age = hm.get("Maximum_Expiry_Age");
			if (Min_Expiry_Age != null && Max_Expiry_Age != null) {
				if (!coverageTerm.equalsIgnoreCase("") && !Min_Expiry_Age.equalsIgnoreCase("")
						&& !Max_Expiry_Age.equalsIgnoreCase("")) {
					if (Integer.parseInt(coverageTerm) + Integer.parseInt(ageOfInsured) < Integer
							.parseInt(Min_Expiry_Age)
							|| Integer.parseInt(coverageTerm) + Integer.parseInt(ageOfInsured) > Integer
									.parseInt(Max_Expiry_Age)) {
						message += "Expiry Age must lie between " + Min_Expiry_Age + " and " + Max_Expiry_Age
								+ ". Please correct!";
						// ifr.setValue("Q_L2BI_DETAILS.DOB", "");
					}
				}
			}
		}

	}

	public String getResult() {
		return message;
	}
}

/**
 * Logic for Effective Date
 * 
 * @author prakhar.saxena
 *
 */
class EffectiveDate {
	String effectiveDate;
	String customerSignDate;
	String message = "",whereClause;

	public EffectiveDate(String effectiveDate,String customerSignDate, String whereClause) {
		this.effectiveDate = effectiveDate;
		this.customerSignDate = customerSignDate;
		this.whereClause=whereClause;
	}

	void validateField() {
		message = "";
		String query = "SELECT ISNULL(Plan_Effective_Date,'') AS 'Plan_Effective_Date',ISNULL(Channel_Effective_Date,'') AS 'Channel_Effective_Date',"
				+ "ISNULL(Plan_Expiry_Date,'') AS 'Plan_Expiry_Date', ISNULL(Product_Dating,'') AS 'Product_Dating' "
				+ whereClause;
		EffectiveDateResult effectiveDateResult = BusinessLogicDao.queryExecutor.runEffectiveDateQuery(query,
				BusinessLogicDao.source);

		if (effectiveDateResult != null) {
			String planEffectiveDate = effectiveDateResult.getPlanEffectiveDate();
			String channelEffectiveDate = effectiveDateResult.getChannelEffectiveDate();
			String planExpiryDate = effectiveDateResult.getPlanExpiryDate();
			String Product_Dating = effectiveDateResult.getProduct_Dating();
			
			Date effectiveDateObj=null,customerSignDateObj=null ;
			
			
			//TRAD follows EDC and ULIP is current dating
			if(BusinessLogicDao.productType.equalsIgnoreCase("TRAD")){
				try {
					effectiveDateObj = new SimpleDateFormat("yyyy-MM-dd").parse(effectiveDate);
				} catch (ParseException e1) {
					e1.printStackTrace();
				}
			}
			else
				effectiveDateObj = new Date();
			
			Date planEffectiveDateObj = null;
			Date channelEffectiveDateObj = null;
			Date planExpiryDateObj = null;
			try {
				//effectiveDateObj = new SimpleDateFormat("yyyy-MM-dd").parse(effectiveDate);
				planEffectiveDateObj = new SimpleDateFormat("yyyy-MM-dd").parse(planEffectiveDate);
				channelEffectiveDateObj = new SimpleDateFormat("yyyy-MM-dd").parse(channelEffectiveDate);
				planExpiryDateObj = new SimpleDateFormat("yyyy-MM-dd").parse(planExpiryDate);
				
				customerSignDateObj = new SimpleDateFormat("yyyy-MM-dd").parse(customerSignDate);
				
				if(Product_Dating.equalsIgnoreCase("CD"))
					effectiveDateObj=customerSignDateObj;
				
				if (effectiveDateObj.before(planEffectiveDateObj) || effectiveDateObj.after(planExpiryDateObj)) {
					message = "Effective/Customer Sign Date Should lie between Plan Effective Date: " + planEffectiveDate
							+ " and Plan Expiry Date: " + planExpiryDate + " Please Correct!  ";
//		                ifr.setValue("Q_COVERAGE_DETAILS.EFFECTIVE_DATE", "");
				}
				if (effectiveDateObj.before(channelEffectiveDateObj) || effectiveDateObj.after(planExpiryDateObj)) {
					message += "Effective/Customer Sign Date Should lie between Channel Effective Date: " + channelEffectiveDate
							+ " and Plan Expiry Date: " + planExpiryDate + " Please Correct!";
//		                ifr.setValue("Q_COVERAGE_DETAILS.EFFECTIVE_DATE", "");
				}
			} catch (ParseException e) {
				message = "";
				e.printStackTrace();
			}

		}
	}

	public String getResult() {
		return message;
	}
}

/**
 * Logic for Sum Assured
 * 
 * @author prakhar.saxena
 *
 */
class SumAssured {
	String fieldValue;
	String minAmount;
	String maxAmount;
	String message = "";
	String CoverageMultiple = "";
	String ATP = "";
	String riderClass;
	String baseSA,whereClause,riderFlag;
	String ExactIncome="";
	String planCode; //Added by sparsh for fund issues
	
	public SumAssured(String fieldValue,String CoverageMultiple,String ATP,String riderClass, String  baseSA, String whereClause, String riderFlag, String planCode, String ExactIncome) {
		this.fieldValue = fieldValue;
		this.CoverageMultiple = CoverageMultiple;
		this.ATP = ATP;
		this.riderClass = riderClass;
		this.baseSA = baseSA;
		this.whereClause=whereClause;
		this.riderFlag=riderFlag;
		this.ExactIncome=ExactIncome;
		this.planCode=planCode; //Added by sparsh for fund issues
	}

	public void validateField() {
		message = "";
//		MinMaxValues query = queryExecutor.runMinMaxQuery(
//				"SELECT Minimum_Issue_Age, Max_Issue_Age"+BusinessLogicDao.whereClause, BusinessLogicDao.source, "Minimum_Issue_Age", "Max_Issue_Age");
		double intervalValue,sumAssured;
		String query = "SELECT ISNULL(Min_Issue_Amount,0) AS 'Min_Issue_Amount',ISNULL(Max_Issue_Amount,0) AS 'Max_Issue_Amount',"
				+ "ISNULL(Interval,0) AS 'Interval'" + whereClause;

		MinMaxValues minMaxValues = BusinessLogicDao.queryExecutor.runMinMaxQuery(query, BusinessLogicDao.source,
				"Min_Issue_Amount", "Max_Issue_Amount","Interval");
		
		String quer1 = "SELECT ISNULL(RIDER_MAX_SA_LOGIC_CODE,'') AS 'RIDER_MAX_SA_LOGIC_CODE',ISNULL(RIDER_MAX_SA_FORMULA_VALUES,'') AS 'RIDER_MAX_SA_FORMULA_VALUES',"
				 + whereClause;
		
		RIDERLOGIC riderLogic = BusinessLogicDao.queryExecutor.riderLogic(query, BusinessLogicDao.source,
				"RIDER_MAX_SA_LOGIC_CODE", "RIDER_MAX_SA_FORMULA_VALUES");
		double maxSA=0.0;
		String riderLogics="";
		if((BusinessLogicDao.productType.equalsIgnoreCase("ULIP"))
				&& ((planCode.equalsIgnoreCase("UFISFL")) || (planCode.equalsIgnoreCase("UFISFR"))
						||  (planCode.equalsIgnoreCase("UFINFL")) ||  (planCode.equalsIgnoreCase("UFINFL"))) )
		{
			if(riderLogic.RIDER_MAX_SA_LOGIC_CODE.equalsIgnoreCase("LEIBSA"))
			{
				//aan12345
				double baseSumAssured1;
				 String[] riderLogicVALUES = riderLogic.RIDER_MAX_SA_FORMULA_VALUES.split(",");
                 
                 String firstValue= riderLogicVALUES[0];
                 String secondValue= riderLogicVALUES[0];
                 
                 double FV = Double.parseDouble(firstValue);
                 double SV = Double.parseDouble(secondValue);
                 double EI=Double.parseDouble(ExactIncome);
                 riderLogics="Y";
                 
                 baseSumAssured1 = baseSA.isEmpty() ? 0 : Double.parseDouble(baseSA);
                 baseSumAssured1 = 20 * baseSumAssured1 / 100;
                   
                   EI=5 * EI;
                   
                   maxSA=Math.min(baseSumAssured1, EI); 
			}
		}
		//Logic for CI rider
		if(riderFlag.equalsIgnoreCase("Y") && riderClass.equalsIgnoreCase("CI")){
			double baseSumAssured,maximumIssueAmount;			    
			baseSumAssured = baseSA.isEmpty() ? 0 : Double.parseDouble(baseSA);
			maximumIssueAmount = minMaxValues.maxValue.isEmpty() ? 0 : Double.parseDouble(minMaxValues.maxValue);
			baseSumAssured = 50 * baseSumAssured / 100;
            maximumIssueAmount = Math.min(baseSumAssured, maximumIssueAmount);
            minMaxValues.maxValue=String.valueOf(maximumIssueAmount);
		}
		
		if(riderLogics.equalsIgnoreCase("Y"))
		{
			 minMaxValues.maxValue=String.valueOf(maxSA);
		}
		
		if (!minMaxValues.minValue.equals("") && !minMaxValues.maxValue.equals(""))
			if (Double.parseDouble(fieldValue) < Double.parseDouble(minMaxValues.minValue)
					|| Double.parseDouble(fieldValue) > Double.parseDouble(minMaxValues.maxValue))
				message = "Please enter the Sum Assured between " + minMaxValues.minValue + " and "
						+ minMaxValues.maxValue;
		
		if((!(planCode.equalsIgnoreCase("UFISFL"))) && (!(planCode.equalsIgnoreCase("UFISFR"))) 
				&& (!(planCode.equalsIgnoreCase("UFINFL")))  && (!(planCode.equalsIgnoreCase("UFINFR"))) )
		{
		if(BusinessLogicDao.productType.equalsIgnoreCase("ULIP") && !riderFlag.equalsIgnoreCase("Y")){
			if(!CoverageMultiple.equals("") && !ATP.equals("") && !fieldValue.equals("")){
				Double calculatedSumAssured= Double.parseDouble(CoverageMultiple)*Double.parseDouble(ATP);
				Double actualSumAssured= Double.parseDouble(fieldValue);
				if(!actualSumAssured.equals(calculatedSumAssured))
					message=", SumAssured is not equal to product of CoverageMultiple and ATP,";
			}else
				message=", CoverageMultiple/ATP/SumAssured is blank,";
			
		}
		}
		 intervalValue = Double.parseDouble(minMaxValues.Interval);
		 if (intervalValue != 0 && riderFlag.equalsIgnoreCase("Y")) {
			 sumAssured=Double.parseDouble(fieldValue);
             if (sumAssured % intervalValue != 0) {
            	 message += ",  Issue amount should be multiple of " + minMaxValues.Interval + "!";
             }
         }
		
		
	}

	public String getResult() {
		return message;
	}
}

/**
 * Logic for Coverage Term
 * 
 * @author prakhar.saxena
 *
 */
class CoverageTerm {
	String coverageTerm;
	String insuredDOB;
	String effectiveDate;
	
	String Plan_Age_Expiry;
	String Term_CalC_Code;
	String Min_Term;
	String Max_Term;
	String Min_Expiry_Age;
	String Max_Expiry_Age,whereClause,productDating;

	String message = "";

	public CoverageTerm(String coverageTerm, String insuredDOB,String effectiveDate, String whereClause, String productDating) {
		this.coverageTerm = coverageTerm;
		this.insuredDOB = insuredDOB;
		this.effectiveDate = effectiveDate;
		this.whereClause=whereClause;
		this.productDating=productDating;
	}

	public void validateField() {
		String ageOfInsured = "";
		String term_calc_desc = "";
		message = "";
		String query = "SELECT ISNULL(Plan_Age_Expiry,0) AS 'Plan_Age_Expiry', ISNULL(Term_CalC_Code,'') AS 'Term_CalC_Code', "
				+ "ISNULL(Minimum_Term,'0') AS 'Minimum_Term', ISNULL(Maximum_Term,0) AS 'Maximum_Term',ISNULL(Minimum_Expiry_Age,0) AS 'Minimum_Expiry_Age',"
				+ "ISNULL(Maximum_Expiry_Age ,0) AS 'Maximum_Expiry_Age'"
				+ whereClause;
		BusinessLogicDao.logger.info("query: " + query);
		Map<String, String> hm = new HashMap<>();
		hm = BusinessLogicDao.queryExecutor.runCoverageTermQuery(query, BusinessLogicDao.source);

		// Calculating insured age
		if (!insuredDOB.equalsIgnoreCase("")) {
			ageOfInsured = BusinessLogicDao.CalculateYears(insuredDOB,effectiveDate,productDating);
		}

		// Logic
		if (hm.get("Term_CalC_Code").equalsIgnoreCase("A")) {
			if (!coverageTerm.equalsIgnoreCase("") && !hm.get("Minimum_Term").equalsIgnoreCase("")
					&& !hm.get("Maximum_Term").equalsIgnoreCase("")) {
				if (Integer.parseInt(coverageTerm) < Integer.parseInt(hm.get("Minimum_Term"))
						|| Integer.parseInt(coverageTerm) > Integer.parseInt(hm.get("Maximum_Term"))) {
					message = "Coverage Term must lie between " + hm.get("Minimum_Term") + " and "
							+ hm.get("Maximum_Term") + ". Please correct!";
					BusinessLogicDao.logger.info("message: " + message);
					// ifr.setValue("Q_COVERAGE_DETAILS.COVERAGE_TERM", "");
				}
			}
		} else if (hm.get("Term_CalC_Code").equalsIgnoreCase("B")) {
			if (!coverageTerm.equalsIgnoreCase("") && !hm.get("Plan_Age_Expiry").equalsIgnoreCase("")
					&& !ageOfInsured.equalsIgnoreCase("")) {
				if (Integer.parseInt(coverageTerm) != Integer.parseInt(hm.get("Plan_Age_Expiry"))
						- Integer.parseInt(ageOfInsured)) {
					message = "Covergae Term must be equal to "
							+ (Integer.parseInt(hm.get("Plan_Age_Expiry")) - Integer.parseInt(ageOfInsured));
					// ifr.setValue("Q_COVERAGE_DETAILS.COVERAGE_TERM", "");
				}
			}
		} else if (hm.get("Term_CalC_Code").equalsIgnoreCase("C")) {
			term_calc_desc = hm.get("Minimum_Term");
			boolean matched = false;
			String[] term_calc_descArr = term_calc_desc.split(",");
			if (term_calc_descArr.length != 0) {
				for (String code : term_calc_descArr) {
					code = code.trim();
					if (coverageTerm.equals(code))
						matched = true;
				}
			}
			if (!matched) {
				message = "Please enter the valid coverage term!";
			}
		}

		// Logic 2
		//Commented by Pranav as same logic is already written in IssueAge Class  
		/*String Min_Expiry_Age = "", Max_Expiry_Age = "";
		Min_Expiry_Age = hm.get("Minimum_Expiry_Age");
		Max_Expiry_Age = hm.get("Maximum_Expiry_Age");

		if (!coverageTerm.equalsIgnoreCase("") && !Min_Expiry_Age.equalsIgnoreCase("")
				&& !ageOfInsured.equalsIgnoreCase("") && !Max_Expiry_Age.equalsIgnoreCase("")) {
			if (Integer.parseInt(coverageTerm) + Integer.parseInt(ageOfInsured) < Integer.parseInt(Min_Expiry_Age)
					|| Integer.parseInt(coverageTerm) + Integer.parseInt(ageOfInsured) > Integer
							.parseInt(Max_Expiry_Age)) {
				message = "Expiry Age must lie between " + Min_Expiry_Age + " and " + Max_Expiry_Age
						+ ". Please correct!";
//                    ifr.setValue("Q_COVERAGE_DETAILS.COVERAGE_TERM", "");
			}
		}*/

	}

	// result
	public String getResult() {
		return message;
	}

}

/**
 * Logic for Modal Premium
 * 
 * @author prakhar.saxena
 *
 */
class ModalPremium {
	String modalPremium;
	String modeofPay;
	String message = "",whereClause;

	public ModalPremium(String modalPremium, String modeofPay, String whereClause) {
		this.modalPremium = modalPremium;
		this.modeofPay = modeofPay;
		this.whereClause=whereClause;
	}

	public void validateField() {
		message = "";
		DecimalFormat df = new DecimalFormat("#.00");
		MinMaxValues minMaxValues = new MinMaxValues();
		String query = "";
		if (modeofPay.equalsIgnoreCase("01")) { // monthly
			query = "SELECT ISNULL(Minimum_Monthly_Premium,0) AS 'Minimum_Monthly_Premium',"
					+ "ISNULL(Maximum_Monthly_Premium,0) AS 'Maximum_Monthly_Premium','0' AS 'Interval'" + whereClause;
			minMaxValues = BusinessLogicDao.queryExecutor.runMinMaxQuery(query, BusinessLogicDao.source,
					"Minimum_Monthly_Premium", "Maximum_Monthly_Premium","Interval");
			;
			if (minMaxValues != null) {
				String Min_Monthly_Premium = minMaxValues.minValue;
				String Max_Monthly_Premium = minMaxValues.maxValue;

				if (!modalPremium.equalsIgnoreCase("") && !Min_Monthly_Premium.equalsIgnoreCase("")
						&& !Max_Monthly_Premium.equalsIgnoreCase("")) {
					if (Double.parseDouble(modalPremium) < Double.parseDouble(Min_Monthly_Premium)
							|| Double.parseDouble(modalPremium) > Double.parseDouble(Max_Monthly_Premium)) {
						message = "Modal Premium must lie between " + df.format(Double.parseDouble(Min_Monthly_Premium))
								+ " and " + df.format(Double.parseDouble(Max_Monthly_Premium));
//						ifr.setValue("Q_COVERAGE_DETAILS.MODAL_PREMIUM", "");
					}
				}
			}
		} else if (modeofPay.equalsIgnoreCase("03")) { // quarterly
			query = "SELECT ISNULL(Minimum_Quarterly_Premium,0) AS 'Minimum_Quarterly_Premium',"
					+ "ISNULL(Maximum_Quarterly_Premium,0) AS 'Maximum_Quarterly_Premium',"
					+ "'0' AS 'Interval'" + whereClause;
			minMaxValues = BusinessLogicDao.queryExecutor.runMinMaxQuery(query, BusinessLogicDao.source,
					"Minimum_Quarterly_Premium", "Maximum_Quarterly_Premium","Interval");
			if (minMaxValues != null) {
				String Min_Quarterly_Premium = minMaxValues.minValue;
				String Max_Quarterly_Premium = minMaxValues.maxValue;

				if (!modalPremium.equalsIgnoreCase("") && !Min_Quarterly_Premium.equalsIgnoreCase("")
						&& !Max_Quarterly_Premium.equalsIgnoreCase("")) {
					if (Double.parseDouble(modalPremium) < Double.parseDouble(Min_Quarterly_Premium)
							|| Double.parseDouble(modalPremium) > Double.parseDouble(Max_Quarterly_Premium)) {
						message = "Modal Premium must lie between "
								+ df.format(Double.parseDouble(Min_Quarterly_Premium)) + " and "
								+ df.format(Double.parseDouble(Max_Quarterly_Premium));
//						ifr.setValue("Q_COVERAGE_DETAILS.MODAL_PREMIUM", "");
					}
				}
			}
		} else if (modeofPay.equalsIgnoreCase("06")) { // semi annual
			query = "SELECT ISNULL(Minimum_Semi_Annual_Premium,0) AS 'Minimum_Semi_Annual_Premium',"
					+ "ISNULL(Maximum_Semi_Annual_Premium,0) AS 'Maximum_Semi_Annual_Premium','0' AS 'Interval' " 
					+ whereClause;
			minMaxValues = BusinessLogicDao.queryExecutor.runMinMaxQuery(query, BusinessLogicDao.source,
					"Minimum_Semi_Annual_Premium", "Maximum_Semi_Annual_Premium","Interval");
			if (minMaxValues != null) {
				String Min_Semi_Annual_Premium = minMaxValues.minValue;
				String Max_Semi_Annual_Premium = minMaxValues.maxValue;

				if (!modalPremium.equalsIgnoreCase("") && !Min_Semi_Annual_Premium.equalsIgnoreCase("")
						&& !Max_Semi_Annual_Premium.equalsIgnoreCase("")) {
					if (Double.parseDouble(modalPremium) < Double.parseDouble(Min_Semi_Annual_Premium)
							|| Double.parseDouble(modalPremium) > Double.parseDouble(Max_Semi_Annual_Premium)) {
						message = "Modal Premium must lie between "
								+ df.format(Double.parseDouble(Min_Semi_Annual_Premium)) + " and "
								+ df.format(Double.parseDouble(Max_Semi_Annual_Premium));
//						ifr.setValue("Q_COVERAGE_DETAILS.MODAL_PREMIUM", "");
					}
				}
			}
		} else if (modeofPay.equalsIgnoreCase("12")) { // annual
			query = "SELECT ISNULL(Minimum_Annual_Premium,0) AS 'Minimum_Annual_Premium',ISNULL(Maximum_Annual_Premium,0) AS 'Maximum_Annual_Premium',"
					+ "'0' AS 'Interval'" + whereClause;
			minMaxValues = BusinessLogicDao.queryExecutor.runMinMaxQuery(query, BusinessLogicDao.source,
					"Minimum_Annual_Premium", "Maximum_Annual_Premium","Interval");
			if (minMaxValues != null) {
				String Min_Annual_Premium = minMaxValues.minValue;
				String Max_Annual_Premium = minMaxValues.maxValue;

				if (!modalPremium.equalsIgnoreCase("") && !Min_Annual_Premium.equalsIgnoreCase("")
						&& !Max_Annual_Premium.equalsIgnoreCase("")) {
					if (Double.parseDouble(modalPremium) < Double.parseDouble(Min_Annual_Premium)
							|| Double.parseDouble(modalPremium) > Double.parseDouble(Max_Annual_Premium)) {
						message = "Modal Premium must lie between " + df.format(Double.parseDouble(Min_Annual_Premium))
								+ " and " + df.format(Double.parseDouble(Max_Annual_Premium));
//						ifr.setValue("Q_COVERAGE_DETAILS.MODAL_PREMIUM", "");
					}
				}
			}
		}
	}

	// result
	public String getResult() {
		return message;
	}
}

/**
 * Will return hashMap of valid key and value pairs whose entries are present in
 * ULIP master table as comma separated values.
 * 
 * @author prakhar.saxena
 *
 */
class CommaSeparatedValues {
	private static Logger logger = Logger.getLogger("CommaSeparatedValues");
	Map<String, String> hm = new HashMap<>(); 

	public void getValidKeyValues(String MDM_ColumnName, String masterTableName, String valueCol,
			String labelCol, String whereClause) {
		hm.clear();
		String query = "Select " + MDM_ColumnName + " " + whereClause;
		hm = BusinessLogicDao.queryExecutor.getValidKeyValuePair(query, BusinessLogicDao.source, MDM_ColumnName,
				masterTableName, valueCol, labelCol);
		logger.info("hm: " + hm);
	}

	public Map<String, String> getResult() {
		return hm;
	}

}

/**
 * Logic for Premium Payment Term
 * 
 * @author prakhar.saxena
 *
 */
class PremiumPaymentTerm {
	String premiumPaymentTerm;
	String insuredDOB;
	String coverageTerm;
	String effectiveDate;
	String message = "";
	String whereClauseWithoutTable;
	String productDating,whereClause;

	public PremiumPaymentTerm(String premiumPaymentTerm, String insuredDOB, String coverageTerm, String whereClauseWithoutTable,String effectiveDate,
			String whereClause, String productDating) {
		this.premiumPaymentTerm = premiumPaymentTerm;
		this.insuredDOB = insuredDOB;
		this.coverageTerm = coverageTerm;
		this.whereClauseWithoutTable = whereClauseWithoutTable;
		this.effectiveDate = effectiveDate;
		this.whereClause=whereClause;
		this.productDating=productDating;
	}

	public void validateField() {
		message = "";
		Map<String, String> queryResult = new HashMap<>();
		String query = "SELECT PPT_Cal_Logic_code,Payment_Term,Calculation_Value" + whereClause;
		queryResult = BusinessLogicDao.queryExecutor.runPPTQuery(query, BusinessLogicDao.source);
		String PPT_Cal_Logic_code = queryResult.get("PPT_Cal_Logic_code");
		String Payment_Term = queryResult.getOrDefault("Payment_Term", "0");
		String Calculation_Value = queryResult.getOrDefault("Calculation_Value", "0");
		String ageOfInsured = BusinessLogicDao.CalculateYears(insuredDOB,effectiveDate,productDating);
		
		if(Payment_Term.equals("")) Payment_Term="0";
		if(Calculation_Value.equals("")) Calculation_Value="0";
		
		if (queryResult != null) {
			if (PPT_Cal_Logic_code.equalsIgnoreCase("A")) {
				String[] Payment_TermArr = Payment_Term.split(",");
				Boolean match = false;
				for (int i = 0; i < Payment_TermArr.length; i++) {
					if (premiumPaymentTerm.equalsIgnoreCase(Payment_TermArr[i])) {
						match = true;
					}
				}
				if (!match) {
					message = "Premium Payment Term is not valid. Please check.";
//                    ifr.setValue("Q_COVERAGE_DETAILS.PREMIUM_PAY_TERM", "");
				}
			} else if (PPT_Cal_Logic_code.equalsIgnoreCase("B")) {
				if (!premiumPaymentTerm.isEmpty() && !ageOfInsured.isEmpty()) {
					if (Integer.parseInt(premiumPaymentTerm) != Integer.parseInt(Calculation_Value)
							- Integer.parseInt(ageOfInsured)) {
						message = "Premium Payment Term is not valid. Please check.";
//                        ifr.setValue("Q_COVERAGE_DETAILS.PREMIUM_PAY_TERM", "");
					}
				}
			} else if (PPT_Cal_Logic_code.equalsIgnoreCase("C")) {
				if (!coverageTerm.equalsIgnoreCase(premiumPaymentTerm)) {
					message = "Premium Payment Term is not valid. Please check.";
//                    ifr.setValue("Q_COVERAGE_DETAILS.PREMIUM_PAY_TERM", "");
				}
			} else if (PPT_Cal_Logic_code.equalsIgnoreCase("D")) {
				if (!premiumPaymentTerm.equalsIgnoreCase("1")) {
					message = "Premium Payment Term is not valid. Please check.";
//                    ifr.setValue("Q_COVERAGE_DETAILS.PREMIUM_PAY_TERM", "");
				}
			} else if (PPT_Cal_Logic_code.equalsIgnoreCase("E")) {
				if (!premiumPaymentTerm.isEmpty() && !coverageTerm.isEmpty() && !Calculation_Value.isEmpty()) {
					if (Integer.parseInt(premiumPaymentTerm) != Integer.parseInt(coverageTerm)
							- Integer.parseInt(Calculation_Value)) {
						message = "Premium Payment Term is not valid. Please check.";
//                        ifr.setValue("Q_COVERAGE_DETAILS.PREMIUM_PAY_TERM", "");
					}
				}
			} else if (PPT_Cal_Logic_code.equalsIgnoreCase("F")) {
				String ppt_query = "SELECT Premium_Payment_Term FROM NG_NB_MS_TRAD_PT_PPT(nolock) "+whereClauseWithoutTable+" AND Term = " + coverageTerm;
				ArrayList<String> ppt_list = new ArrayList<>();
				ppt_list = BusinessLogicDao.queryExecutor.runPPTQuery2(ppt_query, BusinessLogicDao.source);
				boolean matched = false;
                if(ppt_list!=null){
                    for(int i=0;i<ppt_list.size(); i++){
                        if(ppt_list.contains(premiumPaymentTerm))
                            matched = true;
                    }
                }
                if(!matched){
                	message = "Premium Payment Term is not valid. Please check. Valid values are: " +ppt_list;
                }
			}
		}

	}

	public String getResult() {
		return message;
	}
}


//Rider Classes
class RiderCT {
	String CoverageTerm;
	String insuredDob;
	String effectiveDate;
	String baseCoverageTerm;
	String basePPT;
	String message = "",whereClause,productDating,proposerDOB,JointLife;  //DR-28247 sparsh
	
	public RiderCT(String CoverageTerm,String insuredDob,String proposerDOB, String effectiveDate,String baseCoverageTerm,String basePPT, String whereClause, 
			String productDating, String JointLife){
		this.CoverageTerm=CoverageTerm;
		this.insuredDob=insuredDob;
		this.effectiveDate=effectiveDate;
		this.baseCoverageTerm=baseCoverageTerm;
		this.basePPT=basePPT;
		this.whereClause=whereClause;
		this.productDating=productDating;
		this.proposerDOB=proposerDOB;
		this.JointLife=JointLife;  //DR-28247 sparsh
	}
	
	public void validateCT() {
		message = "";
		String ageOfInsured="0",ageofprop="0",riderCT="",termCalcCode,Minimum_Term,Maximum_Term,termLogicCode,query,maxExpiry="0";
		Map<String, String> queryResult = new HashMap<>();
		int intBasePPT, intBaseCT, insuredAge, riderMaxTerm =0,intMaxExpiry=0,propAge;
		
		try{
			query = "SELECT ISNULL(Term_Calc_Cd,'') AS 'Term_Calc_Cd',ISNULL(Minimum_Term,'0') AS 'Minimum_Term',"
					+ " ISNULL(Maximum_Term,0) AS 'Maximum_Term', ISNULL(Term_CalC_Code,'') AS 'Term_CalC_Code',"
					+ "ISNULL(Maximum_Expiry_Age,0) AS 'Maximum_Expiry_Age'  "+ whereClause;
			
			queryResult = BusinessLogicDao.queryExecutor.runRiderCTQuery(query);
			termCalcCode = queryResult.get("Term_Calc_Cd");
			Minimum_Term = queryResult.get("Minimum_Term");
			Maximum_Term = queryResult.get("Maximum_Term");
			termLogicCode = queryResult.get("Term_CalC_Code");
			maxExpiry=queryResult.get("Maximum_Expiry_Age");
			
			if (!insuredDob.equalsIgnoreCase("")) {
    			ageOfInsured = BusinessLogicDao.CalculateYears(insuredDob,effectiveDate,productDating);
    		}
            insuredAge = ageOfInsured.isEmpty() ? 0 : Integer.parseInt(ageOfInsured);
            
        	if (!proposerDOB.equalsIgnoreCase("")) {
        		ageofprop = BusinessLogicDao.CalculateYears(proposerDOB,effectiveDate,productDating);
    		}
        	propAge = ageofprop.isEmpty() ? 0 : Integer.parseInt(ageofprop);
            
			if(termCalcCode.equalsIgnoreCase("CT") && !CoverageTerm.equalsIgnoreCase(baseCoverageTerm)){
				message= "Coverage Term must be equal to Base Coverage Term";
			}
			else if(termCalcCode.equalsIgnoreCase("PPT") && !CoverageTerm.equalsIgnoreCase(basePPT)){
				message="Coverage Term must be equal to Base Premium Payment Term";
			}
			else if(termCalcCode.equalsIgnoreCase("RAN"))
				message="RAN";
			else if(termCalcCode.equalsIgnoreCase("CALC")){
				intBasePPT = basePPT.isEmpty() ? 0 : Integer.parseInt(basePPT);
	            intBaseCT = baseCoverageTerm.isEmpty() ? 0 : Integer.parseInt(baseCoverageTerm);
	            intMaxExpiry=maxExpiry.isEmpty() ? 0 : Integer.parseInt(maxExpiry);
				
	            if (termLogicCode.equalsIgnoreCase("A")) {
	                riderMaxTerm = Maximum_Term.isEmpty() ? 0 : Integer.parseInt(Maximum_Term);
	            } else if (termLogicCode.equalsIgnoreCase("C")) {
	                String[] multipleTerm = Minimum_Term.split(",", -1);
	                int ctVal = 0;
	                for (String CT : multipleTerm) {
	                    ctVal = CT.isEmpty() ? 0 : Integer.parseInt(CT);
	                    if (ctVal > riderMaxTerm) {
	                        riderMaxTerm = ctVal;
	                    }
	                }
	            }
	            
	            // if isJointlife-->'Y' and code is CALC then expiry-proposerAge // DR-28247 sparsh
	            if(JointLife.equalsIgnoreCase("Y")) {
	            	riderCT=String.valueOf(Math.min(Math.min(Math.min(intBasePPT, intBaseCT), intMaxExpiry - propAge),riderMaxTerm));
	 	           	
	            }else {
	            	riderCT=String.valueOf(Math.min(Math.min(Math.min(intBasePPT, intBaseCT), intMaxExpiry - insuredAge),riderMaxTerm));
	            }
	            
	            if(!CoverageTerm.equalsIgnoreCase(riderCT)){
	            	message="Coverage Term should be equal to "+riderCT+ ".";
	            }
	            if(Integer.parseInt(CoverageTerm)<Integer.parseInt(Minimum_Term) || Integer.parseInt(CoverageTerm)>Integer.parseInt(Maximum_Term))
	            {
	            	message=message+"Coverage Term should be between "+Minimum_Term+ " and " +Maximum_Term;
	            }
			}
			else if(termCalcCode.equalsIgnoreCase("PCALC")){
				intBasePPT = basePPT.isEmpty() ? 0 : Integer.parseInt(basePPT);
	            intBaseCT = baseCoverageTerm.isEmpty() ? 0 : Integer.parseInt(baseCoverageTerm);
	            intMaxExpiry=maxExpiry.isEmpty() ? 0 : Integer.parseInt(maxExpiry);
	         
				
	            if (termLogicCode.equalsIgnoreCase("A")) {
	                riderMaxTerm = Maximum_Term.isEmpty() ? 0 : Integer.parseInt(Maximum_Term);
	            } else if (termLogicCode.equalsIgnoreCase("C")) {
	                String[] multipleTerm = Minimum_Term.split(",", -1);
	                int ctVal = 0;
	                for (String CT : multipleTerm) {
	                    ctVal = CT.isEmpty() ? 0 : Integer.parseInt(CT);
	                    if (ctVal > riderMaxTerm) {
	                        riderMaxTerm = ctVal;
	                    }
	                }
	            }
	            riderCT=String.valueOf(Math.min(Math.min(Math.min(intBasePPT, intBaseCT), intMaxExpiry - propAge),riderMaxTerm));
	            if(!CoverageTerm.equalsIgnoreCase(riderCT)){
	            	message="Coverage Term should be equal to "+riderCT+ ".";
	            }
	            if(Integer.parseInt(CoverageTerm)<Integer.parseInt(Minimum_Term) || Integer.parseInt(CoverageTerm)>Integer.parseInt(Maximum_Term))
	            {
	            	message=message+"Coverage Term should be between "+Minimum_Term+ " and " +Maximum_Term;
	            }
			}
			else if(termCalcCode.equalsIgnoreCase("CTCALC")){
				intBaseCT = baseCoverageTerm.isEmpty() ? 0 : Integer.parseInt(baseCoverageTerm);
				intMaxExpiry=maxExpiry.isEmpty() ? 0 : Integer.parseInt(maxExpiry);
				
	            if (termLogicCode.equalsIgnoreCase("A")) {
	                riderMaxTerm = Maximum_Term.isEmpty() ? 0 : Integer.parseInt(Maximum_Term);
	            } else if (termLogicCode.equalsIgnoreCase("C")) {
	                String[] multipleTerm = Minimum_Term.split(",", -1);
	                int ctVal = 0;
	                for (String CT : multipleTerm) {
	                    ctVal = CT.isEmpty() ? 0 : Integer.parseInt(CT);
	                    if (ctVal > riderMaxTerm) {
	                        riderMaxTerm = ctVal;
	                    }
	                }
	            }
	            //DR-28247 sparsh if jointlife is Y and code is CTCALC then expiry-proposerAge
	            if(JointLife.equalsIgnoreCase("Y")) {
	            	 riderCT = String.valueOf(Math.min(Math.min(intBaseCT, riderMaxTerm),intMaxExpiry-propAge));
	  	        }else {
	  	        	riderCT = String.valueOf(Math.min(Math.min(intBaseCT, riderMaxTerm),intMaxExpiry-insuredAge));
	            }
	            
	            if(!CoverageTerm.equalsIgnoreCase(riderCT)){
	            	message="Coverage Term should be equal to "+riderCT;
	            }
			}
			else if(termCalcCode.isEmpty()){
				message="CT Calc code not found in rider setup Master";
			}
		}
		catch(Exception e){
			message="Error Occured in validateCT method of RiderCT Class "+e.toString();
		}
	}
	
	public String getMessage() {
		return message;
	}
}

class RiderPPT {
	private String ppt;
	String baseCoverageTerm;
	String basePPT;
	String insuredDob;
	String effectiveDate;
	String CoverageTerm;
	String message = "";
	String whereClause,productDating;
	
	public RiderPPT(String ppt,String baseCoverageTerm,String basePPT,String insuredDob,String effectiveDate,String CoverageTerm, String whereClause,
			String productDating){
		this.ppt=ppt;
		this.baseCoverageTerm=baseCoverageTerm;
		this.basePPT=basePPT;
		this.insuredDob=insuredDob;
		this.effectiveDate=effectiveDate;
		this.CoverageTerm=CoverageTerm;
		this.whereClause=whereClause;
		this.productDating=productDating;
	}
	
	public void validatePPT() {
		message = "";
		String riderPPT = "", mimterm = "", maxterm = "", termLogicCode = "",query,pptCalcCode,pptApplicable,calculation,maxExpiry="0",ageOfInsured="0";
		Map<String, String> queryResult = new HashMap<>();
		int intBasePPT, intBaseCT, riderMaxTerm = 0,intMaxExpiry=0,insuredAge,numericPPT,numericCT;
		
		try{
			query = "SELECT ISNULL(PPT_APPLICABLE,'') AS 'PPT_APPLICABLE',ISNULL(PPT_Calc_Cd,'') AS 'PPT_Calc_Cd',ISNULL(Minimum_PPT,'0') AS 'Minimum_PPT', "
					+ "ISNULL(Maximum_PPT,0) AS 'Maximum_PPT', ISNULL(PPT_Cal_Logic_Code,'') AS 'PPT_Cal_Logic_Code',"
					+ "ISNULL(Calculation,0) AS 'Calculation', ISNULL(Maximum_Expiry_Age,0) AS 'Maximum_Expiry_Age'  "+ whereClause;
			
			queryResult = BusinessLogicDao.queryExecutor.runRiderPPTQuery(query);
			pptApplicable=queryResult.get("PPT_APPLICABLE");
			pptCalcCode = queryResult.get("PPT_Calc_Cd");
			mimterm = queryResult.get("Minimum_PPT");
			maxterm = queryResult.get("Maximum_PPT");
			termLogicCode = queryResult.get("PPT_Cal_Logic_Code");
			calculation = queryResult.get("Calculation");
			maxExpiry= queryResult.get("Maximum_Expiry_Age");
			
			if(pptApplicable.equalsIgnoreCase("Y")){
				
				if (!insuredDob.equalsIgnoreCase("")) {
	    			ageOfInsured = BusinessLogicDao.CalculateYears(insuredDob,effectiveDate,productDating);
	    		}
	            insuredAge = ageOfInsured.isEmpty() ? 0 : Integer.parseInt(ageOfInsured);
	            
	            
				if (pptCalcCode.equalsIgnoreCase("CT") && !ppt.equalsIgnoreCase(baseCoverageTerm)) {
					message= "PPT must be equal to Base Coverage Term";
		        } else if (pptCalcCode.equalsIgnoreCase("PPT") && !ppt.equalsIgnoreCase(basePPT)) {
		        	message= "PPT must be equal to Base Premium Payment Term";
		        } else if (pptCalcCode.equalsIgnoreCase("RAN")) {
		        	message=premiumPaymentTermLogic(ppt,termLogicCode,mimterm,maxterm,calculation,insuredAge);
		        } else if (pptCalcCode.equalsIgnoreCase("CTCALC")) {
		            intBaseCT = baseCoverageTerm.isEmpty() ? 0 : Integer.parseInt(baseCoverageTerm);
		            intBasePPT = basePPT.isEmpty() ? 0 : Integer.parseInt(basePPT);
		            intMaxExpiry=maxExpiry.isEmpty() ? 0 : Integer.parseInt(maxExpiry);
		            
		            if (termLogicCode.equalsIgnoreCase("A")) {
		                String[] multipleTerm = mimterm.split(",", -1);
		                int ctVal = 0;
		                for (String CT : multipleTerm) {
		                    ctVal = CT.trim().isEmpty() ? 0 : Integer.parseInt(CT);
		                    if (ctVal > riderMaxTerm) {
		                        riderMaxTerm = ctVal;
		                    }
		                }
		            } else if (termLogicCode.equalsIgnoreCase("G")) {
		                riderMaxTerm = maxterm.isEmpty() ? 0 : Integer.parseInt(maxterm);
		            }
		            
		            if(termLogicCode.isEmpty())
		            	message= "PPT Logic is missing in Rider setup Master";
		            else{
			            riderPPT = String.valueOf(Math.min(intBasePPT, Math.min(intMaxExpiry-insuredAge, riderMaxTerm)));
			            if(!ppt.equalsIgnoreCase(riderPPT)){
			            	message= "PPT should be equal to "+riderPPT;
			            }
		            }
		        }
		        else if(pptCalcCode.isEmpty())
		        	message= "PPT Calc code not found in rider setup Master";
				
				numericCT = CoverageTerm.isEmpty() ? 0 : Integer.parseInt(CoverageTerm);
                numericPPT = ppt.isEmpty() ? 0 : Integer.parseInt(ppt);
                if (numericPPT > numericCT) {
                	message += "!  Rider PPT cannot be greater than rider CT!";
                }
			}
			
		}
		catch(Exception e){
			message="Error Occured in validatePPT method of RiderPPT Class -"+e.toString();
		}
	}
	public String premiumPaymentTermLogic(String ppt, String pptCode,String minTerm, String maxTerm,String calculation,int insuredAge){
		int calculationValue = 0, pptVal, logicalValue, baseCoverageTermVal, minPremiumTerm, maxPremiumTerm;
		String matchFlag="N",returnMessage="",ageOfInsured="";
		try{
			calculationValue = Integer.parseInt(calculation);
			pptVal = ppt.isEmpty() ? 0 : Integer.parseInt(ppt);
			baseCoverageTermVal = baseCoverageTerm.isEmpty() ? 0 : Integer.parseInt(baseCoverageTerm);
			
	        if (pptCode.equalsIgnoreCase("A")) {
	            String[] minTermArr = minTerm.split(",");
	            for (String term : minTermArr) {
	                if (term.trim().equalsIgnoreCase(ppt.trim())) {
	                    matchFlag = "Y";
	                }
	            }
	            if (matchFlag.equalsIgnoreCase("N")) {
	                returnMessage = "Valid values for Premium Payment Term are " + minTerm + "!";
	            }
	        } else if (pptCode.equalsIgnoreCase("B")) {
	            logicalValue = calculationValue - insuredAge;
	            if (logicalValue != pptVal) {
	                returnMessage ="Value for Premium Payment Term should be " + logicalValue + "!";
	            }
	        } else if (pptCode.equalsIgnoreCase("C") && pptVal != baseCoverageTermVal) {
	            returnMessage = "Premium Payment Term should be " + baseCoverageTermVal + "!";
	        } else if (pptCode.equalsIgnoreCase("D") && pptVal != 1) {
	            returnMessage =  "Premium Payment Term should be 1 !";
	        } else if (pptCode.equalsIgnoreCase("E")) {
	            logicalValue = baseCoverageTermVal - calculationValue;
	            if (logicalValue != pptVal) {
	                returnMessage = "Value for Premium Payment Term should be " + logicalValue + "!";
	            }
	        } else if (pptCode.equalsIgnoreCase("G")) {
	            minPremiumTerm = Integer.parseInt(minTerm);
	            maxPremiumTerm = Integer.parseInt(maxTerm);
	            if (pptVal < minPremiumTerm || pptVal > maxPremiumTerm) {
	                returnMessage = "Premium term should be between " + minTerm + " and " + maxTerm + "!";
	            }
	        }
	        else if (pptCode.isEmpty()){
	        	returnMessage ="PPT Logic Code not found in Rider setup Master";
	        }
		}catch(Exception e){
			returnMessage="Error Occured in premiumPaymentTermLogic method of RiderPPT Class -"+e.toString();
		}
		return returnMessage;
	}
	
	public String getMessage() {
		return message;
	}
}

//Rider Classes End