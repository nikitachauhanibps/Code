package com.newgen.services;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.json.XML;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.JsonObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.newgen.util.CommonFunctions;
import com.newgen.util.XMLGen;
import com.newgen.validations.UlipValidator;
import com.newgen.validationsCombo.ComboValidator;

public class CreateWI {
	private static Properties propertiesFileData;
	private String sessionID = "";
	private static Logger logger = Logger.getLogger("CreateWI");

	// {
	// try {
	// String sessionID = CommonFunctions.getSessionID();
	// } catch (FileNotFoundException e) {
	// // TODO Auto-generated catch block
	// e.printStackTrace();
	// } catch (IOException e) {
	// // TODO Auto-generated catch block
	// e.printStackTrace();
	// }
	// }

	public synchronized String createWI(InputStream incomingData) throws IOException, Exception {
		String result = "";
		try {
			propertiesFileData = new Properties();
			Properties props = new Properties();

			String configPath = System.getProperty("user.dir") + File.separator
					+ "CreateWorkitemService\\log4j.properties";
			props.load(new FileInputStream(configPath));
			PropertyConfigurator.configure(props);

			configPath = System.getProperty("user.dir") + File.separator + "CreateWorkitemService\\config.properties";
			FileReader reader = new FileReader(configPath);

			logger.info("configPath: " + configPath);

			propertiesFileData = new Properties();
			propertiesFileData.load(reader);

			JSONObject erroObj = createErrorJson("400", "Validation");
			String cabinetName = propertiesFileData.getProperty("cabinetName");
			String ipAddress = propertiesFileData.getProperty("ipAddress");
			String username = propertiesFileData.getProperty("username");
			String password = propertiesFileData.getProperty("password");
			String port = propertiesFileData.getProperty("port");

			StringBuilder inputJSON = new StringBuilder();
			try {
				BufferedReader in = new BufferedReader(new InputStreamReader(incomingData));
				String line = null;
				while ((line = in.readLine()) != null) {
					inputJSON.append(line);
				}
			} catch (Exception e) {
				logger.info("Error Parsing: - ");
			}

			logger.info("Data Received: " + inputJSON.toString());

			String wiData = inputJSON.toString();
			// ipAddress = "192.168.54.97";
			// String method = "POST";
			// String url =
			// "http://"+ipAddress+":9090/iBPSRestFulWebServices/ibps/Restful/"+cabinetName+"/WMConnect/?userName="+username+"&UserExist=N";
			//
			// HashMap<String, String> hm = new HashMap<>();
			// hm.put("Password", password);
			//
			// sessionID=callRestAPI(url, method, hm);
			// if(sessionID.indexOf("<SessionId>")==-1) {
			// result = "Invalid Session ID!";
			// return result;
			// }
			// else {
			// sessionID =
			// sessionID.substring(sessionID.indexOf("<SessionId>")+11,
			// sessionID.indexOf("</SessionId>"));

			// Calling Proc to validate all the dropdowns
			wiData = wiData.replaceAll("'", "''''");
			wiData = wiData.replaceAll("&", "&amp;");
			
			String jsonValidateQuery = "EXEC NG_SP_NB_INTERFACE_VALIDATE '" + wiData + "'";
			logger.info("jsonValidateQuery: " + jsonValidateQuery);
			// //getting sessionID
			// String inputXML =
			// XMLGen.get_WMConnect_Input(cabinetName,username,password,"N");
			// logger.info("get_WMConnect_Input_inputXML: "+inputXML);
			// String outputXML = callRestAPI_JTS(inputXML);
			// sessionID =
			// outputXML.substring(outputXML.indexOf("<SessionId>")+11,outputXML.indexOf("</SessionId>"));
			// logger.info("get_WMConnect_Input_outputXML: "+outputXML);
			logger.info("Connecting User...");
			sessionID = CommonFunctions.getSessionID();
			logger.info("sessionID: " + sessionID);
			// added by Prakhar for ULIP validations begins
			String case_type = caseType(wiData, cabinetName);

			
			String IsCOMBO= ISCOMBO(wiData, cabinetName);
			logger.info("case_type: " + case_type);
			if (IsCOMBO.equals("COMBO")) {
				ComboValidator comboValidations = new ComboValidator(wiData, sessionID, cabinetName);
				// ulipValidations.set_SessionIDCabName(sessionID, cabinetName);
				comboValidations.validateJson();
				if (!comboValidations.createResponseJson(erroObj).equalsIgnoreCase("Validated")) {
					// disconnecting user
					logger.info("Disconnecting User...");
					String disUserXML = CommonFunctions.disconnectUser(sessionID);
					logger.info("disUserXML: " + disUserXML);
					return comboValidations.createResponseJson(erroObj);
				}
			}
			
			else if (case_type.equals("ULIP")) {
				UlipValidator ulipValidations = new UlipValidator(wiData, sessionID, cabinetName);
				// ulipValidations.set_SessionIDCabName(sessionID, cabinetName);
				ulipValidations.validateJson();
				if (!ulipValidations.createResponseJson(erroObj).equalsIgnoreCase("Validated")) {
					// disconnecting user
					logger.info("Disconnecting User...");
					String disUserXML = CommonFunctions.disconnectUser(sessionID);
					logger.info("disUserXML: " + disUserXML);
					return ulipValidations.createResponseJson(erroObj);
				}
			}
			// added for ULIP validations end.

			String jsonValidateInputXML = XMLGen.APSelectWithColumnNames(cabinetName, jsonValidateQuery, sessionID);
			logger.info("APSelectWithColumnNames_Input_inputXML: " + jsonValidateInputXML);
			// String outputXML = WFCallBroker.execute(inputXML,
			// "192.168.54.97",
			// 3333, 1);
			String jsonValidateOutputXML = CommonFunctions.callRestAPI_JTS(jsonValidateInputXML);
			logger.info("APSelectWithColumnNames jsonValidateOutputXML: " + jsonValidateOutputXML);
			String jsonValidateResult = jsonValidateOutputXML.substring(jsonValidateOutputXML.indexOf("SUCCESS") + 8,
					jsonValidateOutputXML.indexOf("</SUCCESS>"));
			logger.info("jsonValidateResult: " + jsonValidateResult);
			// bug 1081028
			ArrayList<String> riderValidateResponse=new  ArrayList<>();
			// Rider Validations
			if (IsCOMBO.equals("COMBO")) 
			{
				ComboValidator riderValidate = new ComboValidator(wiData, sessionID, cabinetName,case_type);
				riderValidate.validateRiderBenefit();
				 riderValidateResponse = riderValidate.createRiderResponseJson();
			}
			else
			{
			UlipValidator riderValidate = new UlipValidator(wiData, sessionID, cabinetName,case_type);
			riderValidate.validateRiderBenefit();
			 riderValidateResponse = riderValidate.createRiderResponseJson();
			}

			if (!jsonValidateResult.equalsIgnoreCase("SUCCESS") || riderValidateResponse.size() > 0) {
				String[] arrOfStr = jsonValidateResult.split(",");
				ArrayList<String> jsonValidateArrayStr = new ArrayList<>();

				if (!jsonValidateResult.equalsIgnoreCase("SUCCESS")) {
					for (String a : arrOfStr)
						jsonValidateArrayStr.add(a);
				}

				for (String riderErr : riderValidateResponse)
					jsonValidateArrayStr.add(riderErr);

				JSONObject jsonValidateObj = new JSONObject();
				jsonValidateObj.put("msgInfo", erroObj);
				jsonValidateObj.put("message", "Please Validate the fields");
				jsonValidateObj.put("fields", jsonValidateArrayStr);
				logger.info("Disconnecting User...");
				String disUserXML = CommonFunctions.disconnectUser(sessionID);
				return jsonValidateObj.toString();
			} else if (jsonValidateResult.equalsIgnoreCase("ERROR")) {
				logger.info("Disconnecting User...");
				String disUserXML = CommonFunctions.disconnectUser(sessionID);
				return "{\r\n" + "	\"Exception\":{\r\n" + "		\"statusCode\":\"1\",\r\n"
						+ "		\"Subject\":\"Some Error Occured at Server End. Please contact Administrator.\"\r\n"
						+ "	}\r\n" + "}";
			}

			wiData = wiData.replaceAll("''", "'");

			// Rider Validations

			JSONParser jsonParser = new JSONParser();
			JSONObject json = (JSONObject) jsonParser.parse(wiData);
			String sessionIDJSON = json.get("SessionID").toString();

			// String sessionID="";
			if (!sessionIDJSON.equalsIgnoreCase("") && sessionIDJSON != null) {
				sessionID = sessionIDJSON;
			}
			// else
			// sessionID = CommonFunctions.getSessionID();

			if (sessionID.equalsIgnoreCase("Invalid Session ID!")) {
				return "Invalid Session ID!";
			}

			try {
				result = uploadWI(wiData);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			logger.info("Disconnecting User...");
			String disUserXML = CommonFunctions.disconnectUser(sessionID);

		} catch (Exception e) {
			JSONObject errorJson = new JSONObject();
			logger.info("Exception"+e);
			e.printStackTrace();
			errorJson.put("msgInfo", createErrorJson("500", "Exception"));
			result = errorJson.toString();
		}
		return result;
	}

	private String caseType(String wiData, String cabinetName)
			throws ParseException, FileNotFoundException, IOException {
		JSONParser jsonParser = new JSONParser();
		JSONObject json = (JSONObject) jsonParser.parse(wiData);

		JSONObject PolicyAgentCustomerObj = (JSONObject) jsonParser
				.parse(json.getOrDefault("PolicyAgentCustomerInfo", "{}").toString());
		JSONObject PolicyDetailsObj = (JSONObject) jsonParser
				.parse(PolicyAgentCustomerObj.get("PolicyDetails").toString());
		String Product_Name = (String) PolicyDetailsObj.get("ProductName");

		String query = "SELECT PRODUCT_TYPE FROM NG_NB_MS_PLAN_CODE(NOLOCK) WHERE PLAN_CODE = '" + Product_Name + "'";
		String inputXML = XMLGen.APSelectWithColumnNames(cabinetName, query, sessionID);
		logger.info("APSelectWithColumnNames_Input_inputXML: " + inputXML);
		// String outputXML = WFCallBroker.execute(inputXML, "192.168.54.97",
		// 3333, 1);
		String outputXML = CommonFunctions.callRestAPI_JTS(inputXML);
		logger.info("APSelectWithColumnNames_outputXML: " + outputXML);

		String productType = "";
		if (outputXML.indexOf("<PRODUCT_TYPE>") != -1)
			productType = outputXML.substring(outputXML.indexOf("<PRODUCT_TYPE>") + 14,
					outputXML.indexOf("</PRODUCT_TYPE>"));
		return productType;
	}
	private String ISCOMBO(String wiData, String cabinetName)
			throws ParseException, FileNotFoundException, IOException {
		JSONParser jsonParser = new JSONParser();
		JSONObject json = (JSONObject) jsonParser.parse(wiData);

		JSONObject FlagsObj = (JSONObject) jsonParser
				.parse(json.getOrDefault("Flags", "{}").toString());
		
		String ISCOMBO = FlagsObj.getOrDefault("ISCOMBO","").toString();
		String productType = "";
		if(ISCOMBO.equalsIgnoreCase("Y"))
		{
			 productType="COMBO";
		}
		return productType;
	}

	public String uploadWI(String wiData) throws IOException, Exception {
		String attributesXML = "", wfuploadXML = "", failFlag = "",attributesXML_COMBO="",wfuploadXML_COMBO="",failFlag_COMBO="";
		;
		try {
			propertiesFileData = new Properties();
			Properties props = new Properties();

			String configPath = System.getProperty("user.dir") + File.separator
					+ "CreateWorkitemService\\log4j.properties";
			props.load(new FileInputStream(configPath));
			PropertyConfigurator.configure(props);

			configPath = System.getProperty("user.dir") + File.separator + "CreateWorkitemService\\config.properties";
			FileReader reader = new FileReader(configPath);

			logger.info("configPath: " + configPath);

			propertiesFileData = new Properties();
			propertiesFileData.load(reader);

			String msgCode = "200", msg = "Success";

			String cabinetName = propertiesFileData.getProperty("cabinetName");
			String ipAddress = propertiesFileData.getProperty("ipAddress");
			String username = propertiesFileData.getProperty("username");
			String password = propertiesFileData.getProperty("password");
			String processDefId = propertiesFileData.getProperty("processDefId");
			String port = propertiesFileData.getProperty("port");
			String volID = propertiesFileData.getProperty("volID");
			String multipleDocAllowed = propertiesFileData.getProperty("multipleDocAllowed");

			JSONParser jsonParser = new JSONParser();
			JSONObject json = (JSONObject) jsonParser.parse(wiData);

			// String documentDetail=json.get("DocumentDetail").toString();

			// Creating Document Tag
			String documentsTag = "";
			// (JSONArray) jsonParser.parse(json.get("DocumentDetail");
			JSONArray documentsArr = (JSONArray) json.get("DocumentDetail");
			for (Object tag : documentsArr) {
				JSONObject jsonObj = (JSONObject) tag;
				documentsTag = documentsTag + jsonObj.get("documentName") + (char) 21 + jsonObj.get("documentIndex")
						+ "#" + jsonObj.get("volumeId") + (char) 21 + jsonObj.get("noOfPages") + (char) 21
						+ jsonObj.get("documentSize") + (char) 21 + jsonObj.get("extension") + (char) 21
						+ jsonObj.get("documentName") + (char) 25;
			}
			logger.info("documentsTag:" + documentsTag);
		
			
			
			String documentsTagCOMBO = "";
			// (JSONArray) jsonParser.parse(json.get("DocumentDetail");
			JSONArray documentsArrCOMBO = (JSONArray) json.getOrDefault("ComboDocumentDetail",new JSONArray());
			for (Object tag : documentsArrCOMBO) {
				JSONObject jsonObj = (JSONObject) tag;
				documentsTagCOMBO = documentsTagCOMBO + jsonObj.get("documentName") + (char) 21 + jsonObj.get("documentIndex")
						+ "#" + jsonObj.get("volumeId") + (char) 21 + jsonObj.get("noOfPages") + (char) 21
						+ jsonObj.get("documentSize") + (char) 21 + jsonObj.get("extension") + (char) 21
						+ jsonObj.get("documentName") + (char) 25;
			}
			logger.info("documentsTagCOMBO:" + documentsTagCOMBO);

			JSONObject jsonValidate = new JSONObject();

			// Variables Declaration
			// QC_Summary->ProposerDetails
				String Prop_Salutation = "", Prop_FirstName = "", Prop_MiddleName = "", Prop_LastName = "",
					Prop_Address = "", Prop_DOB = "", Prop_Gender = "", Prop_Mobile = "", Prop_Email = "",
					Prop_PAN = "", Prop_FatherName = "", Prop_TotalAFYP = "", Prop_BankName = "", Prop_AccountNo = "",
					Prop_IFSC = "", Prop_CKYC = "", Proposer_Tag1 = "", Proposer_Tag2 = "", Proposer_Tag3 = "",
					Proposer_Tag4 = "", Proposer_Reason1 = "", Proposer_Reason2 = "", Proposer_Reason3 = "",
					Proposer_Reason4 = "";
			// QC_Summary->LifeInsuredDetails
			String Insured_Salutation = "", Insured_FirstName = "", Insured_MiddleName = "", Insured_LastName = "",
					Insured_Gender = "", Insured_TSA = "", Insured_DOB = "", Insured_Tag1 = "", Insured_Tag2 = "",
					Insured_Tag3 = "", Insured_Tag4 = "", Insured_Reason1 = "", Insured_Reason2 = "",
					Insured_Reason3 = "", Insured_Reason4 = "";
			// QC-Summary->PayorDetails
			String Payor_salutation = "", Payor_FirstName = "", Payor_MiddleName = "", Payor_LastName = "",
					Payor_PAN = "", Payor_Address = "", Payor_Gender = "", Payor_BankName = "", Payor_AccountNo = "",
					Payor_IFSC = "", Payor_DOB = "", Payor_Tag1 = "", Payor_Tag2 = "", Payor_Tag3 = "", Payor_Tag4 = "",
					Payor_Reason1 = "", Payor_Reason2 = "", Payor_Reason3 = "", Payor_Reason4 = "";
			// PolicyAgentCustomerInfo->AgentDetails
			String Agent_Code = "", GO_code = "", Agent_Name = "", Agent_Contact_Number = "", Branch_Name = "",
					Channel = "", Agent_Joining_Date = "", Agent_Status = "", Current_AML_Start_Date = "",
					Current_AML_End_Date = "", Previous_AML_Start_Date = "", Previous_AML_End_Date = "",
					Current_ULIP_Start_Date = "", Current_ULIP_End_Date = "", Previous_ULIP_Start_Date = "",
					Previous_ULIP_End_Date = "", Reporting_Manager_Code = "", Reporting_Manager_Name = "";
			// PolicyAgentCustomerInfo->PolicyDetails
			String Product_Name = "", Objective_of_insurance = "", Need = "", Life_Stage = "", Proposal_No = "",
					mPRO_initiation_date = "", App_Recvd_date_from_mPRO = "", Rural_urban_Social = "",
					Product_Solution = "", Combo_Proposal_Number = "", Previous_Proposal_Number = "",
					Source_of_Sale = "", SPARC_lead_Source = "", QROPS = "";
			// PolicyAgentCustomerInfo->CEIPDetails
			String Business_Type = "", BDM_id = "", Enroller_id = "", Finder_id = "", Name_of_company = "";
			// PolicyAgentCustomerInfo->DefenceDetails
			String Defence_Channel_Case = "", Army_Number = "", Unit_Name = "";
			// PolicyAgentCustomerInfo->CustomerInformation
			String Customer_Sign_Date = "", Customer_ID = "", Customer_classification = "",
					YBL_Customer_Classification = "", Is_this_a_replacement_policy_sale = "";
			// PolicyAgentCustomerInfo->AgentInformation
			String Agent_Sign_Date = "", Agent_Code2 = "", Agent_Name2 = "", Commission_Share = "",
					SP_CERTIFICATE_NO = "", SOL_ID = "", SSN_code = "", Application_ID = "", WMS_Sr_No = "",
					Application_Received_Prior = "";
			// PolicyAgentCustomerInfo->Customer
			String INVESTOR_RISK_PROFILE_SCORE = "";
			// PersonalInformation->ProposerDetails //adhaar ack number issue
			String Q_Personal_Proposer_Details_Client_type = "", Q_Personal_Proposer_Details_Title = "",
					Q_Personal_Proposer_Details_Last_Name = "", Q_Personal_Proposer_Details_Please_Specify = "",
					Q_Personal_Proposer_Details_First_Name = "", Q_Personal_Proposer_Details_Middle_Name = "",
					Q_Personal_Proposer_Details_FatherHusband_Name = "",
					Q_Personal_Proposer_Details_Date_of_Incorporation = "",
					Q_Personal_Proposer_Details_Date_of_Birth = "", Q_Personal_Proposer_Details_Pan_Number = "",
					Q_Personal_Proposer_Details_Applied_for = "", Q_Personal_Proposer_Details_Date_of_Application = "",
					Q_Personal_Proposer_Details_Application_Number = "", Q_Personal_Proposer_Details_Gender = "",
					Q_Personal_Proposer_Details_Nationality = "", Q_Personal_Proposer_Details_Business_Source = "",
					Q_Personal_Proposer_Details_Marital_Status = "", Q_Personal_Proposer_Details_Education = "",
					Q_Personal_Proposer_Details_Industry_Type_mPRO = "",
					Q_Personal_Proposer_Details_Please_Specify2 = "",
					Q_Personal_Proposer_Details_Organization_Type_mPRO = "",
					Q_Personal_Proposer_Details_Income_source = "", Q_Personal_Proposer_Details_Please_Specify3 = "",
					Q_Personal_Proposer_Details_Occupation_mPRO = "", Q_Personal_Proposer_Details_Please_Specify4 = "",
					Q_Personal_Proposer_Details_Exact_income = "", Q_Personal_Proposer_Details_Life_Proposer = "",
					Q_Personal_Proposer_Details_Country1 = "", Q_Personal_Proposer_Details_Please_Specify5 = "",
					Q_Personal_Proposer_Details_Pin_Code1 = "", Q_Personal_Proposer_Details_HouseNo_Society1 = "",
					Q_Personal_Proposer_Details_Road_Area_Sector1 = "", Q_Personal_Proposer_Details_Landmark1 = "",
					Q_Personal_Proposer_Details_Village_Town1 = "", Q_Personal_Proposer_Details_City_District1 = "",
					Q_Personal_Proposer_Details_State_UT1 = "", Q_Personal_Proposer_Details_MobileNo_1_1 = "",
					Q_Personal_Proposer_Details_MobileNo_2_1 = "", Q_Personal_Proposer_Details_LandlineNo_1_1 = "",
					Q_Personal_Proposer_Details_LandlineNo_2_1 = "",
					Q_Personal_Proposer_Details_LandlineNo_STD_1_1 = "",
					Q_Personal_Proposer_Details_LandlineNo_STD_2_1 = "", Q_Personal_Proposer_Details_EmailId = "",
					Q_Personal_Proposer_Details_Address_Proposer = "", Q_Personal_Proposer_Details_Date_of_Issue = "",
					Q_Personal_Proposer_Details_Date_of_Expiry = "", Q_Personal_Proposer_Details_ID_Proposer = "",
					Q_Personal_Proposer_Details_Proof_Number = "",
					Q_Personal_Proposer_Details_Date_IssueIdentity_Proof = "",
					Q_Personal_Proposer_Details_Date_expiry_Identity_Proof = "",
					Q_Personal_Proposer_Details_e_Insurance = "", Q_Personal_Proposer_Details_EIA_available = "",
					Q_Personal_Proposer_Details_EIA_Number = "", Q_Personal_Proposer_Details_Repositoryaccount_1 = "",
					Q_Personal_Proposer_Details_Annuity = "", Q_Personal_Proposer_Details_Aadhaar_Number = "",
					Q_Personal_Proposer_Details_Aadhaar_Enrol_Ack_number = "",
					Q_Personal_Proposer_Details_Company_Type = "",
					Q_Personal_Proposer_Details_Preferred_language_English = "";
			// PersonalInformation->L2BIDetails //Q_Personal_Other_Occupation
			// issue
			String Q_Personal_Other_Client_type1 = "", Q_Personal_Other_Title1 = "", Q_Personal_Other_specify1 = "",
					Q_Personal_Other_First_Name1 = "", Q_Personal_Other_Middle_Name1 = "",
					Q_Personal_Other_Last_Name1 = "", Q_Personal_Other_Father_Husband_Name = "",
					Q_Personal_Other_Date_of_Birth1 = "", Q_Personal_Other_Gender1 = "",
					Q_Personal_Other_Relationship_with_insured = "", Q_Personal_Other_specify2 = "",
					Q_Personal_Other_Nationality1 = "", Q_Personal_Other_Business_Source = "",
					Q_Personal_Other_Marital_Status = "", Q_Personal_Other_Education = "",
					Q_Personal_Other_Industry_Type = "", Q_Personal_Other_Specify3 = "",
					Q_Personal_Other_Organization_Type = "", Q_Personal_Other_Income_source = "",
					Q_Personal_Other_Specify4 = "", Q_Personal_Other_Occupation = "", Q_Personal_Other_Specify5 = "",
					Q_Personal_Other_Exact_income = "";
			// PersonalInformation->NomineeDetails
			String Q_Personal_Other_Client_type2 = "", Q_Personal_Other_select_value = "",
					Q_Personal_Other_Objective_Insurance = "", Q_Personal_Other_Title2 = "",
					Q_Personal_Other_Specify6 = "", Q_Personal_Other_First_Name2 = "",
					Q_Personal_Other_Middle_Name2 = "", Q_Personal_Other_Last_Name2 = "", Q_Personal_Other_DOB2 = "",
					Q_Personal_Other_Gender2 = "", Q_Personal_Other_Relationship_with_Nominee = "",
					Q_Personal_Other_Specify7 = "", Q_Personal_Other_Reason_for_Nomination = "",
					Q_Personal_Other_Percentage_share = "", Q_Personal_Other_Nominee_Type = "",
					Q_Personal_Other_Pan_Number = "", Q_Personal_Other_Applied_for = "",
					Q_Personal_Other_Date_of_Application = "", Q_Personal_Other_Application_Acknowledgement_Number = "",
					Q_Personal_Other_Nationality2 = "", Q_Personal_Other_please_select2 = "",
					Q_Personal_Other_Business_Source2 = "", Q_Personal_Other_Current_residential_Address = "",
					Q_Personal_Other_Same_as_Proposer2 = "", Q_Personal_Other_Country3 = "",
					Q_Personal_Other_specify9 = "", Q_Personal_Other_Pin_Code = "",
					Q_Personal_Other_HouseNo_Society = "", Q_Personal_Other_Road_Area_Sector = "",
					Q_Personal_Other_Landmark = "", Q_Personal_Other_Village_Town = "",
					Q_Personal_Other_City_District = "", Q_Personal_Other_State_UT = "",
					Q_Personal_Other_MobileNo_1 = "", Q_Personal_Other_MobileNo_2 = "",
					Q_Personal_Other_LandlineNo_1 = "", Q_Personal_Other_LandlineNo_2 = "",
					Q_Personal_Other_STD_LandlineNo_1 = "", Q_Personal_Other_STD_LandlineNo_2 = "",
					Q_Personal_Other_Email_Id = "";
			// PersonalInformation->AppointeeDetails
			String Q_Personal_Other_First_Name3 = "", Q_Personal_Other_Middle_Name3 = "",
					Q_Personal_Other_Last_Name3 = "", Q_Personal_Other_Relationship_of_apointee_nominee = "",
					Q_Personal_Other_specify8 = "";
			// PersonalInformation->ChildDetails
			String Q_Personal_Other_Client_type3 = "", Q_Personal_Other_Same_as_Nominee = "",
					Q_Personal_Other_First_Name4 = "", Q_Personal_Other_Middle_Name4 = "",
					Q_Personal_Other_Last_Name4 = "", Q_Personal_Other_DOB4 = "";
			// PersonalInformation->PolicyValidationsDetails
			String Q_Personal_Other_straight_pass_case = "", Q_Personal_Other_Dedupe_exact_match = "",
					Q_Personal_Other_PAN_authentication = "", Q_Personal_Other_ID_DOB_authentication = "",
					Q_Personal_Other_OCR_ID = "", Q_Personal_Other_DOB_ID = "", Q_Personal_Other_Pan_Status = "",
					Q_Personal_Other_Proof_of_Address = "", Q_Personal_Other_Income_proof_Proposer = "",
					Q_Personal_Other_Address_proof = "", Q_Personal_Other_OCR_address_proof = "",
					Q_Personal_Other_OCR_NACH = "", Q_Personal_Other_eNACH_eMandate = "",
					Q_Personal_Other_OCR_photograph = "", Q_Personal_Other_OCR_Cheque = "",
					Q_Personal_Other_Credit_Score = "", Q_Personal_Other_Income_segment = "", Q_Personal_Other_BSE = "";
			// ProductAndPaymentInfo -> Bank Details
			String B_A_No = "", B_A_Holder_name = "", B_MICR = "", B_IFSC = "", B_Bname_branch = "", B_TypeOfB = "";
			// ProductAndPaymentInfo -> Coverage Details
			String Q_COVERAGE_DETAILS_PRODUCT_NAME = "", Q_COVERAGE_DETAILS_VESTING_AGE = "",
					Q_COVERAGE_DETAILS_COVERAGE_TERM = "", Q_COVERAGE_DETAILS_PREMIUM_PAY_TERM = "",
					Q_COVERAGE_DETAILS_PREMIUM_BACK = "", Q_COVERAGE_DETAILS_COVERAGE_MULTIPLE = "",
					Q_COVERAGE_DETAILS_SUM_ASSURED = "", Q_COVERAGE_DETAILS_DEATH_BENEFIT = "",
					Q_COVERAGE_DETAILS_ATP = "", Q_COVERAGE_DETAILS_MODE_OF_PAY = "",
					Q_COVERAGE_DETAILS_MODAL_PREMIUM = "", Q_COVERAGE_DETAILS_GST = "",
					Q_COVERAGE_DETAILS_SAVE_MORE_TOMORROW = "", Q_COVERAGE_DETAILS_EMP_DISCOUNT = "",
					Q_COVERAGE_DETAILS_EXISTING_CUST_DISCOUNT = "", Q_COVERAGE_DETAILS_SMOKER_CLASS = "",
					Q_COVERAGE_DETAILS_LIFE_EVENT = "", Q_COVERAGE_DETAILS_GUARANTEE_MON_INCOME = "",
					Q_COVERAGE_DETAILS_GUARANTEE_ANNUAL_INCOME = "", Q_COVERAGE_DETAILS_GIP_PAYOUT_DAY = "",
					Q_COVERAGE_DETAILS_GIP_PAYOUT_METHOD = "", Q_COVERAGE_DETAILS_NON_FORFEITURE = "",
					Q_COVERAGE_DETAILS_BONUS_OPTION = "", Q_COVERAGE_DETAILS_EFFECTIVE_DATE = "";
			// ProductAndPaymentInfo -> Financial Information
			String Q_PRODUCT_AND_PAYMENT_INFO_Sourceoffunds = "", L_IncomeProof = "",
					Q_PRODUCT_AND_PAYMENT_INFO_Doyouownavehicle = "", Q_PRODUCT_AND_PAYMENT_INFO_Wheeler2 = "",
					Q_PRODUCT_AND_PAYMENT_INFO_priceofpurchase1 = "", Q_PRODUCT_AND_PAYMENT_INFO_Wheeler4 = "",
					Q_PRODUCT_AND_PAYMENT_INFO_priceofpurchase2 = "";
			// ProductAndPaymentInfo -> Fund Selected
			String Q_PRODUCT_AND_PAYMENT_INFO_Dynamicfundallocation = "",
					Q_PRODUCT_AND_PAYMENT_INFO_Investerprofile = "",
					Q_PRODUCT_AND_PAYMENT_INFO_Systematictransferfund = "", Q_PRODUCT_AND_PAYMENT_INFO_FundName = "",
					Q_PRODUCT_AND_PAYMENT_INFO_Initialallocation = "",
					Q_PRODUCT_AND_PAYMENT_INFO_Totalfundallocation = "";
			// ProductAndPaymentInfo -> NEFT Details
			String Payout_to_Account = "", Q_PRODUCT_AND_PAYMENT_INFO_BankAccountNumber1 = "",
					Q_PRODUCT_AND_PAYMENT_INFO_AccountHoldername1 = "", Q_PRODUCT_AND_PAYMENT_INFO_MICRCode1 = "",
					Q_PRODUCT_AND_PAYMENT_INFO_IFSCCode1 = "", Q_PRODUCT_AND_PAYMENT_INFO_BankNameandBranch1 = "",
					Q_PRODUCT_AND_PAYMENT_INFO_TypeofBankAccount1 = "",
					Q_PRODUCT_AND_PAYMENT_INFO_BankAccountNumber2 = "",
					Q_PRODUCT_AND_PAYMENT_INFO_AccountHoldername2 = "", Q_PRODUCT_AND_PAYMENT_INFO_MICRCode2 = "",
					Q_PRODUCT_AND_PAYMENT_INFO_IFSCCode2 = "", Q_PRODUCT_AND_PAYMENT_INFO_BankNameandBranch2 = "",
					Q_PRODUCT_AND_PAYMENT_INFO_TypeofBankAccount2 = "";
			String Payout_to_Account_ANN = "", Q_PRODUCT_AND_PAYMENT_INFO_BankAccountNumber1_ANN = "",
					Q_PRODUCT_AND_PAYMENT_INFO_AccountHoldername1_ANN = "", Q_PRODUCT_AND_PAYMENT_INFO_MICRCode1_ANN = "",
					Q_PRODUCT_AND_PAYMENT_INFO_IFSCCode1_ANN = "", Q_PRODUCT_AND_PAYMENT_INFO_BankNameandBranch1_ANN = "",
					Q_PRODUCT_AND_PAYMENT_INFO_TypeofBankAccount1_ANN = "";
	
			// ProductAndPaymentInfo -> Payment Details
			String Q_PRODUCT_AND_PAYMENT_INFO_InitialPremiumPaid = "",
					Q_PRODUCT_AND_PAYMENT_INFO_InitialPremiumMethod = "",
					Q_PRODUCT_AND_PAYMENT_INFO_CashletterReceived = "";
			// ProductAndPaymentInfo -> Renewal Premium Details
			String Q_PRODUCT_AND_PAYMENT_INFO_RenewalPremiumMethod = "", Q_PRODUCT_AND_PAYMENT_INFO_CompanyName = "",
					Q_PRODUCT_AND_PAYMENT_INFO_BillDrawDate1 = "", Q_PRODUCT_AND_PAYMENT_INFO_payor_same1 = "",
					Q_PRODUCT_AND_PAYMENT_INFO_CCHolderName = "", Q_PRODUCT_AND_PAYMENT_INFO_CreditCardNo = "",
					Q_PRODUCT_AND_PAYMENT_INFO_CCExpiryDate = "", Q_PRODUCT_AND_PAYMENT_INFO_CreditcardType = "",
					Q_PRODUCT_AND_PAYMENT_INFO_ECS_datails = "", Q_PRODUCT_AND_PAYMENT_INFO_payor_same2 = "",
					Q_PRODUCT_AND_PAYMENT_INFO_BankAccountNumber = "", Q_PRODUCT_AND_PAYMENT_INFO_MICRCode = "",
					Q_PRODUCT_AND_PAYMENT_INFO_AccountHolderName = "", Q_PRODUCT_AND_PAYMENT_INFO_BillDrawDate2 = "",
					Q_PRODUCT_AND_PAYMENT_INFO_IFSCCode = "", Q_PRODUCT_AND_PAYMENT_INFO_BankNameandBranch = "",
					Q_PRODUCT_AND_PAYMENT_INFO_TypeofBankAccount = "",
					Q_PRODUCT_AND_PAYMENT_INFO_PayorisdifferentfromProposer = "",
					Q_PRODUCT_AND_PAYMENT_INFO_Relationshipofpayorwithproposer = "";
			// ProductAndPaymentInfo -> Payor Pan Details
			String Q_PRODUCT_AND_PAYMENT_INFO_PayorsFirstName = "", Q_PRODUCT_AND_PAYMENT_INFO_Middle = "",
					Q_PRODUCT_AND_PAYMENT_INFO_Last = "", Q_PRODUCT_AND_PAYMENT_INFO_Dateofbirth = "",
					Q_PRODUCT_AND_PAYMENT_INFO_Gender = "", Q_PRODUCT_AND_PAYMENT_INFO_PayorsPanNumber = "",
					AppliedFor = "", Q_PRODUCT_AND_PAYMENT_INFO_DateofApplication = "",
					Q_PRODUCT_AND_PAYMENT_INFO_ApplicationAcknowledgementNumber = "",
					Q_PRODUCT_AND_PAYMENT_INFO_PayorClientId = "";
			// MedicalAndPreviousInfo ->Family Information
			String Q_Medical_AND_PREV_POLICY_INFO_Plan_Insured_Details = "",
					Q_Medical_AND_PREV_POLICY_INFO_Family_Diagonosed = "",
					Q_Medical_AND_PREV_POLICY_INFO_Family_Member = "",
					Q_Medical_AND_PREV_POLICY_INFO_Age_at_diagnosis = "",
					Q_Medical_AND_PREV_POLICY_INFO_conditions = "";
			// MedicalAndPreviousInfo ->Female Information
			String Q_Medical_AND_PREV_POLICY_INFO_Spouse_Details = "", Q_Medical_AND_PREV_POLICY_INFO_details5 = "",
					Q_Medical_AND_PREV_POLICY_INFO_Occupation = "", Q_Medical_AND_PREV_POLICY_INFO_Income = "",
					Q_Medical_AND_PREV_POLICY_INFO_Insuranceamount = "",
					Q_Medical_AND_PREV_POLICY_INFO_FullMaidenName = "", Q_Medical_AND_PREV_POLICY_INFO_pregnant = "",
					Q_Medical_AND_PREV_POLICY_INFO_months = "",
					Q_Medical_AND_PREV_POLICY_INFO_Areantenatalreportsattached = "";
			// MedicalAndPreviousInfo ->Habit Questions
			String Q_Habit_tobacco = "", Q_Habit_PanMasala = "", Q_Habit_Cigarettes = "", Q_Habit_Beedi = "",
					Q_Habit_Gutkha = "", Q_Habit_alcohol = "", Q_Habit_Beer = "", Q_Habit_Wine = "",
					Q_Habit_HardLiquor = "", Q_Habit_drugs = "", Q_Habit_Cannabis = "", Q_Habit_Marijuana = "",
					Q_Habit_Ecstacy = "", Q_Habit_Heroin = "", Q_Habit_LSD = "", Q_Habit_Amphetamines = "",
					Q_Habit_other = "", Q_Habit_Quantity1 = "", Q_Habit_PerDay1 = "", Q_Habit_NoofYears1 = "",
					Q_Habit_Quantity2 = "", Q_Habit_Quantity3 = "", Q_Habit_Quantity4 = "", Q_Habit_PerDay2 = "",
					Q_Habit_PerDay3 = "", Q_Habit_PerDay4 = "", Q_Habit_NoofYears2 = "", Q_Habit_NoofYears3 = "",
					Q_Habit_NoofYears4 = "", Q_Habit_Quantity5 = "", Q_Habit_NoofYears5 = "", Q_Habit_Quantity6 = "",
					Q_Habit_Quantity7 = "", Q_Habit_NoofYears6 = "", Q_Habit_NoofYears7 = "", Q_Habit_Qty8 = "",
					Q_Habit_NoofYears8 = "", Q_Habit_Qty9 = "", Q_Habit_Qty10 = "", Q_Habit_Qty11 = "",
					Q_Habit_Qty12 = "", Q_Habit_Qty13 = "", Q_Habit_Qty14 = "", Q_Habit_NoofYears9 = "",
					Q_Habit_NoofYears10 = "", Q_Habit_NoofYears11 = "", Q_Habit_NoofYears12 = "",
					Q_Habit_NoofYears13 = "", Q_Habit_NoofYears14 = "";
			// MedicalAndPreviousInfo ->Height and weight
			String Q_Medical_AND_PREV_POLICY_INFO_Height_in = "", Q_Medical_AND_PREV_POLICY_INFO_InFeet = "",
					Q_Medical_AND_PREV_POLICY_INFO_InInches = "", Q_Medical_AND_PREV_POLICY_INFO_InCms = "",
					Q_Medical_AND_PREV_POLICY_INFO_Weight = "", Q_Medical_AND_PREV_POLICY_INFO_details6 = "",
					Q_Medical_AND_PREV_POLICY_INFO_change_in_weight = "", Q_Medical_AND_PREV_POLICY_INFO_details7 = "",
					Q_Medical_AND_PREV_POLICY_INFO_ReasonforWeightChange = "", Q_Medical_AND_PREV_POLICY_INFO_ByKg = "";
			// MedicalAndPreviousInfo ->Juvenille info
			String Q_Medical_AND_PREV_POLICY_INFO_child_vaccinations = "", Q_Medical_AND_PREV_POLICY_INFO_Details2 = "",
					Q_Medical_AND_PREV_POLICY_INFO_Insurance_coverage_parents = "",
					Q_Medical_AND_PREV_POLICY_INFO_Details3 = "",
					Q_Medical_AND_PREV_POLICY_INFO_Insurance_Siblings = "",
					Q_Medical_AND_PREV_POLICY_INFO_Details4 = "",
					Q_Medical_AND_PREV_POLICY_INFO_Parents_Siblings_Insurance_ack = "";
			// MedicalAndPreviousInfo ->Life Style
			String Q_Medical_AND_PREV_POLICY_INFO_hazardous_activities = "",
					Q_Medical_AND_PREV_POLICY_INFO_Specify = "", Q_Medical_AND_PREV_POLICY_INFO_details = "",
					Q_Medical_AND_PREV_POLICY_INFO_travel_abroad = "", Q_Medical_AND_PREV_POLICY_INFO_Country = "",
					Q_Medical_AND_PREV_POLICY_INFO_City = "", Q_Medical_AND_PREV_POLICY_INFO_Purpose = "",
					Q_Medical_AND_PREV_POLICY_INFO_DurationofStay = "", Q_Medical_AND_PREV_POLICY_INFO_convicted = "",
					Q_Medical_AND_PREV_POLICY_INFO_details1 = "";
			// MedicalAndPreviousInfo ->Medical Questions
			String Q_Medical_AND_PREV_POLICY_INFO_Chest_pain = "",
					Q_Medical_AND_PREV_POLICY_INFO_Hypertension_Highbp = "",
					Q_Medical_AND_PREV_POLICY_INFO_Diabetes = "", Q_Medical_AND_PREV_POLICY_INFO_Asthma = "",
					Q_Medical_AND_PREV_POLICY_INFO_Hormonal_disorders = "",
					Q_Medical_AND_PREV_POLICY_INFO_liver_disorders = "",
					Q_Medical_AND_PREV_POLICY_INFO_Congenital_disorders = "",
					Q_Medical_AND_PREV_POLICY_INFO_Cancer_tumoror_growth = "",
					Q_Medical_AND_PREV_POLICY_INFO_kidney_disorder = "",
					Q_Medical_AND_PREV_POLICY_INFO_epilepsy_psychiatricdisorders = "",
					Q_Medical_AND_PREV_POLICY_INFO_ENT_disorders = "",
					Q_Medical_AND_PREV_POLICY_INFO_back_arthritis_disorders = "",
					Q_Medical_AND_PREV_POLICY_INFO_last5years_surgery = "",
					Q_Medical_AND_PREV_POLICY_INFO_any_other_illness = "", Q_Medical_AND_PREV_POLICY_INFO_Hiv_Aids = "",
					Q_Medical_AND_PREV_POLICY_INFO_OFFWORK = "",
					Q_Medical_AND_PREV_POLICY_INFO_attaching_medical_form = "";
			// MedicalAndPreviousInfo ->Other Medical info
			String Q_Medical_AND_PREV_POLICY_INFO_diagnosed_with_disability = "",
					Q_Medical_AND_PREV_POLICY_INFO_hospitalized = "",
					Q_Medical_AND_PREV_POLICY_INFO_familymember_diagnosed_before60 = "";
			// MedicalAndPreviousInfo ->Other Policy info
			String Q_Medical_AND_PREV_POLICY_INFO_insurance_pending = "",
					Q_Medical_AND_PREV_POLICY_INFO_PolicyNumber = "", Q_Medical_AND_PREV_POLICY_INFO_NameofCompany = "",
					Q_Medical_AND_PREV_POLICY_INFO_YearofIssue = "", Q_Medical_AND_PREV_POLICY_INFO_TypeofPolicy = "",
					Q_Medical_AND_PREV_POLICY_INFO_TotalSumAssued = "", Q_Medical_AND_PREV_POLICY_INFO_Reason = "",
					Q_Medical_AND_PREV_POLICY_INFO_Statusofpolicy = "",
					Q_Medical_AND_PREV_POLICY_INFO_insurance_refused = "",
					Q_Medical_AND_PREV_POLICY_INFO_PolicyNumber1 = "",
					Q_Medical_AND_PREV_POLICY_INFO_NameofCompany1 = "",
					Q_Medical_AND_PREV_POLICY_INFO_YearofIssue1 = "", Q_Medical_AND_PREV_POLICY_INFO_TypeofPolicy1 = "",
					Q_Medical_AND_PREV_POLICY_INFO_TotalSumAssued1 = "", Q_Medical_AND_PREV_POLICY_INFO_Reason1 = "",
					Q_Medical_AND_PREV_POLICY_INFO_Statusofpolicy1 = "";

			// Flags tag
			JSONObject FlagsObj = null;
			if (json.containsKey("Flags")) {
				FlagsObj = (JSONObject) jsonParser.parse(json.get("Flags").toString());
				attributesXML = attributesXML + "<DOCFLAG>" + FlagsObj.get("DOCFLAG").toString() + "</DOCFLAG>"
						+ "<CC_FLAG>" + FlagsObj.get("CC_FLAG").toString() + "</CC_FLAG>" + "<DISCREPANCY_FLAG>"
						+ FlagsObj.get("DISCREPANCY_FLAG").toString() + "</DISCREPANCY_FLAG>" + "<AUTO_UW_FLAG>"
						+ FlagsObj.get("AUTO_UW_FLAG").toString() + "</AUTO_UW_FLAG>" + "<MED_KICKOUT_FLAG>"
						+ FlagsObj.get("MED_KICKOUT_FLAG").toString() + "</MED_KICKOUT_FLAG>" + "<ADD_INFO_FLAG>"
						+ FlagsObj.get("ADD_INFO_FLAG").toString() + "</ADD_INFO_FLAG>" + "<DECISION>"
						+ FlagsObj.get("DECISION").toString() + "</DECISION>" + "<REQ_IN_FLAG>"
						+ FlagsObj.get("REQ_IN_FLAG").toString() + "</REQ_IN_FLAG>" + "<PI_ATTACHED>"
						+ FlagsObj.get("PI_ATTACHED").toString() + "</PI_ATTACHED>" + "<ULIP_CHECK>"
						+ FlagsObj.get("ULIP_CHECK").toString() + "</ULIP_CHECK>"

						+ "<SOURCING_SYSTEM>" + FlagsObj.get("SOURCING_SYSTEM").toString() + "</SOURCING_SYSTEM>"
						+ "<MONEY_STATUS>" + FlagsObj.get("MONEY_STATUS").toString() + "</MONEY_STATUS>"
						+ "<COLLECTED_AMOUNT>" + FlagsObj.get("COLLECTED_AMOUNT").toString() + "</COLLECTED_AMOUNT>"
						+ "<CLEARED_AMOUNT>" + FlagsObj.get("CLEARED_AMOUNT").toString() + "</CLEARED_AMOUNT>"
						+ "<BOUNCE_AMOUNT>" + FlagsObj.get("BOUNCE_AMOUNT").toString() + "</BOUNCE_AMOUNT>"
						+ "<COMM_CT>" + FlagsObj.getOrDefault("uinchange","").toString() + "</COMM_CT>"
						+ "<payment_Date>" + FlagsObj.getOrDefault("PAYMENT_DATE","").toString() + "</payment_Date>"
						+ "<NEW_TO_YBL>" + FlagsObj.getOrDefault("ISPROSPECTIVEYBLCUSTOMER","").toString() + "</NEW_TO_YBL>"
						+ "<INITIATIVE_TYPE>" + FlagsObj.getOrDefault("INITIATIVE_TYPE","").toString() + "</INITIATIVE_TYPE>"
						+ "<RULE_RUN>" + FlagsObj.getOrDefault("RULE_RUN","").toString() + "</RULE_RUN>"
						+ "<INSTA_COI>" + FlagsObj.getOrDefault("INSTA_COI","").toString() + "</INSTA_COI>"
						+ "<IS_COMBO>" + FlagsObj.getOrDefault("ISCOMBO","").toString() + "</IS_COMBO>"
						+ "<IIB_REQUEST_TIMESTAMP>" + FlagsObj.getOrDefault("IIB_REQUEST_TIMESTAMP","").toString() + "</IIB_REQUEST_TIMESTAMP>"
						+ "<IIB_RESPONSE_TIMESTAMP>" + FlagsObj.getOrDefault("IIB_RESPONSE_TIMESTAMP","").toString() + "</IIB_RESPONSE_TIMESTAMP>"
						+ "<IIB_SERVICE_STATUS>" + FlagsObj.getOrDefault("IIB_SERVICE_STATUS","").toString() + "</IIB_SERVICE_STATUS>"
						+ "<pasaLead>" + FlagsObj.getOrDefault("pasaLead","").toString() + "</pasaLead>"
						+ "<ING_BATCH_DATE>" + FlagsObj.getOrDefault("ING_BATCH_DATE","").toString() + "</ING_BATCH_DATE>"
						+ "<GOVERN_FLAG>" + FlagsObj.getOrDefault("GOVERN_FLAG","").toString() + "</GOVERN_FLAG>"
						+ "<GOVERN_RULE_EXE>" + FlagsObj.getOrDefault("GOVERN_RULE_EXE","").toString() + "</GOVERN_RULE_EXE>"
						+ "<MPRO_AUTO_UW_FLAG>" + FlagsObj.getOrDefault("MPRO_AUTO_UW_FLAG","").toString() + "</MPRO_AUTO_UW_FLAG>"
						+ "<MPRO_CC_FLAG>" + FlagsObj.getOrDefault("MPRO_CC_FLAG","").toString() + "</MPRO_CC_FLAG>"
						+ "<PHYSICALOGIN>" + FlagsObj.getOrDefault("PHYSICALOGIN","").toString() + "</PHYSICALOGIN>"
						+ "<ISQA>" + FlagsObj.getOrDefault("ISQA","").toString() + "</ISQA>"
						+ "<MPRO_HOST>" + FlagsObj.getOrDefault("MPRO_HOST","").toString() + "</MPRO_HOST>"
						+ "<IS_JOINTLIFE>" + FlagsObj.getOrDefault("IS_JOINTLIFE","").toString() + "</IS_JOINTLIFE>"
						+ "<IS_SWISSRE_MPRO>" + FlagsObj.getOrDefault("IS_SWISSRE","").toString() + "</IS_SWISSRE_MPRO>"	//DR-24067 MANSI
						+ "<ISCUSTOMERVALIDATED>" + FlagsObj.getOrDefault("ISCUSTOMERVALIDATED","").toString() + "</ISCUSTOMERVALIDATED>"	//DR-24067 MANSI
						+ "<pennyDrop>" + FlagsObj.getOrDefault("pennyDrop","").toString() + "</pennyDrop>"	//dr-23916 mansi
						+ "<Exception>" + FlagsObj.getOrDefault("Exception","").toString() + "</Exception>"	//DR-28122 sparsh
						+ "<journeyIdentifier>" + FlagsObj.getOrDefault("journeyIdentifier","").toString() + "</journeyIdentifier>" // DR-33511 mansi
						+ "<GSCancellation>" + FlagsObj.getOrDefault("GSCancellation","").toString() + "</GSCancellation>" //DR-33564 mansi
						+ "<sourceChannel>" + FlagsObj.getOrDefault("sourceChannel","").toString() + "</sourceChannel>"
						+ "<diyJourneyType>" + FlagsObj.getOrDefault("diyJourneyType","").toString() + "</diyJourneyType>"
						+ "<aIEstimatedIncome>" + FlagsObj.getOrDefault("aIEstimatedIncome","").toString() + "</aIEstimatedIncome>"
						+ "<aIScoreResult>" + FlagsObj.getOrDefault("aIScoreResult","").toString() + "</aIScoreResult>"
						+ "<greenChannel>" + FlagsObj.getOrDefault("greenChannel","").toString() + "</greenChannel>" // DR-39470 mansi
						+ "<persistencyScore>" + FlagsObj.getOrDefault("persistencyScore","").toString() + "</persistencyScore>" //DR-40097 dron
						+ "<persistencyRiskTag>" + FlagsObj.getOrDefault("persistencyRiskTag","").toString() + "</persistencyRiskTag>" //DR-40097 dron
						+ "<isDhuCase>" + FlagsObj.getOrDefault("isDhuCase","").toString() + "</isDhuCase>"
						+ "<IsSuperAnnuitionCase>" + FlagsObj.getOrDefault("IsSuperAnnuitionCase","").toString() + "</IsSuperAnnuitionCase>" 
						+ "<SPARK_CALL_REQUIRED>" + FlagsObj.getOrDefault("sparkCallRequired","").toString() + "</SPARK_CALL_REQUIRED>" // DR 48337 Ankit
						+ "<DIY_CASE>" + FlagsObj.getOrDefault("isDiyCase","").toString() + "</DIY_CASE>" //  added by ABHI DR 48460
						+ "<SP_VALIDATION>" + FlagsObj.getOrDefault("sp_Validation","").toString() + "</SP_VALIDATION>" //  added by ABHI DR 48460
						+ "<PPHI_FLAG>" + FlagsObj.getOrDefault("PPHIFieldsMandatory","").toString() + "</PPHI_FLAG>" // DR- 52700 Lovnish
						+ "<OCRStatusBS>" + FlagsObj.getOrDefault("OCRStatusBS","").toString() + "</OCRStatusBS>" // DR- 52462 sparsh
						+ "<OCRStatusSS>" + FlagsObj.getOrDefault("OCRStatusSS","").toString() + "</OCRStatusSS>" // DR- 52462 sparsh
						+ "<OCRStatusITR>" + FlagsObj.getOrDefault("OCRStatusITR","").toString() + "</OCRStatusITR>" // DR- 52462 sparsh
						;
			}

			// OtherTags
			JSONObject OtherTagsObj = null;
			if (json.containsKey("OtherTags")) {
				OtherTagsObj = (JSONObject) jsonParser.parse(json.get("OtherTags").toString());
				attributesXML = attributesXML
						// +
						// "<PROPOSER_CLIENT_ID>"+OtherTagsObj.get("ProposerClientId").toString()+"</PROPOSER_CLIENT_ID>"
						// +
						// "<INSURED_CLIENT_ID>"+OtherTagsObj.get("InsuredClientId").toString()+"</INSURED_CLIENT_ID>"
						// +
						// "<PAYOR_CLIENT_ID>"+OtherTagsObj.get("PayorClientId").toString()+"</PAYOR_CLIENT_ID>"
						// +
						// "<NOMINEE_CLIENT_ID1>"+OtherTagsObj.get("NomineeClientId1").toString()+"</NOMINEE_CLIENT_ID1>"
						// +
						// "<NOMINEE_CLIENT_ID2>"+OtherTagsObj.get("NomineeClientId2").toString()+"</NOMINEE_CLIENT_ID2>"
						// +
						// "<NOMINEE_CLIENT_ID3>"+OtherTagsObj.get("NomineeClientId3").toString()+"</NOMINEE_CLIENT_ID3>"
						// +
						// "<GUARDIAN_CLIENT_ID>"+OtherTagsObj.get("GuardianClientId").toString()+"</GUARDIAN_CLIENT_ID>"
						// +
						// "<CHILD_CLIENT_ID>"+OtherTagsObj.get("ChildClientId").toString()+"</CHILD_CLIENT_ID>"
						+ "<ADJUSTED_AFYP>" + OtherTagsObj.get("AdjustedAFYP").toString() + "</ADJUSTED_AFYP>"
						+ "<ADJUSTED_MFYP>" + OtherTagsObj.get("AdjustedMYFP").toString() + "</ADJUSTED_MFYP>"
				// +
				// "<PROPOSER_AGE>"+OtherTagsObj.get("ProposerAge").toString()+"</PROPOSER_AGE>"
				// +
				// "<INSURED_AGE>"+OtherTagsObj.get("InsuredAge").toString()+"</INSURED_AGE>"
				;
			}

			// PolicyAgentCustomerInfo tab
			JSONObject PolicyAgentCustomerObj = (JSONObject) jsonParser
					.parse(json.getOrDefault("PolicyAgentCustomerInfo", "{}").toString());

			// AgentDetails Section
			// JSONObject AgentDetailsObj = (JSONObject)
			// jsonParser.parse(PolicyAgentCustomerObj.get("AgentDetails").toString());
			JSONObject AgentDetailsObj = (JSONObject) jsonParser
					.parse(PolicyAgentCustomerObj.getOrDefault("AgentDetails", "{}").toString());

			JSONArray AgentGridArray;
			AgentGridArray = (JSONArray) AgentDetailsObj.get("AgentGrid");
			int insertionOrderId = 0, hashID = 1;

			for (Object j : AgentGridArray) {
				JSONObject jsonObj = (JSONObject) j;
				attributesXML = attributesXML + "<Q_LIST_AGENT_DETAILS_GRID>\r\n" + "<InsertionOrderId>"
						+ insertionOrderId + "</InsertionOrderId>" + "<HashId>" + hashID++ + "</HashId>" + "<GO_CODE>"
						+ jsonObj.get("GOCode").toString() + "</GO_CODE>" + "<AGENT_CODE>"
						+ jsonObj.get("AgentCode").toString() + "</AGENT_CODE>" + "<AGENT_NAME>"
						+ jsonObj.get("AgentName").toString() + "</AGENT_NAME>" + "<COMMISION_SHARE>"
						+ jsonObj.get("CommissionShare").toString() + "</COMMISION_SHARE>" + "<AGENT_CONTACT_NUMBER>"
						+ jsonObj.get("AgentContactNumber").toString() + "</AGENT_CONTACT_NUMBER>" + "<CHANNEL>"
						+ jsonObj.get("Channel").toString() + "</CHANNEL>" + "<AGENT_JOINING_DATE>"
						+ jsonObj.get("AgentJoiningDate").toString() + "</AGENT_JOINING_DATE>" + "<AGENT_STATUS>"
						+ jsonObj.get("AgentStatus").toString() + "</AGENT_STATUS>" + "<CURR_AML_START_DATE>"
						+ jsonObj.get("CurrentAMLStartDate").toString() + "</CURR_AML_START_DATE>"
						+ "<CURR_AML_END_DATE>" + jsonObj.get("CurrentAMLEndDate").toString() + "</CURR_AML_END_DATE>"
						+ "<PREV_AML_START_DATE>" + jsonObj.get("PreviousAMLStartDate").toString()
						+ "</PREV_AML_START_DATE>" + "<PREV_AML_END_DATE>"
						+ jsonObj.get("PreviousAMLEndDate").toString() + "</PREV_AML_END_DATE>"
						+ "<CURR_ULIP_START_DATE>" + jsonObj.get("CurrentULIPStartDate").toString()
						+ "</CURR_ULIP_START_DATE>" + "<CURR_ULIP_END_DATE>"
						+ jsonObj.get("CurrentULIPEndDate").toString() + "</CURR_ULIP_END_DATE>"
						+ "<PREV_ULIP_START_DATE>" + jsonObj.get("PreviousULIPStartDate").toString()
						+ "</PREV_ULIP_START_DATE>" + "<PREV_ULIP_END_DATE>"
						+ jsonObj.get("PreviousULIPEndDate").toString() + "</PREV_ULIP_END_DATE>" + "<AGENT_EMAIL>"
						+ jsonObj.get("AgentEmailID").toString() + "</AGENT_EMAIL>" + "<BRANCH_NAME>"
						+ jsonObj.get("BranchName").toString() + "</BRANCH_NAME>" + "<REPORTING_MANAGER_CODE>"
						+ jsonObj.get("ReportingManagerCode").toString() + "</REPORTING_MANAGER_CODE>"
						+ "<REPORTING_MANAGER_NAME>" + jsonObj.get("ReportingManagerName").toString()
						+ "</REPORTING_MANAGER_NAME>"+ "<AGENT_LEVEL>" + jsonObj.getOrDefault("AgentLevel","").toString()
						+ "</AGENT_LEVEL>" + "<AGENT_SEGMENT>" + jsonObj.getOrDefault("AgentSegment","").toString()
						+ "</AGENT_SEGMENT>" + "</Q_LIST_AGENT_DETAILS_GRID>";
			}

			attributesXML = attributesXML + "<Q_AGENT_DETAILS>" + "<AGENT_SIGN_DATE>"
					+ AgentDetailsObj.get("AgentSignDate").toString() + "</AGENT_SIGN_DATE>" + "<SP_CERTIFICATE_NO>"
					+ AgentDetailsObj.get("SPCertificationNumber").toString() + "</SP_CERTIFICATE_NO>" + "<SOL_ID>"
					+ AgentDetailsObj.get("SOL_Id").toString() + "</SOL_ID>" + "<SSN_CODE>"
					+ AgentDetailsObj.get("SSNCode").toString() + "</SSN_CODE>" + "<APPLICATION_ID>"
					+ AgentDetailsObj.get("ApplicationId").toString() + "</APPLICATION_ID>" + "<WMS_SERIAL_NO>"
					+ AgentDetailsObj.get("WMSSerialNumber").toString() + "</WMS_SERIAL_NO>" 
					+ "<LOGIN_PRIOR_3PM>"
					+ AgentDetailsObj.get("LoginPrior").toString() + "</LOGIN_PRIOR_3PM>" 
					+ "<ACReport>"
					+ AgentDetailsObj.getOrDefault("ACRQuestion","").toString() + "</ACReport>" + "<RA_ID>"  
					+ AgentDetailsObj.getOrDefault("raId","").toString() + "</RA_ID>"+  "<RA_NAME>"  
					+ AgentDetailsObj.getOrDefault("raName","").toString() + "</RA_NAME>"+ "<RA_EMAILID>"  
					+ AgentDetailsObj.getOrDefault("raEmailId","").toString() + "</RA_EMAILID>"+ "<RA_MOBILE>"
					+ AgentDetailsObj.getOrDefault("raMobile","").toString() + "</RA_MOBILE>"+// above 4 fields added by ujjawal DR-48325 
					"<MAPPED_AGENT_ID>" + AgentDetailsObj.getOrDefault("mappedAgentId","").toString() + "</MAPPED_AGENT_ID>"+  //added by ABHI DR-48460
					"<MAPPED_AGENT_VERIFIED>" + AgentDetailsObj.getOrDefault("isMappedAgentVerified","").toString() + "</MAPPED_AGENT_VERIFIED>"+   //added by ABHI DR-48460
					"<sellerSegment>" + AgentDetailsObj.getOrDefault("sellerSegment","").toString() + "</sellerSegment>"+   // DR-49145 Farman
					"</Q_AGENT_DETAILS>";             

			// logger.info(Agent_Code + GO_code + Agent_Name
			// +Agent_Contact_Number + Branch_Name + Agent_Status);
			String INFLUENCER_CHANNEL = "", EQUOTE_NUMBER = "", CRMLeadID = "";
			// PolicyDetails Section
			JSONObject PolicyDetailsObj = (JSONObject) jsonParser
					.parse(PolicyAgentCustomerObj.get("PolicyDetails").toString());
			Product_Name = (String) PolicyDetailsObj.get("ProductName");
			String Product_Name_Combo=(String) PolicyDetailsObj.get("ProductNameCombo");
			// String ProductFamily = (String)
			// PolicyDetailsObj.get("ProductFamily");
			Need = (String) PolicyDetailsObj.get("Need");
			Life_Stage = (String) PolicyDetailsObj.get("LifeStage");
			Objective_of_insurance = (String) PolicyDetailsObj.get("Objectiveofinsurance");
			Proposal_No = (String) PolicyDetailsObj.get("ProposalNo");
			CRMLeadID = (String) PolicyDetailsObj.get("CRMLeadID");
			INFLUENCER_CHANNEL = (String) PolicyDetailsObj.get("InfluencerChannel");
			EQUOTE_NUMBER = (String) PolicyDetailsObj.get("EquoteNumber");
			mPRO_initiation_date = (String) PolicyDetailsObj.get("mPROinitiationdate");
			App_Recvd_date_from_mPRO = (String) PolicyDetailsObj.get("AppRecvddatefrommPRO");
			Rural_urban_Social = (String) PolicyDetailsObj.get("RuralurbanSocial");
			Product_Solution = (String) PolicyDetailsObj.get("ProductSolution");
			Combo_Proposal_Number = (String) PolicyDetailsObj.get("ComboProposalNumber");
			Previous_Proposal_Number = (String) PolicyDetailsObj.get("PreviousProposalNumber");
			Source_of_Sale = (String) PolicyDetailsObj.get("SourceofSale");
			SPARC_lead_Source = (String) PolicyDetailsObj.get("SPARCleadSource");
			QROPS = (String) PolicyDetailsObj.get("QROPS");
			String familyIncomeOption = (String) PolicyDetailsObj.get("familyIncomeOption");
			String PurposeOfInsurance = (String) PolicyDetailsObj.get("PurposeOfInsurance");

			attributesXML = attributesXML + "<Q_POLICY_DETAILS>"
			// + "<Product_Name>" + Product_Name + "</Product_Name>"
					+ "<Need>" + Need + "</Need>" + "<Life_Stage>" + Life_Stage + "</Life_Stage>"
					// + "<OBJ_OF_INSURANCE>" + Objective_of_insurance +
					// "</OBJ_OF_INSURANCE>"
					// + "<Proposal_No>" + Proposal_No + "</Proposal_No>"
					+ "<CRM_LEAD_ID>" + CRMLeadID + "</CRM_LEAD_ID>" + "<INFLUENCER_CHANNEL>" + INFLUENCER_CHANNEL
					+ "</INFLUENCER_CHANNEL>" + "<INITIATION_DATE>" + mPRO_initiation_date + "</INITIATION_DATE>"
					+ "<EQUOTE_NUMBER>" + EQUOTE_NUMBER + "</EQUOTE_NUMBER>" + "<APP_RECEIVE_DATE>"
					+ App_Recvd_date_from_mPRO + "</APP_RECEIVE_DATE>" + "<Rural_urban_Social>" + Rural_urban_Social
					+ "</Rural_urban_Social>" + "<Product_Solution>" + Product_Solution + "</Product_Solution>"
					+ "<COMBO_PROPOSAL_NO>" + Combo_Proposal_Number + "</COMBO_PROPOSAL_NO>" + "<PREV_PROPOSAL_NO>"
					+ Previous_Proposal_Number + "</PREV_PROPOSAL_NO>" + "<SRC_OF_SALE>" + Source_of_Sale
					+ "</SRC_OF_SALE>" + "<SPARC_LEAD_SRC>" + SPARC_lead_Source + "</SPARC_LEAD_SRC>" + "<QROPS>"
					+ QROPS + "</QROPS>" + "<PURPOSE_OF_INSUR>" + PurposeOfInsurance + "</PURPOSE_OF_INSUR>"
					+"<FAMILY_INCOME_OPTION>" + familyIncomeOption + "</FAMILY_INCOME_OPTION>"
					+ "</Q_POLICY_DETAILS>";
			attributesXML = attributesXML + "<PLAN_NAME>" + Product_Name + "</PLAN_NAME>";
			attributesXML = attributesXML + "<PLAN_NAME_COMBO>" + Product_Name_Combo + "</PLAN_NAME_COMBO>";
			//attributesXML = attributesXML + "<COMBO_PROPOSAL_NUMBER>" + Combo_Proposal_Number + "</COMBO_PROPOSAL_NUMBER>";
			attributesXML = attributesXML + "<PRODUCT_SOLUTION>" + Product_Solution + "</PRODUCT_SOLUTION>";
			
			// attributesXML = attributesXML+ "<PLAN_TYPE>" + ProductFamily +
			// "</PLAN_TYPE>";
			attributesXML = attributesXML + "<OBJ_OF_INSURANCE>" + Objective_of_insurance + "</OBJ_OF_INSURANCE>";

			// attributesXML = attributesXML+ "<PROPOSAL_NUMBER>" + Proposal_No
			// + "</PROPOSAL_NUMBER>";
			// logger.info(Product_Name + Need + Life_Stage);

			// CEIP DETAILS
			JSONObject CEIPDetailsObj = (JSONObject) jsonParser
					.parse(PolicyAgentCustomerObj.getOrDefault("CEIPDetails", "{}").toString());

			Business_Type = (String) CEIPDetailsObj.get("BusinessType");
			BDM_id = (String) CEIPDetailsObj.get("BDMid");
			Enroller_id = (String) CEIPDetailsObj.get("Enrollerid");
			Finder_id = (String) CEIPDetailsObj.get("Finderid");
			Name_of_company = (String) CEIPDetailsObj.get("Nameofcompany");
			attributesXML = attributesXML
					// Q_CEIP_DETAILS_BUSINESS_TYPE
					+ "<Q_CEIP_DETAILS>" + "<Business_Type>" + Business_Type + "</Business_Type>" + "<BDM_id>" + BDM_id
					+ "</BDM_id>" + "<Enroller_id>" + Enroller_id + "</Enroller_id>" + "<Finder_id>" + Finder_id
					+ "</Finder_id>" + "<Name_of_company>" + Name_of_company + "</Name_of_company>"
					+ "</Q_CEIP_DETAILS>";

			// Defence Details
			JSONObject DefenceDetailsObj = (JSONObject) jsonParser
					.parse(PolicyAgentCustomerObj.getOrDefault("DefenceDetails", "{}").toString());
			Defence_Channel_Case = (String) DefenceDetailsObj.get("DefenceChannelCase");
			Army_Number = (String) DefenceDetailsObj.get("ArmyNumber");
			Unit_Name = (String) DefenceDetailsObj.get("UnitName");
			attributesXML = attributesXML
					// Q_DEFENCE_DETAILS_DEFENCE_CHANNEL_CASE
					+ "<Q_DEFENCE_DETAILS>" + "<Defence_Channel_Case>" + Defence_Channel_Case
					+ "</Defence_Channel_Case>" + "<Army_Number>" + Army_Number + "</Army_Number>" + "<Unit_Name>"
					+ Unit_Name + "</Unit_Name>" + "</Q_DEFENCE_DETAILS>";

			// Customer information
			String IRPScore = "";
			JSONObject CustomerInformationObj = (JSONObject) jsonParser
					.parse(PolicyAgentCustomerObj.getOrDefault("CustomerInformation", "{}").toString());
			Customer_Sign_Date = (String) CustomerInformationObj.get("CustomerSignDate");
			Customer_ID = (String) CustomerInformationObj.get("CustomerID");
			Customer_classification = (String) CustomerInformationObj.get("CustomerClassification");
			YBL_Customer_Classification = (String) CustomerInformationObj.get("YBLCustomerClassification");
			Is_this_a_replacement_policy_sale = (String) CustomerInformationObj.get("ReplacementPolicySale");
			IRPScore = (String) CustomerInformationObj.get("IRPScore");
			String ISTHANOS=(String) CustomerInformationObj.getOrDefault("IsThanosCase","");
			String THANOSJOURNEYTYPE=(String) CustomerInformationObj.getOrDefault("ThanosJourneyType","");
			String YBLTELESALES=(String) CustomerInformationObj.getOrDefault("IsYBLTeleSales","");

			attributesXML = attributesXML
					// Q_CUSTOMER_INFORMATION_IRP_SCORE
					+ "<Q_CUSTOMER_INFORMATION>" + "<IRP_SCORE>" + IRPScore + "</IRP_SCORE>" + "<Customer_Sign_Date>"
					+ Customer_Sign_Date + "</Customer_Sign_Date>" + "<Customer_ID>" + Customer_ID + "</Customer_ID>"
					+ "<AXIS_CUST_CLASS>" + Customer_classification + "</AXIS_CUST_CLASS>" + "<YBL_CUST_CLASS>"
					+ YBL_Customer_Classification + "</YBL_CUST_CLASS>" 
					+ "<REPLACEMENT_POLICY_SALE>"
					+ Is_this_a_replacement_policy_sale + "</REPLACEMENT_POLICY_SALE>"
					+ "<ISTHANOSCASE>"
					+ ISTHANOS + "</ISTHANOSCASE>"
					+ "<THANOS_TYPE>"
					+ THANOSJOURNEYTYPE + "</THANOS_TYPE>"
					+ "<ISYBLTELESALE>"
					+ YBLTELESALES + "</ISYBLTELESALE>"
					+ "</Q_CUSTOMER_INFORMATION>";

			attributesXML = attributesXML + "<REPLACEMENT_POLICY_SALE>" + Is_this_a_replacement_policy_sale
					+ "</REPLACEMENT_POLICY_SALE>";
			// Agent Information
			/*
			 * JSONObject AgentInformationObj = (JSONObject)
			 * jsonParser.parse(PolicyAgentCustomerObj.getOrDefault(
			 * "AgentInformation","{}").toString());
			 * 
			 * Agent_Sign_Date = (String)
			 * AgentInformationObj.get("AgentSignDate"); Agent_Code2 = (String)
			 * AgentInformationObj.get("AgentCode"); Agent_Name2 = (String)
			 * AgentInformationObj.get("AgentName"); Commission_Share = (String)
			 * AgentInformationObj.get("CommissionShare"); SP_CERTIFICATE_NO =
			 * (String) AgentInformationObj.get("SP_CERTIFICATE_NO"); SOL_ID =
			 * (String) AgentInformationObj.get("SOL_ID"); SSN_code = (String)
			 * AgentInformationObj.get("SSN_code"); Application_ID = (String)
			 * AgentInformationObj.get("Application_ID"); WMS_Sr_No = (String)
			 * AgentInformationObj.get("WMSSrNo"); Application_Received_Prior =
			 * (String) AgentInformationObj.get("LoginPrior"); attributesXML =
			 * attributesXML //id="Q_AGENT_INFORMATION_AGENT_SIGN_DATE" +
			 * "<Q_AGENT_INFORMATION>" + "<Agent_Sign_Date>" + Agent_Sign_Date +
			 * "</Agent_Sign_Date>" + "<AGENT_CODE>" + Agent_Code2 +
			 * "</AGENT_CODE>" + "<AGENT_NAME>" + Agent_Name2 + "</AGENT_NAME>"
			 * + "<Commission_Share>" + Commission_Share + "</Commission_Share>"
			 * + "<SP_CERTI_NO>" + SP_CERTIFICATE_NO + "</SP_CERTI_NO>" +
			 * "<SOL_ID>" + SOL_ID + "</SOL_ID>" + "<SSN_code>" + SSN_code +
			 * "</SSN_code>" + "<Application_ID>" + Application_ID +
			 * "</Application_ID>" + "<WMS_SERIAL_NO>" + WMS_Sr_No +
			 * "</WMS_SERIAL_NO>" + "<LOGIN_31_MARCH>" +
			 * Application_Received_Prior + "</LOGIN_31_MARCH>" +
			 * "</Q_AGENT_INFORMATION>" ;
			 */
			// WelcomeCall
			JSONObject WelcomeCallObj = (JSONObject) jsonParser
					.parse(PolicyAgentCustomerObj.getOrDefault("WelcomeCall", "{}").toString());
			String POSVResponse = "";
			// WelcomeCallReplacement,WelcomeCallPolSplit,WelcomeCallPSM,DispositionForNegative,WelcomeCallNotes;
			POSVResponse = (String) WelcomeCallObj.getOrDefault("POSVResponse", "");
			// String WelcomeCallReplacement = (String)
			// WelcomeCallObj.get("WelcomeCallReplacement");
			String WelcomeCallPolSplit = (String) WelcomeCallObj.getOrDefault("WelcomeCallPolSplit", "");
			String WelcomeCallPSM = (String) WelcomeCallObj.getOrDefault("WelcomeCallPSM", "");
			
			String WelcomeCallSeniorCitizen = (String) WelcomeCallObj.getOrDefault("WelcomeCallForSeniorCitizen", "");
			// DispositionForNegative = (String)
			// WelcomeCallObj.get("DispositionForNegative");
			// WelcomeCallNotes = (String)
			// WelcomeCallObj.get("WelcomeCallNotes");

			attributesXML = attributesXML + "<POLSPLITFLAG>" + WelcomeCallPolSplit + "</POLSPLITFLAG>";
			attributesXML = attributesXML + "<PSMRESFLAG>" + WelcomeCallPSM + "</PSMRESFLAG>";

			attributesXML = attributesXML + "<Q_WELCOME_CALL>" + "<POSV_RESPONSE>" + POSVResponse + "</POSV_RESPONSE>"
			// +
			// "<WC_REPLACEMENT_SALE>"+WelcomeCallPolSplit+"</WC_REPLACEMENT_SALE>"
			// +
			// "<WC_POLICY_SPLITTING>"+WelcomeCallPolSplit+"</WC_POLICY_SPLITTING>"
			// +
			// "<DISPOSITION_FOR_NEGATIVE>"+DispositionForNegative+"</DISPOSITION_FOR_NEGATIVE>"
			 + "<WC_PSM>"+WelcomeCallPSM+"</WC_PSM>"
			  + "<SENIOR_CITIZEN>"+WelcomeCallSeniorCitizen+"</SENIOR_CITIZEN>"
					+ "</Q_WELCOME_CALL>";
			attributesXML = attributesXML + "<POSV_RESPONSE>" + POSVResponse + "</POSV_RESPONSE>";
			attributesXML = attributesXML + "<SENIOR_CITIZEN>" + WelcomeCallSeniorCitizen + "</SENIOR_CITIZEN>";
			/*
			 * //Customer JSONObject CustomerObj = (JSONObject)
			 * jsonParser.parse(PolicyAgentCustomerObj.getOrDefault("Customer",
			 * "{}").toString());
			 * 
			 * INVESTOR_RISK_PROFILE_SCORE = (String)
			 * CustomerObj.get("INVESTOR_RISK_PROFILE_SCORE"); attributesXML =
			 * attributesXML + "<Q_CUSTOMER>" +
			 * "<RISK_PROFILE_SCORE>"+INVESTOR_RISK_PROFILE_SCORE+
			 * "</RISK_PROFILE_SCORE>" + "</Q_CUSTOMER>" ;
			 */
			// PersonalInformation tab
			JSONObject PersonalInformationObj = (JSONObject) jsonParser
					.parse(json.getOrDefault("PersonalInformation", "{}").toString());
			// ProposerDetails Section

			JSONObject ProposerDetails = (JSONObject) jsonParser
					.parse(PersonalInformationObj.getOrDefault("ProposerDetails", "{}").toString());

			// +
			// "<PROPOSER_CLIENT_ID>"+OtherTagsObj.get("ProposerClientId").toString()+"</PROPOSER_CLIENT_ID>"

			attributesXML = attributesXML + "<PROPOSER_CLIENT_ID>" + ProposerDetails.get("ProposerClientId").toString()
					+ "</PROPOSER_CLIENT_ID>" + "<PROPOSER_AGE>" + (String) ProposerDetails.get("ProposerAge")
					+ "</PROPOSER_AGE>";

			attributesXML = attributesXML + "<Q_PROPOSER_DETAILS>\r\n" + "<CLIENT_TYPE>"
					+ (String) ProposerDetails.get("ClientType") + "</CLIENT_TYPE>\r\n" + "<POLICY_PACK_REQUIRED>"
					+ (String) ProposerDetails.get("PolicyPackRequired") + "</POLICY_PACK_REQUIRED>\r\n" + "<TITLE>"
					+ (String) ProposerDetails.get("Title") + "</TITLE>\r\n" + "<SPECIFY_TITLE>"
					+ (String) ProposerDetails.get("PleaseSpecify") + "</SPECIFY_TITLE>\r\n" + "<FIRST_NAME>"
					+ (String) ProposerDetails.get("FirstName") + "</FIRST_NAME>\r\n" + "<MIDDLE_NAME>"
					+ (String) ProposerDetails.get("MiddleName") + "</MIDDLE_NAME>\r\n" + "<LAST_NAME>"
					+ (String) ProposerDetails.get("LastName") + "</LAST_NAME>\r\n" + "<FATHER_HUSBAND_NAME>"
					+ (String) ProposerDetails.get("FatherHusbandName") + "</FATHER_HUSBAND_NAME>\r\n" +
					// "<FATHER_NAME>"+(String)
					// ProposerDetails.get("FathersName")+"</FATHER_NAME>\r\n" +
					// "<HUSBAND_NAME>"+(String)
					// ProposerDetails.get("HusbandsName")+"</HUSBAND_NAME>\r\n"
					// +
					"<MOTHER_NAME>" + (String) ProposerDetails.get("MothersName") + "</MOTHER_NAME>\r\n"
					+ "<DATE_OF_INCOR>" + (String) ProposerDetails.get("DateofIncorporation") + "</DATE_OF_INCOR>\r\n"
					+ "<DATE_OF_BIRTH>" + (String) ProposerDetails.get("DateofBirth") + "</DATE_OF_BIRTH>\r\n"
					+ "<GENDER>" + (String) ProposerDetails.get("Gender") + "</GENDER>\r\n" + "<NATIONALITY>"
					+ (String) ProposerDetails.get("Nationality") + "</NATIONALITY>\r\n" + "<PAN_NUMBER>"
					+ (String) ProposerDetails.get("PanNumber") + "</PAN_NUMBER>\r\n" + "<RESIDENTIAL_STATUS>"
					+ (String) ProposerDetails.get("ResidentialStatus") + "</RESIDENTIAL_STATUS>\r\n" +
					// "<SPECIFY_STATUS>"+(String)
					// ProposerDetails.get("PleaseSpecifyRS")+"</SPECIFY_STATUS>\r\n"
					// +
					"<BUSINESS_SOURCE>" + (String) ProposerDetails.get("BusinessSource") + "</BUSINESS_SOURCE>\r\n"
					+ "<TYPE_OF_VISA>" + (String) ProposerDetails.get("TypeOfVisa") + "</TYPE_OF_VISA>\r\n"
					+ "<VISA_VALID_TILL>" + (String) ProposerDetails.get("ValidTill") + "</VISA_VALID_TILL>\r\n"
					+ "<PASSPORT_EXP_DATE>" + (String) ProposerDetails.get("PassportExpiryDate")
					+ "</PASSPORT_EXP_DATE>\r\n" + "<DATE_OF_LATEST_ENTRY_TO_INDIA>"
					+ (String) ProposerDetails.get("LatestEntryDate") + "</DATE_OF_LATEST_ENTRY_TO_INDIA>\r\n"
					+ "<TYPE_FOREIGN_ID>" + (String) ProposerDetails.get("TypeOfForeignIdentification")
					+ "</TYPE_FOREIGN_ID>\r\n" + "<ANNUITY_OPTION>" + (String) ProposerDetails.get("AnnuityOption")
					+ "</ANNUITY_OPTION>\r\n" + "<ISSUE_ADD_PROOF>"
					+ (String) ProposerDetails.get("DateofIssueAddressProof") + "</ISSUE_ADD_PROOF>\r\n"
					+ "<EXPIRY_OF_ADD_PROOF>" + (String) ProposerDetails.get("DateofExpiryofAddressProof")
					+ "</EXPIRY_OF_ADD_PROOF>\r\n" + "<POLITICALLY_EXPOSED>"
					+ (String) ProposerDetails.get("IsPoliticallyExposed") + "</POLITICALLY_EXPOSED>\r\n" + "<COUNTRY>"
					+ (String) ProposerDetails.get("Country") + "</COUNTRY>\r\n" + "<PIN_CODE>"
					+ (String) ProposerDetails.get("PinCode") + "</PIN_CODE>\r\n" + "<HOUSE_NO_APT_NAME>"
					+ (String) ProposerDetails.get("HouseNoAptNameSociety") + "</HOUSE_NO_APT_NAME>\r\n"
					+ "<ROAD_AREA_SECTOR>" + (String) ProposerDetails.get("RoadAreaSector") + "</ROAD_AREA_SECTOR>\r\n"
					+ "<LANDMARK>" + (String) ProposerDetails.get("Landmark") + "</LANDMARK>\r\n" + "<VILLAGE_TOWN>"
					+ (String) ProposerDetails.get("VillageTown") + "</VILLAGE_TOWN>\r\n" + "<CITY_DISTRICT>"
					+ (String) ProposerDetails.get("CityDistrict") + "</CITY_DISTRICT>\r\n" + "<STATE_UT>"
					+ (String) ProposerDetails.get("StateUT") + "</STATE_UT>\r\n" + "<MOBILE_NO_1>"
					+ (String) ProposerDetails.get("MobileNo1") + "</MOBILE_NO_1>\r\n" + "<MOBILE_NO_2>"
					+ (String) ProposerDetails.get("MobileNo2") + "</MOBILE_NO_2>\r\n" + "<LANDLINE_NO>"
					+ (String) ProposerDetails.get("LandlineNo1") + "</LANDLINE_NO>\r\n" + "<STD>"
					+ (String) ProposerDetails.get("STD_forLandlineNo1") + "</STD>\r\n" + "<PERM_RESIDENTIAL_ADD>"
					+ (String) ProposerDetails.get("SameAsAbove") + "</PERM_RESIDENTIAL_ADD>\r\n" + "<EMAIL_ID>"
					+ (String) ProposerDetails.get("EmailId") + "</EMAIL_ID>\r\n" + "<ADDR_PROOF_PROP>"
					+ (String) ProposerDetails.get("AddressProofofProposer") + "</ADDR_PROOF_PROP>\r\n"
					+ "<Registration_Certificate_Number>" +(String) ProposerDetails.getOrDefault("RegistrationCertificateNumber","") + "</Registration_Certificate_Number>\r\n"	//DR-15823 mansi
					+ "<ID_PROOF_PROP>" + (String) ProposerDetails.get("IDproofofProposer") + "</ID_PROOF_PROP>\r\n"
					+ "<PROOF_NUMBER>" + (String) ProposerDetails.get("ProofNumber") + "</PROOF_NUMBER>\r\n"
					+ "<EXPIRY_ID_PROOF>" + (String) ProposerDetails.get("DateOfExpiryofIdentityProof")
					+ "</EXPIRY_ID_PROOF>\r\n" + "<EIA_NO_AVAILABLE>"
					+ (String) ProposerDetails.get("13DigitEIANumberAvailable") + "</EIA_NO_AVAILABLE>\r\n"
					+ "<EIA_NUMBER>" + (String) ProposerDetails.get("EIANumber") + "</EIA_NUMBER>\r\n" +

					"<MARITAL_STATUS>" + (String) ProposerDetails.get("MaritalStatus") + "</MARITAL_STATUS>\r\n"
					+ "<EDUCATION>" + (String) ProposerDetails.get("Education") + "</EDUCATION>\r\n" + "<EXACT_INCOME>"
					+ (String) ProposerDetails.get("ExactIncome") + "</EXACT_INCOME>\r\n" + "<OCCUPATION>"
					+ (String) ProposerDetails.get("Occupation") + "</OCCUPATION>\r\n" + "<INDUSTRY_TYPE>"
					+ (String) ProposerDetails.get("IndustryType") + "</INDUSTRY_TYPE>\r\n" + "<NATURE_OF_DUTIES>"
					+ (String) ProposerDetails.get("ExactNature") + "</NATURE_OF_DUTIES>\r\n" + "<FLYING_ROLE>"
					+ (String) ProposerDetails.get("FlyWhat") + "</FLYING_ROLE>\r\n" + "<CURRENTLY_POSTED>"
					+ (String) ProposerDetails.get("IsSensitiveLocation") + "</CURRENTLY_POSTED>\r\n"
					+ "<NATURE_OF_JOB>" + (String) ProposerDetails.get("NatureOfJob") + "</NATURE_OF_JOB>\r\n"
					+ "<PROFESSIONAL_DIVER>" + (String) ProposerDetails.get("ProfessionalDiver")
					+ "</PROFESSIONAL_DIVER>\r\n" + "<DIVE>" + (String) ProposerDetails.get("DiveLocation")
					+ "</DIVE>\r\n" + "<TYPE_OF_VESSEL>" + (String) ProposerDetails.get("TypeOfVessel")
					+ "</TYPE_OF_VESSEL>\r\n" + "<ROLE_INVOLVE>" + (String) ProposerDetails.get("MineRole")
					+ "</ROLE_INVOLVE>\r\n" + "<ILLNESS_OCCUPATION>" + (String) ProposerDetails.get("AnyIllness")
					+ "</ILLNESS_OCCUPATION>\r\n" + "<PREF_MAIL_ADDRESS>"
					+ (String) ProposerDetails.get("PreferredMailingAddress") + "</PREF_MAIL_ADDRESS>\r\n"
					+ "<OFFSHORE>" + (String) ProposerDetails.get("IsTravelling") + "</OFFSHORE>\r\n" +

					"<FTIN_Present>" + (String) ProposerDetails.get("HaveFTIN") + "</FTIN_Present>\r\n" + "<REPOSITORY>"
					+ (String) ProposerDetails.get("RepositorytoOpenAccount") + "</REPOSITORY>\r\n" + "<AADHAAR_NUMBER>"
					+ (String) ProposerDetails.get("AadhaarNumber") + "</AADHAAR_NUMBER>\r\n" + "<AADHAAR_ENROL_NO>"
					+ (String) ProposerDetails.get("AadhaarEnrollmentNumber") + "</AADHAAR_ENROL_NO>\r\n"
					+ "<COMPANY_TYPE>" + (String) ProposerDetails.get("CompanyType") + "</COMPANY_TYPE>\r\n"
					+ "<PREFERRED_LANGUAGE>" + (String) ProposerDetails.get("PreferredLanguage")
					+ "</PREFERRED_LANGUAGE>\r\n" + "<ORGANIZATION_TYPE>"
					+ (String) ProposerDetails.get("OrganizationType") + "</ORGANIZATION_TYPE>\r\n"
					+ "<PAN_APPLIED_FOR>" + (String) ProposerDetails.get("Appliedfor") + "</PAN_APPLIED_FOR>\r\n" +
					// added
					"<DATE_OF_APPLICATION>" + (String) ProposerDetails.get("DateOfApplication")
					+ "</DATE_OF_APPLICATION>\r\n" + "<PAN_ACK_NO>" + (String) ProposerDetails.get("PanAckNumber")
					+ "</PAN_ACK_NO>\r\n" + "<DOB_PROOF>" + (String) ProposerDetails.get("DOBProofOfProposer")
					+ "</DOB_PROOF>\r\n" +
					// --
					"<PERM_COUNTRY>" + (String) ProposerDetails.get("PermCountry") + "</PERM_COUNTRY>\r\n"
					+ "<PERM_PIN_CODE>" + (String) ProposerDetails.get("PermPinCode") + "</PERM_PIN_CODE>\r\n"
					+ "<PERM_HOUSE_NO_APT_NAME>" + (String) ProposerDetails.get("PermHouseNoAptNameSociety")
					+ "</PERM_HOUSE_NO_APT_NAME>\r\n" + "<PERM_ROAD_AREA_SECTOR>"
					+ (String) ProposerDetails.get("PermRoadAreaSector") + "</PERM_ROAD_AREA_SECTOR>\r\n"
					+ "<PERM_LANDMARK>" + (String) ProposerDetails.get("PermLandmark") + "</PERM_LANDMARK>\r\n"
					+ "<PERM_VILLAGE_TOWN>" + (String) ProposerDetails.get("PermVillageTown")
					+ "</PERM_VILLAGE_TOWN>\r\n" + "<PERM_CITY_DISTRICT>"
					+ (String) ProposerDetails.get("PermCityDistrict") + "</PERM_CITY_DISTRICT>\r\n" + "<PERM_STATE_UT>"
					+ (String) ProposerDetails.get("PermStateUT") + "</PERM_STATE_UT>\r\n" + "<PERM_MOBILE_NO_1>"
					+ (String) ProposerDetails.get("PermMobileNo1") + "</PERM_MOBILE_NO_1>\r\n" + "<PERM_MOBILE_NO_2>"
					+ (String) ProposerDetails.get("PermMobileNo2") + "</PERM_MOBILE_NO_2>\r\n" + "<PERM_LANDLINE_NO>"
					+ (String) ProposerDetails.get("PermLandlineNo1") + "</PERM_LANDLINE_NO>\r\n" + "<PERM_STD>"
					+ (String) ProposerDetails.get("PermSTD_forLandlineNo1") + "</PERM_STD>\r\n" + "<DO_YOU_HAVE_CKYC>"
					+ (String) ProposerDetails.get("HaveCKYC") + "</DO_YOU_HAVE_CKYC>\r\n" + "<CKYC_NO>"
					+ (String) ProposerDetails.get("CKYCNo") + "</CKYC_NO>\r\n" + "<PERON_PEP>"
					+ (String) ProposerDetails.get("PEPPerson") + "</PERON_PEP>\r\n" + "<PEP_SPECIFY>"
					+ (String) ProposerDetails.getOrDefault("PEPSpecify", "") + "</PEP_SPECIFY>\r\n" + "<POLITICAL_EXP>"
					+ (String) ProposerDetails.get("PoliticalExperience") + "</POLITICAL_EXP>\r\n"
					+ "<AFFILIATION_POLITICAL_PARTY>" + (String) ProposerDetails.get("AffiliationToPoliticalParty")
					+ "</AFFILIATION_POLITICAL_PARTY>\r\n" + "<PORTFLIO_HANDLED>"
					+ (String) ProposerDetails.get("PortfolioHandled") + "</PORTFLIO_HANDLED>\r\n"
					+ "<ROLE_POLITICAL_PARTY>" + (String) ProposerDetails.get("RoleInPoliticalParty")
					+ "</ROLE_POLITICAL_PARTY>\r\n" + "<SPECIFY_POLITICAL_ROLE>"
					+ (String) ProposerDetails.get("SpecifyRole") + "</SPECIFY_POLITICAL_ROLE>\r\n" + "<PARTY_IN_POWER>"
					+ (String) ProposerDetails.get("IsPartyPower") + "</PARTY_IN_POWER>\r\n" + "<PEP_POSTED>"
					+ (String) ProposerDetails.get("ForeignPortfolio") + "</PEP_POSTED>\r\n" + "<PEP_SPECIFY_OFFICE>"
					+ (String) ProposerDetails.get("PEPOffice") + "</PEP_SPECIFY_OFFICE>\r\n" + "<PEP_INCOME_SOURCES>"
					+ (String) ProposerDetails.get("PEPIncome") + "</PEP_INCOME_SOURCES>\r\n" + "<PEP_CONVICTED>"
					+ (String) ProposerDetails.get("IsPEPconvicted") + "</PEP_CONVICTED>\r\n" + "<CONVICTION_DETAILS>"
					+ (String) ProposerDetails.get("ConvictionDetails") + "</CONVICTION_DETAILS>\r\n" + "<PASSPORT_NO>"
					+ (String) ProposerDetails.get("PassportNumber") + "</PASSPORT_NO>\r\n" +
					// "<PASSPORT_ISSUE_COUNTRY>"+(String)
					// ProposerDetails.get("PassportIssuingCountry")+"</PASSPORT_ISSUE_COUNTRY>\r\n"
					// +
					// "<COUNTRY_RESIDING_IN>"+(String)
					// ProposerDetails.get("CurrentCountry")+"</COUNTRY_RESIDING_IN>\r\n"
					// +
					// "<COUNTRIES_VISIT_FREQ>"+(String)
					// ProposerDetails.get("FrequentCountries")+"</COUNTRIES_VISIT_FREQ>\r\n"
					// +
					"<BIRTH_COUNTRY>" + (String) ProposerDetails.get("BirthCountry") + "</BIRTH_COUNTRY>\r\n"
					+ "<COUNTRY_OF_RESIDENCE>" + (String) ProposerDetails.get("CountryOfResidence")
					+ "</COUNTRY_OF_RESIDENCE>\r\n" + "<OPT_FOR_POLICY>" + (String) ProposerDetails.get("EInsurance")
					+ "</OPT_FOR_POLICY>\r\n" + "<ISSUING_COUNTRY>" + (String) ProposerDetails.get("IssuingCountry")
					+ "</ISSUING_COUNTRY>\r\n" + "<ID_NUMBER>" + (String) ProposerDetails.get("IdentificationNumber")
					+ "</ID_NUMBER>\r\n" + "<NEFT_BANK_ACC_NO>" + (String) ProposerDetails.get("NEFTBankAccNumber")
					+ "</NEFT_BANK_ACC_NO>\r\n" + "<REFERENCE_KEY>" + (String) ProposerDetails.get("ReferenceKey")
					+ "</REFERENCE_KEY>\r\n" +
					////// Added By Suraj
					"<DO_YOU_HAVE_PAN>" + (String) ProposerDetails.getOrDefault("PANCardStatus", "")
					+ "</DO_YOU_HAVE_PAN>\r\n" + "<FORM49_SUBMITTED>"
					+ (String) ProposerDetails.getOrDefault("PAN49Submission", "") + "</FORM49_SUBMITTED>\r\n"
					+ "<OCCUPATION_SPECIFY>" + (String) ProposerDetails.getOrDefault("PleaseSpecifyOccupation", "")
					+ "</OCCUPATION_SPECIFY>\r\n" 
					+ "<PAN_AADHAR>" + (String) ProposerDetails.getOrDefault("IsPANLinkedWithAadhar", "")
					+ "</PAN_AADHAR>\r\n" 
					+ "<EXACT_INCOME_COMPANY>" + (String) ProposerDetails.getOrDefault("ExactIncomeCompany", "")
					+ "</EXACT_INCOME_COMPANY>\r\n" 
					+ "<SOURCE_FUND>" + (String) ProposerDetails.getOrDefault("SourceFund", "")
					+ "</SOURCE_FUND>\r\n" 
					+ "<CERTI_INCORPORATION>" + (String) ProposerDetails.getOrDefault("CertificateOfIncorporation", "")
					+ "</CERTI_INCORPORATION>\r\n" 
					+ "<PAN_NUMBER_COMPANY>" + (String) ProposerDetails.getOrDefault("PANNumberCompany", "")
					+ "</PAN_NUMBER_COMPANY>\r\n" 
					+ "<REG_CERTI>" + (String) ProposerDetails.getOrDefault("RegistrationCertiNumber", "")
					+ "</REG_CERTI>\r\n" 
					+ "<NAME_COMPANY>" + (String) ProposerDetails.getOrDefault("CompanyName", "")
					+ "</NAME_COMPANY>\r\n" 
					+ "<COMP_RELATIONSHIP_PROP>" + (String) ProposerDetails.getOrDefault("CompanyRelationship", "")
					+ "</COMP_RELATIONSHIP_PROP>\r\n" 
					+ "<BNPL>" + (String) ProposerDetails.getOrDefault("BNPL", "")
					+ "</BNPL>\r\n" 
					+ "<NRI_EMODEL>" + (String) ProposerDetails.getOrDefault("NriEModel", "")
					+ "</NRI_EMODEL>\r\n" 
					+ "<IS_NPS>" + (String) ProposerDetails.getOrDefault("IsNPSJourney", "")
					+ "</IS_NPS>\r\n" 
					+ "<MPROLCIENTID>" + (String) ProposerDetails.getOrDefault("ProposerClientId", "")
					+ "</MPROLCIENTID>\r\n" 
					+ "<PRAN_NUMBER>" + (String) ProposerDetails.getOrDefault("PranNo", "")
					+ "</PRAN_NUMBER>\r\n" 
					+"<MproDedupe>" + (String) ProposerDetails.getOrDefault("MproDedupe", "") + "</MproDedupe>\r\n"   // dr-17412 mansi
					+"<SPECIFY_DUTIES_TYPE>" + (String) ProposerDetails.getOrDefault("SpecifyDutiesType", "") + "</SPECIFY_DUTIES_TYPE>\r\n"  // DR-21145 Sparsh
					+"<CITY_OF_BIRTH>" + (String) ProposerDetails.getOrDefault("City_Of_Birth", "") + "</CITY_OF_BIRTH>\r\n"  //DR- 31433 By Ritika
					+"<GO_GREEN>" + (String) ProposerDetails.getOrDefault("goGreen", "") + "</GO_GREEN>\r\n" //DR- 34058 By MANSI
					+"<AbhaID>" + (String) ProposerDetails.getOrDefault("AbhaID", "") + "</AbhaID>\r\n" //DR- 40109 By RITIKA
					+"<Countrycode1>" + (String) ProposerDetails.getOrDefault("Countrycode1", "") + "</Countrycode1>\r\n" //DR- 42593 By RITIKA
					+"<Countrycode2>" + (String) ProposerDetails.getOrDefault("Countrycode2", "") + "</Countrycode2>\r\n" //DR- 42593 By RITIKA
					+"<PermCountrycode1>" + (String) ProposerDetails.getOrDefault("PermCountrycode1", "") + "</PermCountrycode1>\r\n" //DR- 42593 By RITIKA
					+"<PermCountrycode2>" + (String) ProposerDetails.getOrDefault("PermCountrycode2", "") + "</PermCountrycode2>\r\n" //DR- 42593 By RITIKA
					+"<PASSPORT_ISSUE_DATE>" + (String) ProposerDetails.get("PassportIssueDate") + "</PASSPORT_ISSUE_DATE>\r\n"    //DR-46254 Ezaz
					+"<Foreign_UID_Issuing_Country>" + (String) ProposerDetails.getOrDefault("ForeignUIDIssCountry", "") + "</Foreign_UID_Issuing_Country>\r\n" //DR-46254 Ezaz
					+"<Document_Number>" + (String) ProposerDetails.getOrDefault("DocNum", "") + "</Document_Number>\r\n" //DR-46254 Ezaz
					+"<Foreign_UID_Type>" + (String) ProposerDetails.getOrDefault("ForeignUIDTyp", "") + "</Foreign_UID_Type>\r\n" //DR-46254 Ezaz
					+"<Foreign_UID_Number>" + (String) ProposerDetails.getOrDefault("ForeignUidNum", "") + "</Foreign_UID_Number>\r\n" //DR-46254 Ezaz
					+"<Other_Foreign_Tax_Proof>" + (String) ProposerDetails.getOrDefault("OtherForeignTaxProof", "") + "</Other_Foreign_Tax_Proof>\r\n" //DR-46254 Ezaz
					
					
					
					
					///////// Till Here//////////
					+"</Q_PROPOSER_DETAILS>";
			JSONArray Citizenship = (JSONArray) ProposerDetails.getOrDefault("Citizenship", new JSONArray());
			for (Object j : Citizenship) {
				attributesXML = attributesXML + "<Q_LIST_CITIZENSHIP_PROP>" + j.toString()
						+ "</Q_LIST_CITIZENSHIP_PROP>";
			}

			JSONArray FrequentCountries = (JSONArray) ProposerDetails.getOrDefault("FrequentCountries", "[]");
			for (Object j : FrequentCountries) {
				attributesXML = attributesXML + "<Q_LIST_COUNTRIES_FREQ_VISITED_PROP>" + j.toString()
						+ "</Q_LIST_COUNTRIES_FREQ_VISITED_PROP>";
			}

			JSONArray PassportIssuingCountryProp = (JSONArray) ProposerDetails.getOrDefault("PassportIssuingCountry",
					"[]");
			for (Object j : PassportIssuingCountryProp) {
				attributesXML = attributesXML + "<Q_LIST_PASSPORT_COUNTRIES_PROP>" + j.toString()
						+ "</Q_LIST_PASSPORT_COUNTRIES_PROP>";
			}

			JSONArray CurrentCountryyProp = (JSONArray) ProposerDetails.getOrDefault("CurrentCountry", "[]");
			for (Object j : CurrentCountryyProp) {
				attributesXML = attributesXML + "<Q_LIST_COUNTRY_OF_RESIDENCE_PROP>" + j.toString()
						+ "</Q_LIST_COUNTRY_OF_RESIDENCE_PROP>";
			}

			JSONArray FTINArray;
			FTINArray = (JSONArray) ProposerDetails.getOrDefault("FTNDetails", "[]");
			insertionOrderId = 0;
			hashID = 1;

			for (Object j : FTINArray) {
				JSONObject jsonObj = (JSONObject) j;
				attributesXML = attributesXML + "<Q_LIST_FTN_DETAILS>\r\n" + "<InsertionOrderId>" + insertionOrderId
						+ "</InsertionOrderId>" + "<HashId>" + hashID++ + "</HashId>" + "<FTIN_NUMBER>"
						+ jsonObj.get("FTIN_Number").toString() + "</FTIN_NUMBER>" + "<FTIN_ISSUING_COUNTRY>"
						+ jsonObj.get("FTIN_IssuingCountry").toString() + "</FTIN_ISSUING_COUNTRY>"
						+ "</Q_LIST_FTN_DETAILS>";
			}

			// L2BIDetails Section

			JSONObject L2BIDetailsObj = (JSONObject) jsonParser
					.parse(PersonalInformationObj.getOrDefault("L2BIDetails", "{}").toString());

			// +
			// "<INSURED_CLIENT_ID>"+OtherTagsObj.get("InsuredClientId").toString()+"</INSURED_CLIENT_ID>"
			attributesXML = attributesXML + "<INSURED_CLIENT_ID>" + L2BIDetailsObj.get("InsuredClientId").toString()
					+ "</INSURED_CLIENT_ID>" + "<INSURED_AGE>" + L2BIDetailsObj.get("InsuredAge").toString()
					+ "</INSURED_AGE>";

			attributesXML = attributesXML + "<Q_L2BI_DETAILS>\r\n" +
			// "<CLIENT_TYPE>"+(String)
			// L2BIDetailsObj.get("ClientType")+"</CLIENT_TYPE>\r\n" +
					"<TITLE>" + (String) L2BIDetailsObj.get("Title") + "</TITLE>\r\n" + "<SPECIFY_TITLE>"
					+ (String) L2BIDetailsObj.get("PleaseSpecify") + "</SPECIFY_TITLE>\r\n" + "<FIRST_NAME>"
					+ (String) L2BIDetailsObj.get("FirstName") + "</FIRST_NAME>\r\n" + "<MIDDLE_NAME>"
					+ (String) L2BIDetailsObj.get("MiddleName") + "</MIDDLE_NAME>\r\n" + "<LAST_NAME>"
					+ (String) L2BIDetailsObj.get("LastName") + "</LAST_NAME>\r\n" + "<FATHER_HUSBAND_NAME>"
					+ (String) L2BIDetailsObj.get("FatherHusbandName") + "</FATHER_HUSBAND_NAME>\r\n" +
					// "<FATHER_NAME>"+(String)
					// L2BIDetailsObj.get("FathersName")+"</FATHER_NAME>\r\n" +
					// "<HUSBAND_NAME>"+(String)
					// L2BIDetailsObj.get("HusbandsName")+"</HUSBAND_NAME>\r\n"
					// +
					"<DOB>" + (String) L2BIDetailsObj.get("DateOfBirth") + "</DOB>\r\n" + "<DOB_PROOF>"
					+ (String) L2BIDetailsObj.get("DOBProofOfInsured") + "</DOB_PROOF>\r\n" + "<GENDER>"
					+ (String) L2BIDetailsObj.get("Gender") + "</GENDER>\r\n" + "<NATIONALITY>"
					+ (String) L2BIDetailsObj.get("Nationality") + "</NATIONALITY>\r\n" + "<BUSINESS_SOURCE>"
					+ (String) L2BIDetailsObj.get("BusinessSource") + "</BUSINESS_SOURCE>\r\n" +
					// "<COUNTRIES_VISIT_FREQ>"+(String)
					// L2BIDetailsObj.get("FrequentlyVisitedCountries")+"</COUNTRIES_VISIT_FREQ>\r\n"
					// +
					"<PASSPORT_NO>" + (String) L2BIDetailsObj.get("PassportNumber") + "</PASSPORT_NO>\r\n"
					+ "<TYPE_OF_VISA>" + (String) L2BIDetailsObj.get("TypeOFVisa") + "</TYPE_OF_VISA>\r\n"
					+ "<VISA_VALID_TILL>" + (String) L2BIDetailsObj.get("VisaValidTill") + "</VISA_VALID_TILL>\r\n" +
					// "<PASSPORT_ISSUE_COUNTRY>"+(String)
					// L2BIDetailsObj.get("PassportIssuingCountry")+"</PASSPORT_ISSUE_COUNTRY>\r\n"
					// +
					"<PASSPORT_EXP_DATE>" + (String) L2BIDetailsObj.get("PassportExpiryDate")
					+ "</PASSPORT_EXP_DATE>\r\n" +
					// "<COUNTRY_RESIDING_IN>"+(String)
					// L2BIDetailsObj.get("CurrentCountry")+"</COUNTRY_RESIDING_IN>\r\n"
					// +
					"<DATE_OF_LATEST_ENTRY_TO_INDIA>" + (String) L2BIDetailsObj.get("DateOfLatestEntry")
					+ "</DATE_OF_LATEST_ENTRY_TO_INDIA>\r\n" + "<BIRTH_COUNTRY>"
					+ (String) L2BIDetailsObj.get("BirthCountry") + "</BIRTH_COUNTRY>\r\n" + "<COUNTRY_OF_RESIDENCE>"
					+ (String) L2BIDetailsObj.get("CountryOfResidence") + "</COUNTRY_OF_RESIDENCE>\r\n"
					+ "<FTIN_PRESENT>" + (String) L2BIDetailsObj.get("HaveFTIN") + "</FTIN_PRESENT>\r\n"
					+ "<TYPE_FOREIGN_ID>" + (String) L2BIDetailsObj.get("TypeOfForeignIdentification")
					+ "</TYPE_FOREIGN_ID>\r\n" + "<ID_NUMBER>" + (String) L2BIDetailsObj.get("IdentificationNumber")
					+ "</ID_NUMBER>\r\n" + "<ISSUING_COUNTRY>" + (String) L2BIDetailsObj.get("IssuingCountry")
					+ "</ISSUING_COUNTRY>\r\n" + "<CRA_SAME_PROPOSER>" + (String) L2BIDetailsObj.get("IsCRASame")
					+ "</CRA_SAME_PROPOSER>\r\n" + "<COUNTRY>" + (String) L2BIDetailsObj.get("Country")
					+ "</COUNTRY>\r\n" + "<PIN_CODE>" + (String) L2BIDetailsObj.get("PinCode") + "</PIN_CODE>\r\n"
					+ "<HOUSE_NO_APT_NAME>" + (String) L2BIDetailsObj.get("HouseNoAptNameSociety")
					+ "</HOUSE_NO_APT_NAME>\r\n" + "<ROAD_AREA_SECTOR>" + (String) L2BIDetailsObj.get("RoadAreaSector")
					+ "</ROAD_AREA_SECTOR>\r\n" + "<LANDMARK>" + (String) L2BIDetailsObj.get("Landmark")
					+ "</LANDMARK>\r\n" + "<VILLAGE_TOWN>" + (String) L2BIDetailsObj.get("VillageTown")
					+ "</VILLAGE_TOWN>\r\n" + "<CITY_DISTRICT>" + (String) L2BIDetailsObj.get("CityDistrict")
					+ "</CITY_DISTRICT>\r\n" + "<STATE_UT>" + (String) L2BIDetailsObj.get("StateUT") + "</STATE_UT>\r\n"
					+ "<MOBILE_NO_1>" + (String) L2BIDetailsObj.get("MobileNo1") + "</MOBILE_NO_1>\r\n"
					+ "<MOBILE_NO_2>" + (String) L2BIDetailsObj.get("MobileNo2") + "</MOBILE_NO_2>\r\n"
					+ "<LANDLINE_NO>" + (String) L2BIDetailsObj.get("LandlineNo1") + "</LANDLINE_NO>\r\n" + "<STD>"
					+ (String) L2BIDetailsObj.get("STD_forLandlineNo1") + "</STD>\r\n" + "<PERM_RESIDENTIAL_ADD>"
					+ (String) L2BIDetailsObj.get("SameAsAbove") + "</PERM_RESIDENTIAL_ADD>\r\n" + "<PERM_COUNTRY>"
					+ (String) L2BIDetailsObj.get("PermCountry") + "</PERM_COUNTRY>\r\n" + "<PERM_PIN_CODE>"
					+ (String) L2BIDetailsObj.get("PermPinCode") + "</PERM_PIN_CODE>\r\n" + "<PERM_HOUSE_NO_APT_NAME>"
					+ (String) L2BIDetailsObj.get("PermHouseNoAptNameSociety") + "</PERM_HOUSE_NO_APT_NAME>\r\n"
					+ "<PERM_ROAD_AREA_SECTOR>" + (String) L2BIDetailsObj.get("PermRoadAreaSector")
					+ "</PERM_ROAD_AREA_SECTOR>\r\n" + "<PERM_LANDMARK>" + (String) L2BIDetailsObj.get("PermLandmark")
					+ "</PERM_LANDMARK>\r\n" + "<PERM_VILLAGE_TOWN>" + (String) L2BIDetailsObj.get("PermVillageTown")
					+ "</PERM_VILLAGE_TOWN>\r\n" + "<PERM_CITY_DISTRICT>"
					+ (String) L2BIDetailsObj.get("PermCityDistrict") + "</PERM_CITY_DISTRICT>\r\n" + "<PERM_STATE_UT>"
					+ (String) L2BIDetailsObj.get("PermStateUT") + "</PERM_STATE_UT>\r\n" + "<PERM_MOBILE_NO_1>"
					+ (String) L2BIDetailsObj.get("PermMobileNo1") + "</PERM_MOBILE_NO_1>\r\n" + "<PERM_MOBILE_NO_2>"
					+ (String) L2BIDetailsObj.get("PermMobileNo2") + "</PERM_MOBILE_NO_2>\r\n" + "<PERM_LANDLINE_NO>"
					+ (String) L2BIDetailsObj.get("PermLandlineNo1") + "</PERM_LANDLINE_NO>\r\n" + "<PERM_STD>"
					+ (String) L2BIDetailsObj.get("PermSTD_forLandlineNo1") + "</PERM_STD>\r\n" +
					// "<BUSINESS_SOURCE>"+(String)
					// L2BIDetailsObj.get("BusinessSource")+"</BUSINESS_SOURCE>\r\n"
					// +

					"<MARITAL_STATUS>" + (String) L2BIDetailsObj.get("MaritalStatus") + "</MARITAL_STATUS>\r\n"
					+ "<EXACT_INCOME>" + (String) L2BIDetailsObj.get("ExactIncome") + "</EXACT_INCOME>\r\n"
					+ "<EDUCATION>" + (String) L2BIDetailsObj.get("Education") + "</EDUCATION>\r\n" + "<INDUSTRY_TYPE>"
					+ (String) L2BIDetailsObj.get("IndustryType") + "</INDUSTRY_TYPE>\r\n" + "<ORGANIZATION_TYPE>"
					+ (String) L2BIDetailsObj.get("OrganizationType") + "</ORGANIZATION_TYPE>\r\n" + "<INCOME_SOURCE>"
					+ (String) L2BIDetailsObj.get("IncomeSource") + "</INCOME_SOURCE>\r\n" + "<SPECIFY_INC_SRC>"
					+ (String) L2BIDetailsObj.get("PleaseSpecifyIncomeSource") + "</SPECIFY_INC_SRC>\r\n"
					+ "<OCCUPATION>" + (String) L2BIDetailsObj.get("Occupation") + "</OCCUPATION>\r\n"
					+ "<RELATIONSHIP_WITH_PROPOSER>" + (String) L2BIDetailsObj.get("RelationshipWithProposer")
					+ "</RELATIONSHIP_WITH_PROPOSER>\r\n" + "<SPECIFY_RELATION>"
					+ (String) L2BIDetailsObj.get("PleaseSpecifyRelationshipWithProposer") + "</SPECIFY_RELATION>\r\n"
					+ "<NATURE_OF_DUTIES>" + (String) L2BIDetailsObj.get("NatureOfDuties") + "</NATURE_OF_DUTIES>\r\n"
					+ "<CURRENTLY_POSTED>" + (String) L2BIDetailsObj.get("IsSensitiveLocation")
					+ "</CURRENTLY_POSTED>\r\n" + "<PROFESSIONAL_DIVER>"
					+ (String) L2BIDetailsObj.get("ProfessionalDiver") + "</PROFESSIONAL_DIVER>\r\n" + "<ROLE_INVOLVE>"
					+ (String) L2BIDetailsObj.get("MineRole") + "</ROLE_INVOLVE>\r\n" + "<ILLNESS_OCCUPATION>"
					+ (String) L2BIDetailsObj.get("AnyIllness") + "</ILLNESS_OCCUPATION>\r\n" + "<OFFSHORE>"
					+ (String) L2BIDetailsObj.get("IsTravelling") + "</OFFSHORE>\r\n" + "<NATURE_OF_JOB>"
					+ (String) L2BIDetailsObj.get("NatureOfJob") + "</NATURE_OF_JOB>\r\n" + "<FLYING_ROLE>"
					+ (String) L2BIDetailsObj.get("FlyWhat") + "</FLYING_ROLE>\r\n" + "<DIVE>"
					+ (String) L2BIDetailsObj.get("DiveLocation") + "</DIVE>\r\n" + "<TYPE_OF_VESSEL>"
					+ (String) L2BIDetailsObj.get("TypeOfVessel") + "</TYPE_OF_VESSEL>\r\n" + "<OCCUPATION_SPECIFY>"
					+ (String) L2BIDetailsObj.getOrDefault("SpecifyInsuredOccupation", "") + "</OCCUPATION_SPECIFY>\r\n" 
					+ "<DATE_OF_APPLICATION>"
					+ (String) L2BIDetailsObj.getOrDefault("DateOfApplication", "") + "</DATE_OF_APPLICATION>\r\n" 
					+ "<PAN_ACK_NO>"
					+ (String) L2BIDetailsObj.getOrDefault("PanAckNumber", "") + "</PAN_ACK_NO>\r\n" 
					+ "<PAN_NUMBER>"
					+ (String) L2BIDetailsObj.getOrDefault("PanNumber", "") + "</PAN_NUMBER>\r\n" 
					+ "<DO_YOU_HAVE_PAN>"
					+ (String) L2BIDetailsObj.getOrDefault("PANCardStatus", "") + "</DO_YOU_HAVE_PAN>\r\n" 
					+ "<PAN_AADHAR>"
					+ (String) L2BIDetailsObj.getOrDefault("IsPANLinkedWithAadhar", "") + "</PAN_AADHAR>\r\n" 
							+ "<NAME_COMPANY>"
							+ (String) L2BIDetailsObj.getOrDefault("CompanyName", "") + "</NAME_COMPANY>\r\n" 
									+ "<COMM_LANG>"
									+ (String) L2BIDetailsObj.getOrDefault("LanguageOfCommunication", "") + "</COMM_LANG>\r\n" 
											+ "<RESIDENTIAL_STATUS>"
											+ (String) L2BIDetailsObj.getOrDefault("ResidentialStatus", "") + "</RESIDENTIAL_STATUS>\r\n"
													+ "<MPROLCIENTID>"
													+ (String) L2BIDetailsObj.getOrDefault("InsuredClientId", "") + "</MPROLCIENTID>\r\n"
															+"<MproDedupe>" + (String) L2BIDetailsObj.getOrDefault("MproDedupe", "") + "</MproDedupe>\r\n"  //dr-17412	mansi
															+"<AbhaID>" + (String) L2BIDetailsObj.getOrDefault("AbhaID", "") + "</AbhaID>\r\n" //DR- 40109 By RITIKA
															+"<Countrycode1>" + (String) L2BIDetailsObj.getOrDefault("Countrycode1", "") + "</Countrycode1>\r\n" //DR- 42593 By RITIKA
															+"<Countrycode2>" + (String) L2BIDetailsObj.getOrDefault("Countrycode2", "") + "</Countrycode2>\r\n" //DR- 42593 By RITIKA
															+"<PermCountrycode1>" + (String) L2BIDetailsObj.getOrDefault("PermCountrycode1", "") + "</PermCountrycode1>\r\n" //DR- 42593 By RITIKA
															+"<PermCountrycode2>" + (String) L2BIDetailsObj.getOrDefault("PermCountrycode2", "") + "</PermCountrycode2>\r\n" //DR- 42593 By RITIKA
															+"<Email>" + (String) L2BIDetailsObj.getOrDefault("Email", "") + "</Email>\r\n" //DR- 49096 By Abhi
															+"<MobileNo>" + (String) L2BIDetailsObj.getOrDefault("MobileNo", "") + "</MobileNo>\r\n" //DR- 49096 By Abhi
					+ "</Q_L2BI_DETAILS>";

			JSONArray FrequentlyVisitedCountries = (JSONArray) L2BIDetailsObj.getOrDefault("FrequentlyVisitedCountries",
					"[]");
			for (Object j : FrequentlyVisitedCountries) {
				attributesXML = attributesXML + "<Q_LIST_COUNTRIES_FREQ_VISITED_L2BI>" + j.toString()
						+ "</Q_LIST_COUNTRIES_FREQ_VISITED_L2BI>";
			}

			JSONArray PassportIssuingCountryInsur = (JSONArray) L2BIDetailsObj.getOrDefault("PassportIssuingCountry",
					"[]");
			for (Object j : PassportIssuingCountryInsur) {
				attributesXML = attributesXML + "<Q__LIST_PASSPORT_COUNTRIES_L2BI>" + j.toString()
						+ "</Q__LIST_PASSPORT_COUNTRIES_L2BI>";
			}

			JSONArray CurrentCountryInsur = (JSONArray) L2BIDetailsObj.getOrDefault("CurrentCountry", "[]");
			for (Object j : CurrentCountryInsur) {
				attributesXML = attributesXML + "<Q_LIST_COUNTRY_OF_RESIDENCE_L2BI>" + j.toString()
						+ "</Q_LIST_COUNTRY_OF_RESIDENCE_L2BI>";
			}

			// NomineeDetails Section
			JSONObject NomineeDetailsObj = (JSONObject) jsonParser
					.parse(PersonalInformationObj.getOrDefault("NomineeDetails", "{}").toString());

			JSONArray L2BI_FTINArray;
			L2BI_FTINArray = (JSONArray) L2BIDetailsObj.getOrDefault("L2BI_FTNDetails", "[]");
			insertionOrderId = 0;
			hashID = 1;

			for (Object j : L2BI_FTINArray) {
				JSONObject jsonObj = (JSONObject) j;
				attributesXML = attributesXML + "<Q_LIST_FTN_DETAILS_L2BI>\r\n" + "<InsertionOrderId>"
						+ insertionOrderId + "</InsertionOrderId>" + "<HashId>" + hashID++ + "</HashId>"
						+ "<FTIN_NUMBER>" + jsonObj.get("FTIN_Number").toString() + "</FTIN_NUMBER>"
						+ "<FTIN_ISSUING_COUNTRY>" + jsonObj.get("FTIN_IssuingCountry").toString()
						+ "</FTIN_ISSUING_COUNTRY>" + "</Q_LIST_FTN_DETAILS_L2BI>";
			}

			/*
			 * attributesXML = attributesXML + "<Q_NOMINEE_DETAILS>\r\n" +
			 * "<CLIENT_TYPE>"+(String)
			 * NomineeDetailsObj.get("ClientType")+"</CLIENT_TYPE>\r\n" +
			 * //"<REASON_FOR_NOMINATION>"+(String)
			 * NomineeDetailsObj.get("ReasonForNomination")+
			 * "</REASON_FOR_NOMINATION>\r\n" + "<MWPA>"+(String)
			 * NomineeDetailsObj.get("MWPAToBeAdded")+"</MWPA>\r\n" +
			 * "<NOMINEE_TYPE>"+(String)
			 * NomineeDetailsObj.get("NomineeType")+"</NOMINEE_TYPE>\r\n" +
			 * "<PAN_NUMBER>"+(String)
			 * NomineeDetailsObj.get("PanNumber")+"</PAN_NUMBER>\r\n" +
			 * "<APPLIED_FOR_PAN>"+(String)
			 * NomineeDetailsObj.get("AppliedFor")+"</APPLIED_FOR_PAN>\r\n" +
			 * "<APP_ACK_NO>"+(String)
			 * NomineeDetailsObj.get("AppAckNumber")+"</APP_ACK_NO>\r\n" +
			 * "<NATIONALITY>"+(String)
			 * NomineeDetailsObj.get("Nationality")+"</NATIONALITY>\r\n" +
			 * "<BUSINESS_SOURCE>"+(String)
			 * NomineeDetailsObj.get("BusinessSource")+"</BUSINESS_SOURCE>\r\n"
			 * + "<COUNTRY>"+(String)
			 * NomineeDetailsObj.get("Country")+"</COUNTRY>\r\n" +
			 * "<SPECIFY_COUNTRY>"+(String)
			 * NomineeDetailsObj.get("SpecifyCountry")+"</SPECIFY_COUNTRY>\r\n"
			 * + "<PIN_CODE>"+(String)
			 * NomineeDetailsObj.get("PinCode")+"</PIN_CODE>\r\n" +
			 * "<HOUSENO_APTNAME>"+(String)
			 * NomineeDetailsObj.get("HouseNo/AptName/Society")+
			 * "</HOUSENO_APTNAME>\r\n" + "<ROAD_AREA_SEC>"+(String)
			 * NomineeDetailsObj.get("Road/Area/Sector")+"</ROAD_AREA_SEC>\r\n"
			 * + "<LANDMARK>"+(String)
			 * NomineeDetailsObj.get("Landmark")+"</LANDMARK>\r\n" +
			 * "<VILLAGE_TOWN>"+(String)
			 * NomineeDetailsObj.get("Village/Town")+"</VILLAGE_TOWN>\r\n" +
			 * "<CITY_DISTRICT>"+(String)
			 * NomineeDetailsObj.get("City/District")+"</CITY_DISTRICT>\r\n" +
			 * "<STATE_UT>"+(String)
			 * NomineeDetailsObj.get("State/UT")+"</STATE_UT>\r\n" +
			 * "<MOBILE_NO_1>"+(String)
			 * NomineeDetailsObj.get("MobileNo1")+"</MOBILE_NO_1>\r\n" +
			 * "<MOBILE_NO_2>"+(String)
			 * NomineeDetailsObj.get("MobileNo2")+"</MOBILE_NO_2>\r\n" +
			 * "<LANDLINE_NO>"+(String)
			 * NomineeDetailsObj.get("LandlineNo1")+"</LANDLINE_NO>\r\n" +
			 * "<STD>"+(String)
			 * NomineeDetailsObj.get("STD(LandlineNo1)")+"</STD>\r\n" +
			 * "<EMAIL_ID>"+(String)
			 * NomineeDetailsObj.get("EmailId")+"</EMAIL_ID>\r\n" +
			 * "<DATE_OF_APP>"+(String)
			 * NomineeDetailsObj.get("DateofApplication")+"</DATE_OF_APP>\r\n" +
			 * // "<SPECIFY_MWPA>"+(String)
			 * NomineeDetailsObj.get("PleaseSpecify")+"</SPECIFY_MWPA>\r\n" +
			 * "</Q_NOMINEE_DETAILS>";
			 */
			JSONArray NomineeDetailsArray;
			NomineeDetailsArray = (JSONArray) NomineeDetailsObj.get("NomineeDetailsGrid");
			insertionOrderId = 0;
			hashID = 1;

			for (Object j : NomineeDetailsArray) {
				JSONObject jsonObj = (JSONObject) j;
				attributesXML = attributesXML + "<Q_LIST_NOMINEE_DETAILS>\r\n" + "<InsertionOrderId>" + insertionOrderId
						+ "</InsertionOrderId>\r\n" + "<HashId>" + hashID++ + "</HashId>\r\n" + "<TITLE>"
						+ jsonObj.get("Title").toString() + "</TITLE>\r\n" + "<SPECIFY_TITLE>"
						+ jsonObj.get("PleaseSpecify").toString() + "</SPECIFY_TITLE>\r\n" + "<FIRST_NAME>"
						+ jsonObj.get("FirstName").toString() + "</FIRST_NAME>\r\n" + "<MIDDLE_NAME>"
						+ jsonObj.get("MiddleName").toString() + "</MIDDLE_NAME>\r\n" + "<LAST_NAME>"
						+ jsonObj.get("LastName").toString() + "</LAST_NAME>\r\n" + "<DOB>"
						+ jsonObj.get("DOB").toString() + "</DOB>\r\n" + "<GENDER>" + jsonObj.get("Gender").toString()
						+ "</GENDER>\r\n" + "<PERCENTAGE>" + jsonObj.get("PercentageShare").toString()
						+ "</PERCENTAGE>\r\n" + "<RELATIONSHIP_PROPOSER>"
						+ jsonObj.get("RelationshipWithProposer").toString() + "</RELATIONSHIP_PROPOSER>\r\n"
						+ "<PLEASE_SPECIFY>" + jsonObj.get("PleaseSpecifyRelationship").toString()
						+ "</PLEASE_SPECIFY>\r\n" + "<REASON_FOR_NOMINATION>"
						+ jsonObj.get("ReasonForNomination").toString() + "</REASON_FOR_NOMINATION>\r\n" 
						+"<SELECT_VALUE_MWPA>"+jsonObj.getOrDefault("MWPAToBeAdded","").toString()+"</SELECT_VALUE_MWPA>\r\n"+
						"<SAME_AS_PROPOSER>" + jsonObj.getOrDefault("AddressSameAsProposer", "").toString()
						+ "</SAME_AS_PROPOSER>\r\n" + "<NOMINEE_TYPE>"
						+ jsonObj.getOrDefault("NomineeType", "").toString() + "</NOMINEE_TYPE>\r\n" + "<PAN_NUMBER>"
						+ jsonObj.getOrDefault("PanNumber", "").toString() + "</PAN_NUMBER>\r\n" + "<APPLIED_FOR_PAN>"
						+ jsonObj.getOrDefault("AppliedFor", "").toString() + "</APPLIED_FOR_PAN>\r\n" + "<DATE_OF_APP>"
						+ jsonObj.getOrDefault("DateofApplication", "").toString() + "</DATE_OF_APP>\r\n"
						+ "<APP_ACK_NO>" + jsonObj.getOrDefault("AppAckNumber", "").toString() + "</APP_ACK_NO>\r\n"
						+ "<NATIONALITY>" + jsonObj.getOrDefault("Nationality", "").toString() + "</NATIONALITY>\r\n"
						+ "<BUSINESS_SOURCE>" + jsonObj.getOrDefault("BusinessSource", "").toString()
						+ "</BUSINESS_SOURCE>\r\n" + "<COUNTRY>" + jsonObj.getOrDefault("Country", "").toString()
						+ "</COUNTRY>\r\n" + "<PIN_CODE>" + jsonObj.getOrDefault("PinCode", "").toString()
						+ "</PIN_CODE>\r\n" + "<HOUSENO_APTNAME>"
						+ jsonObj.getOrDefault("HouseNo/AptName/Society", "").toString() + "</HOUSENO_APTNAME>\r\n"
						+ "<ROAD_AREA_SEC>" + jsonObj.getOrDefault("Road/Area/Sector", "").toString()
						+ "</ROAD_AREA_SEC>\r\n" + "<LANDMARK>" + jsonObj.getOrDefault("Landmark", "").toString()
						+ "</LANDMARK>\r\n" + "<VILLAGE_TOWN>" + jsonObj.getOrDefault("Village/Town", "").toString()
						+ "</VILLAGE_TOWN>\r\n" + "<CITY_DISTRICT>"
						+ jsonObj.getOrDefault("City/District", "").toString() + "</CITY_DISTRICT>\r\n" + "<STATE_UT>"
						+ jsonObj.getOrDefault("State/UT", "").toString() + "</STATE_UT>\r\n" + "<MOBILE_NO_1>"
						+ jsonObj.getOrDefault("MobileNo1", "").toString() + "</MOBILE_NO_1>\r\n" + "<MOBILE_NO_2>"
						+ jsonObj.getOrDefault("MobileNo2", "").toString() + "</MOBILE_NO_2>\r\n" + "<LANDLINE_NO>"
						+ jsonObj.getOrDefault("LandlineNo1", "").toString() + "</LANDLINE_NO>\r\n" + "<STD>"
						+ jsonObj.getOrDefault("STD(LandlineNo1)", "").toString() + "</STD>\r\n" + "<EMAIL_ID>"
						+ jsonObj.getOrDefault("EmailId", "").toString() + "</EMAIL_ID>\r\n" + "<NOMINEE_CLIENT_ID>"
						+ jsonObj.getOrDefault("NomineeClientId", "").toString() + "</NOMINEE_CLIENT_ID>\r\n"
						+ "<NOMINEE_AGE>" + jsonObj.getOrDefault("NomineeAge", "").toString() + "</NOMINEE_AGE>\r\n"
						+ "<ACCOUNT_NUMBER>" + jsonObj.getOrDefault("BankAccountNumber", "").toString() + "</ACCOUNT_NUMBER>\r\n"
						+ "<PERM_COUNTRY>" + jsonObj.getOrDefault("PermCountry", "").toString() + "</PERM_COUNTRY>\r\n"  // DR-51351, 51352 Lovnish
                        + "<PERM_PIN_CODE>" + jsonObj.getOrDefault("PermPincode", "").toString() + "</PERM_PIN_CODE>\r\n"
                        + "<PERM_HOUSENO_APT_NAME>" + jsonObj.getOrDefault("PermHouseNo/AptName/Society", "").toString() + "</PERM_HOUSENO_APT_NAME>\r\n"
                        + "<PERM_CITY>" + jsonObj.getOrDefault("PermCity", "").toString() + "</PERM_CITY>\r\n"
                        + "<PERM_STATE>" + jsonObj.getOrDefault("PermState", "").toString() + "</PERM_STATE>\r\n"
                        + "<PERM_ROAD_AREA_SEC>" + jsonObj.getOrDefault("PermRoad/Area/Sector", "").toString() + "</PERM_ROAD_AREA_SEC>\r\n"
                        + "<PERM_VILLAGE_TOWN>" + jsonObj.getOrDefault("PermVillage", "").toString() + "</PERM_VILLAGE_TOWN>\r\n"
                        + "<PERM_LANDMARK>" + jsonObj.getOrDefault("PermLandmark", "").toString() + "</PERM_LANDMARK>\r\n"
                		+ "<ACCOUNT_HOLDER_NAME>" + jsonObj.getOrDefault("AccountHolderName", "").toString() + "</ACCOUNT_HOLDER_NAME>\r\n"  // DR-51894
                		+ "<IFSC_CODE>" + jsonObj.getOrDefault("IFSCCode", "").toString() + "</IFSC_CODE>\r\n"
                		+ "<MICR_CODE>" + jsonObj.getOrDefault("MICRCode", "").toString() + "</MICR_CODE>\r\n"
                		+ "<BANK_NAME_BRANCH>" + jsonObj.getOrDefault("BankBranchName", "").toString() + "</BANK_NAME_BRANCH>\r\n"
        				+ "<TYPE_OF_BANK_ACC>" + jsonObj.getOrDefault("TypeOfBankAccount", "").toString() + "</TYPE_OF_BANK_ACC>\r\n"
                		+ "<ACC_OPENING_DATE>" + jsonObj.getOrDefault("AccountOpeningDate", "").toString() + "</ACC_OPENING_DATE>\r\n"
						+ "</Q_LIST_NOMINEE_DETAILS>";
			}

			// Guardian Details

			JSONArray GuardianDetailsArray;
			GuardianDetailsArray = (JSONArray) PersonalInformationObj.get("GuardianDetails");
			insertionOrderId = 0;
			hashID = 1;

			for (Object j : GuardianDetailsArray) {
				JSONObject jsonObj = (JSONObject) j;
				attributesXML = attributesXML + "<Q_LIST_GUARDIAN_DETAILS>\r\n" + "<InsertionOrderId>"
						+ insertionOrderId + "</InsertionOrderId>" + "<HashId>" + hashID++ + "</HashId>"
						+ "<FIRST_NAME>" + jsonObj.get("FirstName").toString() + "</FIRST_NAME>" + "<MIDDLE_NAME>"
						+ jsonObj.get("MiddleName").toString() + "</MIDDLE_NAME>" + "<LAST_NAME>"
						+ jsonObj.get("LastName").toString() + "</LAST_NAME>" + "<RELATIONSHIP>"
						+ jsonObj.get("Relationship").toString() + "</RELATIONSHIP>" + "<SPECIFY_RELATION>"
						+ jsonObj.get("PleaseSpecify").toString() + "</SPECIFY_RELATION>" + "<CLIENT_ID>"
						+ jsonObj.get("GuardianClientId").toString() + "</CLIENT_ID>" + "<TITLE>"
						+ jsonObj.get("Title").toString() + "</TITLE>" + "<DOB>"
						+ jsonObj.getOrDefault("DOB","").toString() + "</DOB>"
						+ "<EMAIL_ID>" + jsonObj.getOrDefault("GuardEmailID","").toString() + "</EMAIL_ID>" // DR-51351, 51352 Lovnish
                        + "<COUNTRY>" + jsonObj.getOrDefault("GuardCountry","").toString() + "</COUNTRY>"
                        + "<PIN_CODE>" + jsonObj.getOrDefault("GuardPincode","").toString() + "</PIN_CODE>"
                        + "<HOUSENO_APT_NAME>" + jsonObj.getOrDefault("GuardHouseNo/AptName/Society","").toString() + "</HOUSENO_APT_NAME>"                                        
                        + "<ROAD_AREA_SEC>" + jsonObj.getOrDefault("GuardRoad/Area/Sector","").toString() + "</ROAD_AREA_SEC>"
                        + "<LANDMARK>" + jsonObj.getOrDefault("GuardLandmark","").toString() + "</LANDMARK>"
                        + "<VILLAGE_TOWN>" + jsonObj.getOrDefault("GuardVillage/Town","").toString() + "</VILLAGE_TOWN>"
                        + "<CITY_DISTRICT>" + jsonObj.getOrDefault("GuardCity/District","").toString() + "</CITY_DISTRICT>"
                        + "<STATE_UT>" + jsonObj.getOrDefault("GuardState/UT","").toString() + "</STATE_UT>"
                        + "<PERM_COUNTRY>" + jsonObj.getOrDefault("GuardPermCountry","").toString() + "</PERM_COUNTRY>"
                        + "<PERM_PIN_CODE>" + jsonObj.getOrDefault("GuardPermPincode","").toString() + "</PERM_PIN_CODE>"
                        + "<PERM_HOUSENO_APT_NAME>" + jsonObj.getOrDefault("GuardPermHouseNo/AptName/Society","").toString() + "</PERM_HOUSENO_APT_NAME>"
                        + "<PERM_CITY>" + jsonObj.getOrDefault("GuardPermCity","").toString() + "</PERM_CITY>"
                        + "<PERM_STATE>" + jsonObj.getOrDefault("GuardPermState","").toString() + "</PERM_STATE>"
                        + "<PERM_ROAD_AREA_SEC>" + jsonObj.getOrDefault("GuardPermRoad/Area/Sector","").toString() + "</PERM_ROAD_AREA_SEC>"
                        + "<PERM_VILLAGE_TOWN>" + jsonObj.getOrDefault("GuardPermVillage/Town","").toString() + "</PERM_VILLAGE_TOWN>"
                        + "<PERM_LANDMARK>" + jsonObj.getOrDefault("GuardPermLandmark","").toString() + "</PERM_LANDMARK>"
                		+ "<ACCOUNT_NO>" + jsonObj.getOrDefault("BankAccountNumber","").toString() + "</ACCOUNT_NO>"  // DR-51894 Lovnish
                        + "<ACCOUNT_HOLDER_NAME>" + jsonObj.getOrDefault("AccountHolderName","").toString() + "</ACCOUNT_HOLDER_NAME>"
                        + "<IFSC_CODE>" + jsonObj.getOrDefault("IFSCCode","").toString() + "</IFSC_CODE>"
                        + "<MICR_CODE>" + jsonObj.getOrDefault("MICRCode","").toString() + "</MICR_CODE>"
                        + "<BANK_NAME_BRANCH>" + jsonObj.getOrDefault("BankBranchName","").toString() + "</BANK_NAME_BRANCH>"
                        + "<TYPE_OF_BANK_ACC>" + jsonObj.getOrDefault("TypeOfBankAccount","").toString() + "</TYPE_OF_BANK_ACC>"
                        + "<ACC_OPENING_DATE>" + jsonObj.getOrDefault("AccountOpeningDate","").toString() + "</ACC_OPENING_DATE>"
                		+ "<MOBILE_NO_1>" + jsonObj.getOrDefault("MobileNo1","").toString() + "</MOBILE_NO_1>" // DR-51332 
                		+ "<MOBILE_NO_2>" + jsonObj.getOrDefault("MobileNo2","").toString() + "</MOBILE_NO_2>" 
                		+ "<STD>" + jsonObj.getOrDefault("STD","").toString() + "</STD>"
                		+ "<LANDLINE_NO>" + jsonObj.getOrDefault("LandlineNumber","").toString() + "</LANDLINE_NO>"
						+"</Q_LIST_GUARDIAN_DETAILS>";
			}

			// child details
			JSONObject ChildDetailsObj = (JSONObject) jsonParser
					.parse(PersonalInformationObj.getOrDefault("ChildDetails", "{}").toString());

			Q_Personal_Other_Client_type3 = (String) ChildDetailsObj.get("ClientType");
			Q_Personal_Other_First_Name4 = (String) ChildDetailsObj.get("FirstName");
			Q_Personal_Other_Middle_Name4 = (String) ChildDetailsObj.get("MiddleName");
			Q_Personal_Other_Last_Name4 = (String) ChildDetailsObj.get("LastName");
			Q_Personal_Other_DOB4 = (String) ChildDetailsObj.get("DOB");
			String Q_CHILD_DETAILS_SAME_AS_NOMINEE = (String) ChildDetailsObj.get("SameAsNominee");
			attributesXML = attributesXML + "<Q_CHILD_DETAILS>"
			// + "<CLIENT_TYPE>" + Q_Personal_Other_Client_type3 +
			// "</CLIENT_TYPE>"
					+ "<FIRST_NAME>" + Q_Personal_Other_First_Name4 + "</FIRST_NAME>" + "<Middle_Name>"
					+ Q_Personal_Other_Middle_Name4 + "</Middle_Name>" + "<Last_Name>" + Q_Personal_Other_Last_Name4
					+ "</Last_Name>" + "<DOB>" + Q_Personal_Other_DOB4 + "</DOB>" + "<SAME_AS_NOMINEE>"
					+ Q_CHILD_DETAILS_SAME_AS_NOMINEE + "</SAME_AS_NOMINEE>" + "<CLIENT_ID>"
					+ (String) ChildDetailsObj.get("ChildClientId") + "</CLIENT_ID>"
					// SAME_AS_NOMINEE
					+ "</Q_CHILD_DETAILS>";

			// policy validation details section
			JSONObject PolValidationDetailsObj = (JSONObject) jsonParser
					.parse(PersonalInformationObj.getOrDefault("PolicyValidiationDetails", "{}").toString());

			attributesXML = attributesXML + "<Q_POLICY_VALIDATION_DETAILS>\r\n" +
			// "<STRAIGHT_PASS_CASE>"+(String)
			// PolValidationDetailsObj.get("StraightPassCase")+"</STRAIGHT_PASS_CASE>\r\n"
			// +
					"<DEDUPE>" + (String) PolValidationDetailsObj.get("DedupeExactMatch") + "</DEDUPE>\r\n"
					+ "<PAN_CARD_COPY_REQ>" + (String) PolValidationDetailsObj.get("PANCardCopyRequired")
					+ "</PAN_CARD_COPY_REQ>\r\n" + "<ID_DOB_PROOF_REQ>"
					+ (String) PolValidationDetailsObj.get("DOBProofRequired") + "</ID_DOB_PROOF_REQ>\r\n"
					+ "<INCOME_PROOF_PROP>" + (String) PolValidationDetailsObj.get("IncomeProofForProposer")
					+ "</INCOME_PROOF_PROP>\r\n" + "<NACH_REQ>" + (String) PolValidationDetailsObj.get("NACHRequired")
					+ "</NACH_REQ>\r\n" + "<PHOTO_REQ>" + (String) PolValidationDetailsObj.get("PhotographRequired")
					+ "</PHOTO_REQ>\r\n" + "<NEFT_SUPPORT_DOC_REQ>"
					+ (String) PolValidationDetailsObj.get("NEFTDocRequired") + "</NEFT_SUPPORT_DOC_REQ>\r\n"
					+ "<CREDIT_SCORE>" + (String) PolValidationDetailsObj.get("CreditScore") + "</CREDIT_SCORE>\r\n"
					+ "<INCOME_SEGMENT>" + (String) PolValidationDetailsObj.get("IncomeSegment")
					+ "</INCOME_SEGMENT>\r\n" + "<BSE_500>" + (String) PolValidationDetailsObj.get("BSE500")
					+ "</BSE_500>\r\n" + "<IRP_REQ>" + (String) PolValidationDetailsObj.get("IRPRequired")
					+ "</IRP_REQ>\r\n" + "<FACT_FINDER_REQ>"
					+ (String) PolValidationDetailsObj.get("FactFinderRequired") + "</FACT_FINDER_REQ>\r\n"
					+ "</Q_POLICY_VALIDATION_DETAILS>";

			attributesXML = attributesXML + "<STRAIGHT_PASS_CASE>"
					+ (String) PolValidationDetailsObj.get("StraightPassCase") + "</STRAIGHT_PASS_CASE>";

			// product and payment info TAB
			JSONObject ProductAndPaymentObj = (JSONObject) jsonParser
					.parse(json.getOrDefault("ProductandPaymentInformation", "{}").toString());

			// CoverageDetails
			String Q_COVERAGE_DETAILS_GURANTEED_DEATH_BENEFIT = "", Q_COVERAGE_DETAILS_REQ_MODAL_PREMIUM = "",
					Q_COVERAGE_DETAILS_TOTAL_REQ_PREMIUM = "", Q_COVERAGE_DETAILS_AFYP = "";
			// Q_COVERAGE_DETAILS_DEATH_BENEFIT
			JSONObject CoverageDetailsObj = (JSONObject) jsonParser
					.parse(ProductAndPaymentObj.get("CoverageDetails").toString());
			
			

			Q_COVERAGE_DETAILS_PRODUCT_NAME = (String) CoverageDetailsObj.get("ProductName");
			Q_COVERAGE_DETAILS_VESTING_AGE = (String) CoverageDetailsObj.get("VestingAge");
			Q_COVERAGE_DETAILS_COVERAGE_TERM = (String) CoverageDetailsObj.get("CoverageTerm");
			Q_COVERAGE_DETAILS_PREMIUM_PAY_TERM = (String) CoverageDetailsObj.get("PremiumPaymentTerm");
			Q_COVERAGE_DETAILS_PREMIUM_BACK = (String) CoverageDetailsObj.get("PremiumBackOption");
			Q_COVERAGE_DETAILS_COVERAGE_MULTIPLE = (String) CoverageDetailsObj.get("CoverageMultiple");
			Q_COVERAGE_DETAILS_SUM_ASSURED = (String) CoverageDetailsObj.get("SumAssured");
			Q_COVERAGE_DETAILS_GURANTEED_DEATH_BENEFIT = (String) CoverageDetailsObj.get("GuaranteedDeathBenefit");
			Q_COVERAGE_DETAILS_DEATH_BENEFIT = (String) CoverageDetailsObj.get("DeathBenefit");
			Q_COVERAGE_DETAILS_ATP = (String) CoverageDetailsObj.get("ATP");
			Q_COVERAGE_DETAILS_MODE_OF_PAY = (String) CoverageDetailsObj.get("ModeofPayment");
			Q_COVERAGE_DETAILS_MODAL_PREMIUM = (String) CoverageDetailsObj.get("ModalPremium");
			Q_COVERAGE_DETAILS_GST = (String) CoverageDetailsObj.get("ServiceTaxGST");
			Q_COVERAGE_DETAILS_SAVE_MORE_TOMORROW = (String) CoverageDetailsObj.get("SaveMoreTomorrow");
			Q_COVERAGE_DETAILS_EMP_DISCOUNT = (String) CoverageDetailsObj.get("EmployeeDiscount");
			Q_COVERAGE_DETAILS_EXISTING_CUST_DISCOUNT = (String) CoverageDetailsObj.get("ExistingCustomerDiscount");
			Q_COVERAGE_DETAILS_SMOKER_CLASS = (String) CoverageDetailsObj.get("SmokerClass");
			Q_COVERAGE_DETAILS_LIFE_EVENT = (String) CoverageDetailsObj.get("LifeEvent");
			Q_COVERAGE_DETAILS_GUARANTEE_MON_INCOME = (String) CoverageDetailsObj.get("GuaranteedMonthlyIncome");
			Q_COVERAGE_DETAILS_GUARANTEE_ANNUAL_INCOME = (String) CoverageDetailsObj.get("GuaranteeAnnualIncome");
			Q_COVERAGE_DETAILS_GIP_PAYOUT_DAY = (String) CoverageDetailsObj.get("GIPPayoutDay");
			Q_COVERAGE_DETAILS_GIP_PAYOUT_METHOD = (String) CoverageDetailsObj.get("GIPPayoutMethod");
			Q_COVERAGE_DETAILS_NON_FORFEITURE = (String) CoverageDetailsObj.get("NonForfeitureOption");
			Q_COVERAGE_DETAILS_BONUS_OPTION = (String) CoverageDetailsObj.get("BonusOption");
			Q_COVERAGE_DETAILS_EFFECTIVE_DATE = (String) CoverageDetailsObj.get("EffectiveDate");
			Q_COVERAGE_DETAILS_REQ_MODAL_PREMIUM = (String) CoverageDetailsObj.get("RequiredModalPremium");
			Q_COVERAGE_DETAILS_TOTAL_REQ_PREMIUM = (String) CoverageDetailsObj.get("TotalRequiredPremium");
			Q_COVERAGE_DETAILS_AFYP = (String) CoverageDetailsObj.get("AFYP");
			String CoverageString = (String) CoverageDetailsObj.get("CoverageString");
			String Income = (String) CoverageDetailsObj.get("Income");
			
			String 	Q_COVERAGE_DETAILS_SMART_WITHDRAWL_OPTION = (String) CoverageDetailsObj.get("SmartWithdrawalOption");
			String 	Q_COVERAGE_DETAILS_SMART_WITHDRAWL_STARTYEAR = (String) CoverageDetailsObj.get("SmartWithdrawalStartYear");
			String 	Q_COVERAGE_DETAILS_SMART_WITHDRAWL_MODE = (String) CoverageDetailsObj.get("SmartWithdrawalMode");
			String 	Q_COVERAGE_DETAILS_SMART_WITHDRAWL_PERCENTAGE = (String) CoverageDetailsObj.get("SmartWithdrawalPercentage");
			String MaturityAge = (String) CoverageDetailsObj.getOrDefault("MaturityAge", "");
			String BIGenDate = (String) CoverageDetailsObj.getOrDefault("BIGenDate", "");
			
			String DeferredPeriod = (String) CoverageDetailsObj.getOrDefault("DeferredPeriod", "");
			String IncomeStartYear = (String) CoverageDetailsObj.getOrDefault("IncomeStartYear", "");
			String IncomePeriod = (String) CoverageDetailsObj.getOrDefault("IncomePeriod", "");
			String DesireDateofIncomePayout = (String) CoverageDetailsObj.getOrDefault("DesireDateofIncomePayout", "");
			String IncomePayoutDate = (String) CoverageDetailsObj.getOrDefault("IncomePayoutDate", "");
			String PremiumOffset = (String) CoverageDetailsObj.getOrDefault("PremiumOffset", "");

			JSONArray riderDetailsArray;
			riderDetailsArray = (JSONArray) CoverageDetailsObj.get("RiderDetails");
			insertionOrderId = 0;
			hashID = 1;

			for (Object j : riderDetailsArray) {
				JSONObject jsonObj = (JSONObject) j;

				attributesXML = attributesXML + "<Q_LIST_RIDER_DETAILS>\r\n" + "<InsertionOrderId>" + insertionOrderId
						+ "</InsertionOrderId>\r\n" + "<HashId>" + hashID++ + "</HashId>\r\n" + "<RIDER_TYPE>"
						+ jsonObj.get("RiderType").toString() + "</RIDER_TYPE>" + "<COVERAGE_TERM>"
						+ jsonObj.get("CoverageTerm").toString() + "</COVERAGE_TERM>\r\n" + "<SUM_ASSURED>"
						+ jsonObj.get("SumAssured").toString() + "</SUM_ASSURED>\r\n" + "<MODAL_PREMIUM>"
						+ jsonObj.get("ModalPremium").toString() + "</MODAL_PREMIUM>\r\n" + "<GST>"
						+ jsonObj.get("GST").toString() + "</GST>\r\n" + "<INSURED_DETAILS>"
						+ jsonObj.get("RiderInsuredDetails").toString() + "</INSURED_DETAILS>" + "<PPT>"
						+ jsonObj.getOrDefault("PPT", "").toString() + "</PPT>" +"<AFYP>"
						+ jsonObj.getOrDefault("RiderAfyp","").toString() + "</AFYP>" +  //DR-48700 ezaz
						// "<REQD_MODAL_PREMIUM>"+jsonObj.get("RequriedModalPremium").toString()+"</REQD_MODAL_PREMIUM>\r\n"
						// +
						// "<TOTAL_REQD_PREMIUM>"+jsonObj.get("TotalRequiredPremium").toString()+"</TOTAL_REQD_PREMIUM>\r\n"
						// +
						// "<AFYP>"+jsonObj.get("AFYP").toString()+"</AFYP>\r\n"
						// +
						"</Q_LIST_RIDER_DETAILS>";
			}
			hashID = 1;

			attributesXML = attributesXML + "<Q_COVERAGE_DETAILS>" + "<PRODUCT_NAME>" + Q_COVERAGE_DETAILS_PRODUCT_NAME
					+ "</PRODUCT_NAME>" + "<VESTING_AGE>" + Q_COVERAGE_DETAILS_VESTING_AGE + "</VESTING_AGE>"
					+ "<COVERAGE_TERM>" + Q_COVERAGE_DETAILS_COVERAGE_TERM + "</COVERAGE_TERM>" + "<PREMIUM_PAY_TERM>"
					+ Q_COVERAGE_DETAILS_PREMIUM_PAY_TERM + "</PREMIUM_PAY_TERM>" + "<PREMIUM_BACK>"
					+ Q_COVERAGE_DETAILS_PREMIUM_BACK + "</PREMIUM_BACK>" + "<COVERAGE_MULTIPLE>"
					+ Q_COVERAGE_DETAILS_COVERAGE_MULTIPLE + "</COVERAGE_MULTIPLE>" + "<SUM_ASSURED>"
					+ Q_COVERAGE_DETAILS_SUM_ASSURED + "</SUM_ASSURED>" + "<GUARANTEE_DEATH_BENEFIT>"
					+ Q_COVERAGE_DETAILS_GURANTEED_DEATH_BENEFIT + "</GUARANTEE_DEATH_BENEFIT>" + "<DEATH_BENEFIT>"
					+ Q_COVERAGE_DETAILS_DEATH_BENEFIT + "</DEATH_BENEFIT>" + "<ATP>" + Q_COVERAGE_DETAILS_ATP
					+ "</ATP>" + "<MODE_OF_PAY>" + Q_COVERAGE_DETAILS_MODE_OF_PAY + "</MODE_OF_PAY>" + "<MODAL_PREMIUM>"
					+ Q_COVERAGE_DETAILS_MODAL_PREMIUM + "</MODAL_PREMIUM>" + "<GST>" + Q_COVERAGE_DETAILS_GST
					+ "</GST>" + "<SAVE_MORE_TOMORROW>" + Q_COVERAGE_DETAILS_SAVE_MORE_TOMORROW
					+ "</SAVE_MORE_TOMORROW>" + "<EMP_DISCOUNT>" + Q_COVERAGE_DETAILS_EMP_DISCOUNT + "</EMP_DISCOUNT>"
					+ "<EXISTING_CUST_DISCOUNT>" + Q_COVERAGE_DETAILS_EXISTING_CUST_DISCOUNT
					+ "</EXISTING_CUST_DISCOUNT>" + "<SMOKER_CLASS>" + Q_COVERAGE_DETAILS_SMOKER_CLASS
					+ "</SMOKER_CLASS>" + "<LIFE_EVENT>" + Q_COVERAGE_DETAILS_LIFE_EVENT + "</LIFE_EVENT>"
					+ "<GUARANTEE_MON_INCOME>" + Q_COVERAGE_DETAILS_GUARANTEE_MON_INCOME + "</GUARANTEE_MON_INCOME>"
					+ "<GUARANTEE_ANNUAL_INCOME>" + Q_COVERAGE_DETAILS_GUARANTEE_ANNUAL_INCOME
					+ "</GUARANTEE_ANNUAL_INCOME>" + "<GIP_PAYOUT_DAY>" + Q_COVERAGE_DETAILS_GIP_PAYOUT_DAY
					+ "</GIP_PAYOUT_DAY>" + "<GIP_PAYOUT_METHOD>" + Q_COVERAGE_DETAILS_GIP_PAYOUT_METHOD
					+ "</GIP_PAYOUT_METHOD>" + "<NON_FORFEITURE>" + Q_COVERAGE_DETAILS_NON_FORFEITURE
					+ "</NON_FORFEITURE>" + "<BONUS_OPTION>" + Q_COVERAGE_DETAILS_BONUS_OPTION + "</BONUS_OPTION>"
					+ "<EFFECTIVE_DATE>" + Q_COVERAGE_DETAILS_EFFECTIVE_DATE + "</EFFECTIVE_DATE>"
					+ "<REQ_MODAL_PREMIUM>" + Q_COVERAGE_DETAILS_REQ_MODAL_PREMIUM + "</REQ_MODAL_PREMIUM>"
					+ "<COVERAGE_STRING>" + CoverageString + "</COVERAGE_STRING>" + "<TOTAL_REQ_PREMIUM>"
					+ Q_COVERAGE_DETAILS_TOTAL_REQ_PREMIUM + "</TOTAL_REQ_PREMIUM>" + "<INCOME>" + Income + "</INCOME>"
					+ "<INCOME_FREQUENCY>" + (String) CoverageDetailsObj.getOrDefault("IncomeFrequency", "")
					+ "</INCOME_FREQUENCY>"+"<GSTWAIVER>" + (String) CoverageDetailsObj.getOrDefault("GstWaiver", "")
					+ "</GSTWAIVER>"+"<PREMIUM_BREAK>" + (String) CoverageDetailsObj.getOrDefault("PremiumBreak", "")
					+ "</PREMIUM_BREAK>"+"<Premium_Break_1>" + (String) CoverageDetailsObj.getOrDefault("PremiumBreakOption1", "")
					+ "</Premium_Break_1>"
					+
					"<Premium_Break_2>" + (String) CoverageDetailsObj.getOrDefault("PremiumBreakOption2", "")
					+ "</Premium_Break_2>"+  
					"<SMART_WITHDRAWL_OPTION>" + (String) CoverageDetailsObj.getOrDefault("SmartWithdrawalOption", "")
					+ "</SMART_WITHDRAWL_OPTION>"+ 
					"<SMART_WITHDRAWL_STARTYEAR>" + (String) CoverageDetailsObj.getOrDefault("SmartWithdrawalStartYear", "")
					+ "</SMART_WITHDRAWL_STARTYEAR>"+ 
					"<SMART_WITHDRAWL_MODE>" + (String) CoverageDetailsObj.getOrDefault("SmartWithdrawalMode", "")
					+ "</SMART_WITHDRAWL_MODE>"+ 
					"<SMART_WITHDRAWL_PERCENTAGE>" + (String) CoverageDetailsObj.getOrDefault("SmartWithdrawalPercentage", "")
					+ "</SMART_WITHDRAWL_PERCENTAGE>"+ 
					"<MATURITY_AGE>" + (String) CoverageDetailsObj.getOrDefault("MaturityAge", "")
					+ "</MATURITY_AGE>"+ 
					"<SEC_PRODUCT_NAME>" + Product_Name_Combo
					+ "</SEC_PRODUCT_NAME>"+ 
					"<SEC_SUM_ASSURED>" + (String) CoverageDetailsObj.getOrDefault("SumAssuredCombo", "")
					+ "</SEC_SUM_ASSURED>"+
					"<SEC_MODAL_PREMIUM>" + (String) CoverageDetailsObj.getOrDefault("ModalPremiumCombo", "")
					+ "</SEC_MODAL_PREMIUM>"+
					"<SEC_COVERAGE_TERM>" + (String) CoverageDetailsObj.getOrDefault("CoverageTermCombo", "")
					+ "</SEC_COVERAGE_TERM>"+
					"<SEC_PPT>" + (String) CoverageDetailsObj.getOrDefault("PremiumPaymentTermCombo", "")
					+ "</SEC_PPT>"+
					"<SEC_GST>" + (String) CoverageDetailsObj.getOrDefault("ServiceTaxGSTCombo", "")
					+ "</SEC_GST>"+
					"<SEC_GDB>" + (String) CoverageDetailsObj.getOrDefault("GuaranteedDeathBenefitCombo", "")
					+ "</SEC_GDB>"+
					"<SEC_DISCOUNT>" + (String) CoverageDetailsObj.getOrDefault("ExistingCustomerDiscountCombo", "")
					+ "</SEC_DISCOUNT>"+
					"<SEC_AFYP>" + (String) CoverageDetailsObj.getOrDefault("AFYPCombo", "")
					+ "</SEC_AFYP>"+
					"<SEC_SMART_WITHDRAWAL_OPTION>" + (String) CoverageDetailsObj.getOrDefault("SmartWithdrawalOptionCombo", "")
					+ "</SEC_SMART_WITHDRAWAL_OPTION>"+
					"<SEC_SMART_WITHDRAWAL_STARTYEAR>" + (String) CoverageDetailsObj.getOrDefault("SmartWithdrawalStartYearCombo", "")
					+ "</SEC_SMART_WITHDRAWAL_STARTYEAR>"+
					"<SEC_SMART_WITHDRAWAL_PAYOUT>" + (String) CoverageDetailsObj.getOrDefault("SmartWithdrawalModeCombo", "")
					+ "</SEC_SMART_WITHDRAWAL_PAYOUT>"+
					"<SEC_SMART_WITHRAWAL_PERCENT>" + (String) CoverageDetailsObj.getOrDefault("SmartWithdrawalPercentageCombo", "")
					+ "</SEC_SMART_WITHRAWAL_PERCENT>"+
					"<SEC_REQ_MODAL_PREMIUM>" + (String) CoverageDetailsObj.getOrDefault("RequiredModalPremiumCombo", "")
					+ "</SEC_REQ_MODAL_PREMIUM>"+
					"<SEC_TOTAL_PREMIUM>" + (String) CoverageDetailsObj.getOrDefault("TotalRequiredPremiumCombo", "")
					+ "</SEC_TOTAL_PREMIUM>"+
					"<COMBO_DESIRED_PREMIUM>" + (String) CoverageDetailsObj.getOrDefault("DesiredPremiumCombo", "")
					+ "</COMBO_DESIRED_PREMIUM>"+
					"<ATP_COMBO>" + (String) CoverageDetailsObj.getOrDefault("ATPCombo", "")
					+ "</ATP_COMBO>"+
					"<COVERAGE_MULTIPLE_COMBO>" + Q_COVERAGE_DETAILS_COVERAGE_MULTIPLE
					+ "</COVERAGE_MULTIPLE_COMBO>"+
					"<ANNUAL_PREM_BASE>" + (String) CoverageDetailsObj.getOrDefault("AnnualPremiumOfBase", "")
					+ "</ANNUAL_PREM_BASE>"+
					"<DEATH_BENEFIT_MULTIPLE>" + (String) CoverageDetailsObj.getOrDefault("DeathBenefitMultiple", "")
					+ "</DEATH_BENEFIT_MULTIPLE>"+
					"<VARIANT>" + (String) CoverageDetailsObj.getOrDefault("Variant", "")
					+ "</VARIANT>"+
					"<BI_GEN_DATE>" + (String) CoverageDetailsObj.getOrDefault("BIGenDate", "")
					+ "</BI_GEN_DATE>"+
					
					"<DEFER_PERIOD>" + (String) CoverageDetailsObj.getOrDefault("DeferredPeriod", "")
					+ "</DEFER_PERIOD>"+
					"<INCOME_PERIOD>" + (String) CoverageDetailsObj.getOrDefault("IncomePeriod", "")
					+ "</INCOME_PERIOD>"+
					"<INCOME_STARTYEAR>" + (String) CoverageDetailsObj.getOrDefault("IncomeStartYear", "")
					+ "</INCOME_STARTYEAR>"+
					"<DESIRE_INCOMEPAYOUT>" + (String) CoverageDetailsObj.getOrDefault("DesireDateofIncomePayout", "")
					+ "</DESIRE_INCOMEPAYOUT>"+
					"<INCOMEPAYOUT_DATE>" + (String) CoverageDetailsObj.getOrDefault("IncomePayoutDate", "")
					+ "</INCOMEPAYOUT_DATE>"+
					"<INCOME_OFFSET>" + (String) CoverageDetailsObj.getOrDefault("PremiumOffset", "")
					+ "</INCOME_OFFSET>"+
					
					"<CUSTOMER_SELECTED_EDC_TAG>" +(String) CoverageDetailsObj.get("CustomerSelectedEDCTag")+ "</CUSTOMER_SELECTED_EDC_TAG>"+ 	//dr-15359 EDC mansi
					//DR-23942 by sparsh
					"<PREMIUM_JOINT>" +(String) CoverageDetailsObj.get("PremiumJoint")+ "</PREMIUM_JOINT>"+ 	
					"<SUM_ASSURED_JOINT>" +(String) CoverageDetailsObj.get("SumAssuredJoint")+ "</SUM_ASSURED_JOINT>"+ 	
					"<GST_JOINT>" +(String) CoverageDetailsObj.get("ServiceTaxGSTJoint")+ "</GST_JOINT>"+ 
					"<COVERAGE_TERM_JOINT>" +(String) CoverageDetailsObj.get("CoverageTermJoint")+ "</COVERAGE_TERM_JOINT>"+ 
					"<PREMIUM_PAY_TERM_JOINT>" +(String) CoverageDetailsObj.get("PremiumPaymentTermJoint")+ "</PREMIUM_PAY_TERM_JOINT>"+ 
					"<SMOKER_CLASS_INSURED>" +(String) CoverageDetailsObj.get("SmokerClassInsured")+ "</SMOKER_CLASS_INSURED>"+ 
					"<ACCRUAL_OPTION>" +(String) CoverageDetailsObj.get("AccrualOption")+ "</ACCRUAL_OPTION>"+  //DR-24153
					"<GSTIN_Number>" +(String) CoverageDetailsObj.getOrDefault("GSTIN_NUMBER","")+ "</GSTIN_Number>"+ 	//DR-15823 mansi
					"<INPUT_RATE_OF_RETURN>" +(String) CoverageDetailsObj.get("InputRateOfReturn")+ "</INPUT_RATE_OF_RETURN>"+  //DR-28084 DRON
					"<PAYOUT_PERIOD>" +(String) CoverageDetailsObj.get("PayoutPeriod")+ "</PAYOUT_PERIOD>"+  //DR- 28244 Sparsh
					"<WELLNESS_DISCOUNT>" +(String) CoverageDetailsObj.get("IsWellnessProgram")+ "</WELLNESS_DISCOUNT>"+  //DR- 31327 NIKITA
					"<PROPOSITION_OF_ROP>" +(String) CoverageDetailsObj.get("ReturnOfPremiumPercentage")+ "</PROPOSITION_OF_ROP>"+  //DR- 33955 NIKITA
					"<EARLY_ROP>" +(String) CoverageDetailsObj.get("EarlyROPPercentage")+ "</EARLY_ROP>"+  //DR- 33955 NIKITA
					"<EARLY_ROP_MILESTONE>" +(String) CoverageDetailsObj.get("MilestoneAge")+ "</EARLY_ROP_MILESTONE>"+  //DR- 33955 NIKITA
					"<GUARANTEED_ANNUITY_PERIOD>" +(String) CoverageDetailsObj.get("GuaranteeAnnuityPeriod")+ "</GUARANTEED_ANNUITY_PERIOD>"+  //DR- 33955 NIKITA
					"<INC_ANNUITY_PERCENTAGE>" +(String) CoverageDetailsObj.get("IncreasingAnnuityPercentage")+ "</INC_ANNUITY_PERCENTAGE>"+  //DR- 33955 NIKITA
		    		"<PROPOSITION_OF_ANNUITY>" +(String) CoverageDetailsObj.get("ProportionOfAnnuityLastSurvivor")+ "</PROPOSITION_OF_ANNUITY>"+  //DR- 33955 NIKITA
					"<DEFERMENT_PERIOD>" +(String) CoverageDetailsObj.get("defermentPeriodMonth")+ "</DEFERMENT_PERIOD>"+  //DR- 33955 NIKITA
					"<SURVIVAL_BENEFIT_PERIOD>" +(String) CoverageDetailsObj.get("SurvivalBenefitPeriod")+ "</SURVIVAL_BENEFIT_PERIOD>"+  //DR- 40123 NIKITA
					"<EmployeeID>" +(String) CoverageDetailsObj.getOrDefault("EmployeeID","")+ "</EmployeeID>"+ // DR 46327 by Ezaz
					"<INCOME_PAYOUT_OPTION>" +(String) CoverageDetailsObj.getOrDefault("IncomePayoutOption","")+ "</INCOME_PAYOUT_OPTION>"+
					"<PbEstimatedIncome>" +(String) CoverageDetailsObj.getOrDefault("PbEstimatedIncome","")+ "</PbEstimatedIncome>"+ //DR-46868 Nikita
					"<SolutionPlanInfo>" +(String) CoverageDetailsObj.getOrDefault("SolutionPlanInfo","")+ "</SolutionPlanInfo>"+  //DR-48500 ezaz
					"<CustomerReminderConsent>" +(String) CoverageDetailsObj.getOrDefault("CustomerReminderConsent","")+ "</CustomerReminderConsent>"+  //DR-52169 ezaz
					"<Income_Cover>" +(String) CoverageDetailsObj.getOrDefault("IncomeCover","")+ "</Income_Cover>"+  //DR-52264 ezaz
					"<Sum_Assured_Booster>" +(String) CoverageDetailsObj.getOrDefault("SumAssuredBooster","")+ "</Sum_Assured_Booster>"+  //DR-52264 ezaz
					"<Sum_Assured_Booster_Value>" +(String) CoverageDetailsObj.getOrDefault("SumAssuredBoosterValue","")+ "</Sum_Assured_Booster_Value>"+  //DR-52264 ezaz
					"<Epfo_Income>" +(String) CoverageDetailsObj.getOrDefault("EpfoIncome","")+ "</Epfo_Income>"+  //DR-52264 ezaz
					"<Special_Uw_Sa>" +(String) CoverageDetailsObj.getOrDefault("SpecialUwSa","")+ "</Special_Uw_Sa>"+  //DR-52264 ezaz
                    
					"</Q_COVERAGE_DETAILS>";
			attributesXML = attributesXML + "<AFYP>" + Q_COVERAGE_DETAILS_AFYP + "</AFYP>";
			
			attributesXML = attributesXML + "<EFFECTIVE_DATE_MPRO>" + Q_COVERAGE_DETAILS_EFFECTIVE_DATE
					+ "</EFFECTIVE_DATE_MPRO>" ;

			
			//aanchal
			JSONObject BankingInformationObj = (JSONObject) jsonParser
                    .parse(ProductAndPaymentObj.getOrDefault("BankingInformation", "{}").toString());
            attributesXML = attributesXML +"<Q_BANKING_INFO><BANKING_SINCE>" + BankingInformationObj.getOrDefault("BankingSince","").toString()
                    + "</BANKING_SINCE></Q_BANKING_INFO>";
            //aanchal
            
			// FinancialInformation
			/*
			 * JSONObject FinancialInfoObj = (JSONObject)
			 * jsonParser.parse(ProductAndPaymentObj.getOrDefault(
			 * "FinancialInformation","{}").toString());
			 * 
			 * Q_PRODUCT_AND_PAYMENT_INFO_Sourceoffunds = (String)
			 * FinancialInfoObj.get("SourceofFunds"); L_IncomeProof = (String)
			 * FinancialInfoObj.get("IncomeProofofProposer");
			 * Q_PRODUCT_AND_PAYMENT_INFO_Doyouownavehicle = (String)
			 * FinancialInfoObj.get("DoyouOwnaVehicle");
			 * Q_PRODUCT_AND_PAYMENT_INFO_Wheeler2 = (String)
			 * FinancialInfoObj.get("2Wheeler");
			 * Q_PRODUCT_AND_PAYMENT_INFO_priceofpurchase1 = (String)
			 * FinancialInfoObj.get("WhatwasThePriceofPurchase1");
			 * Q_PRODUCT_AND_PAYMENT_INFO_Wheeler4 = (String)
			 * FinancialInfoObj.get("4Wheeler");
			 * Q_PRODUCT_AND_PAYMENT_INFO_priceofpurchase2 = (String)
			 * FinancialInfoObj.get("WhatwasThePriceofPurchase2");
			 * 
			 * attributesXML = attributesXML + "<Q_FINANCIAL_INFORMATION>" +
			 * "<SOURCE_OF_FUNDS>" + Q_PRODUCT_AND_PAYMENT_INFO_Sourceoffunds +
			 * "</SOURCE_OF_FUNDS>" + "<OWN_VEHICLE>" +
			 * Q_PRODUCT_AND_PAYMENT_INFO_Doyouownavehicle + "</OWN_VEHICLE>" +
			 * "<Wheeler_2>" + Q_PRODUCT_AND_PAYMENT_INFO_Wheeler2 +
			 * "</Wheeler_2>" //+ "<priceofpurchase1>" +
			 * Q_PRODUCT_AND_PAYMENT_INFO_priceofpurchase1 +
			 * "</priceofpurchase1>" + "<Wheeler_4>" +
			 * Q_PRODUCT_AND_PAYMENT_INFO_Wheeler4 + "</Wheeler_4>" //+
			 * "<priceofpurchase2>" +
			 * Q_PRODUCT_AND_PAYMENT_INFO_priceofpurchase2 +
			 * "</priceofpurchase2>" + "</Q_FINANCIAL_INFORMATION>";
			 */

			String[] L_IncomeProofArr = L_IncomeProof.split(",");
			if (L_IncomeProofArr.length > 0 && !L_IncomeProof.equalsIgnoreCase("")) {
				for (int i = 0; i < L_IncomeProofArr.length; i++) {
					attributesXML = attributesXML
							// Q_LIST_INCOME_PROOF_PROP
							+ "<Q_LIST_INCOME_PROOF_PROP>" + L_IncomeProofArr[i] + "</Q_LIST_INCOME_PROOF_PROP>";
				}
			}

			// FundSelected
			JSONObject FundSelectedObj = (JSONObject) jsonParser
					.parse(ProductAndPaymentObj.getOrDefault("FundSelected", "{}").toString());

			Q_PRODUCT_AND_PAYMENT_INFO_Dynamicfundallocation = (String) FundSelectedObj.get("Dynamicfundallocation");
			Q_PRODUCT_AND_PAYMENT_INFO_Investerprofile = (String) FundSelectedObj.get("InvesterProfile");
			Q_PRODUCT_AND_PAYMENT_INFO_Systematictransferfund = (String) FundSelectedObj.get("SystematicTransferFund");
			Q_PRODUCT_AND_PAYMENT_INFO_FundName = (String) FundSelectedObj.get("FundName");
			Q_PRODUCT_AND_PAYMENT_INFO_Initialallocation = (String) FundSelectedObj.get("InitialAllocation");
			Q_PRODUCT_AND_PAYMENT_INFO_Totalfundallocation = (String) FundSelectedObj.get("TotalFundAllocation");

			String LIFECYCLE_FOLIO_STRATEGY, FUND1, FUND2;
			LIFECYCLE_FOLIO_STRATEGY = (String) FundSelectedObj.get("LifeStylePortfolioStrategy");
			FUND1 = (String) FundSelectedObj.get("Fund1");
			FUND2 = (String) FundSelectedObj.get("Fund2");
			String TriggerPortfolioStrategy, Trigger_Fund1, Trigger_Fund2,movementPercentage;
			TriggerPortfolioStrategy = (String) FundSelectedObj.get("TriggerPortfolioStrategy");
			Trigger_Fund1 = (String) FundSelectedObj.get("Trigger_Fund1");
			Trigger_Fund2 = (String) FundSelectedObj.get("Trigger_Fund2");
			movementPercentage=(String) FundSelectedObj.getOrDefault("MovementPercentage","");

			if (LIFECYCLE_FOLIO_STRATEGY.equals("N")) {
				FUND1 = "";
				FUND2 = "";
			}

			if (TriggerPortfolioStrategy.equals("N")) {
				Trigger_Fund1 = "";
				Trigger_Fund2 = "";
			}

			attributesXML = attributesXML + "<Q_FUND_SELECTED>" + "<DFA>"
					+ Q_PRODUCT_AND_PAYMENT_INFO_Dynamicfundallocation + "</DFA>" + "<INVESTER_PROFILE>"
					+ Q_PRODUCT_AND_PAYMENT_INFO_Investerprofile + "</INVESTER_PROFILE>" + "<STP>"
					+ Q_PRODUCT_AND_PAYMENT_INFO_Systematictransferfund + "</STP>"
					// + "<Fund_Name>" + Q_PRODUCT_AND_PAYMENT_INFO_FundName +
					// "</Fund_Name>"
					// + "<INITIAL_ALLOCATION>" +
					// Q_PRODUCT_AND_PAYMENT_INFO_Initialallocation +
					// "</INITIAL_ALLOCATION>"
					+ "<TOTAL_FUND_ALLOCATION>" + Q_PRODUCT_AND_PAYMENT_INFO_Totalfundallocation
					+ "</TOTAL_FUND_ALLOCATION>" + "<LIFECYCLE_FOLIO_STRATEGY>" + LIFECYCLE_FOLIO_STRATEGY
					+ "</LIFECYCLE_FOLIO_STRATEGY>" + "<FUND1>" + FUND1 + "</FUND1>" + "<FUND2>" + FUND2 + "</FUND2>"
					+ "<TRIGGER_PORTFOLIO_STRATEGY>" + TriggerPortfolioStrategy + "</TRIGGER_PORTFOLIO_STRATEGY>"
					+ "<TRIGGER_FUND1>" + Trigger_Fund1 + "</TRIGGER_FUND1>" + "<TRIGGER_FUND2>" + Trigger_Fund2
					+ "</TRIGGER_FUND2><MOVEMENT_PERCENTAGE>" +movementPercentage+ "</MOVEMENT_PERCENTAGE></Q_FUND_SELECTED>";
			// Funds Grid
			JSONArray FundsArray;
			FundsArray = (JSONArray) FundSelectedObj.get("FundsGrid");
			insertionOrderId = 0;
			hashID = 1;

			String gridArray = "";

			for (Object j : FundsArray) {
				JSONObject jsonObj = (JSONObject) j;

				gridArray = gridArray + "<Q_LIST_FUND_SELECTED_GRID>\r\n" + "<InsertionOrderId>" + insertionOrderId
						+ "</InsertionOrderId>\r\n" + "<HashId>" + hashID++ + "</HashId>\r\n" + "<FUND_NAME>"
						+ jsonObj.get("FundName").toString() + "</FUND_NAME>" + "<INITIAL_ALLOCATION>"
						+ jsonObj.get("InitialAllocation").toString() + "</INITIAL_ALLOCATION>\r\n" +
						// "<TOTAL_ALLOCATION_PERCENT>"+jsonObj.get("TotalFundAllocation").toString()+"</TOTAL_ALLOCATION_PERCENT>\r\n"
						// +
						"</Q_LIST_FUND_SELECTED_GRID>";
			}

			if (Q_PRODUCT_AND_PAYMENT_INFO_Systematictransferfund.equals("Y"))
				gridArray = "";

			attributesXML = attributesXML + gridArray;

			// NEFTDetails
			JSONObject NEFTDetailsObj = (JSONObject) jsonParser
					.parse(ProductAndPaymentObj.getOrDefault("NEFTDetails", "{}").toString());

			Payout_to_Account = (String) NEFTDetailsObj.get("IagreeforallPayouts");
			Q_PRODUCT_AND_PAYMENT_INFO_BankAccountNumber1 = (String) NEFTDetailsObj.get("BankAccountNumber1");
			Q_PRODUCT_AND_PAYMENT_INFO_AccountHoldername1 = (String) NEFTDetailsObj.get("AccountHoldername1");
			Q_PRODUCT_AND_PAYMENT_INFO_MICRCode1 = (String) NEFTDetailsObj.get("MICRCode1");
			Q_PRODUCT_AND_PAYMENT_INFO_IFSCCode1 = (String) NEFTDetailsObj.get("IFSCCode1");
			Q_PRODUCT_AND_PAYMENT_INFO_BankNameandBranch1 = (String) NEFTDetailsObj.get("BankNameandBranch1");
			Q_PRODUCT_AND_PAYMENT_INFO_TypeofBankAccount1 = (String) NEFTDetailsObj.get("TypeofBankAccount1");
			Q_PRODUCT_AND_PAYMENT_INFO_BankAccountNumber2 = (String) NEFTDetailsObj.get("BankAccountNumber2");
			Q_PRODUCT_AND_PAYMENT_INFO_AccountHoldername2 = (String) NEFTDetailsObj.get("AccountHolderName2");
			Q_PRODUCT_AND_PAYMENT_INFO_MICRCode2 = (String) NEFTDetailsObj.get("MICRCode2");
			Q_PRODUCT_AND_PAYMENT_INFO_IFSCCode2 = (String) NEFTDetailsObj.get("IFSCCode2");
			Q_PRODUCT_AND_PAYMENT_INFO_BankNameandBranch2 = (String) NEFTDetailsObj.get("BankNameandBranch2");
			Q_PRODUCT_AND_PAYMENT_INFO_TypeofBankAccount2 = (String) NEFTDetailsObj.get("TypeofBankAccount2");

			attributesXML = attributesXML + "<Q_NEFT_DETAILS>" + "<ACC_NO_NEFT>"
					+ Q_PRODUCT_AND_PAYMENT_INFO_BankAccountNumber1 + "</ACC_NO_NEFT>" + "<HOLDER_NAME_NEFT>"
					+ Q_PRODUCT_AND_PAYMENT_INFO_AccountHoldername1 + "</HOLDER_NAME_NEFT>" + "<MICR_NEFT>"
					+ Q_PRODUCT_AND_PAYMENT_INFO_MICRCode1 + "</MICR_NEFT>" + "<IFSC_NEFT>"
					+ Q_PRODUCT_AND_PAYMENT_INFO_IFSCCode1 + "</IFSC_NEFT>" + "<NAME_BRANCH_NEFT>"
					+ Q_PRODUCT_AND_PAYMENT_INFO_BankNameandBranch1 + "</NAME_BRANCH_NEFT>" + "<TYPE_OF_ACC_NEFT>"
					+ Q_PRODUCT_AND_PAYMENT_INFO_TypeofBankAccount1 + "</TYPE_OF_ACC_NEFT>" + "<ACC_NO_MWPA>"
					+ Q_PRODUCT_AND_PAYMENT_INFO_BankAccountNumber2 + "</ACC_NO_MWPA>" + "<HOLDER_NAME_MWPA>"
					+ Q_PRODUCT_AND_PAYMENT_INFO_AccountHoldername2 + "</HOLDER_NAME_MWPA>" + "<MICR_MWPA>"
					+ Q_PRODUCT_AND_PAYMENT_INFO_MICRCode2 + "</MICR_MWPA>" + "<IFSC_MWPA>"
					+ Q_PRODUCT_AND_PAYMENT_INFO_IFSCCode2 + "</IFSC_MWPA>" + "<NAME_BRANCH_MWPA>"
					+ Q_PRODUCT_AND_PAYMENT_INFO_BankNameandBranch2 + "</NAME_BRANCH_MWPA>" + "<TYPE_OF_ACC_MWPA>"
					+ Q_PRODUCT_AND_PAYMENT_INFO_TypeofBankAccount2 + "</TYPE_OF_ACC_MWPA>" + "<PAYOUTS_CREDITED>"
					+ Payout_to_Account + "</PAYOUTS_CREDITED>" + "</Q_NEFT_DETAILS>";
			// attributesXML = attributesXML
			// + "<PAYOUTS_CREDITED>" + Payout_to_Account +
			// "</PAYOUTS_CREDITED>";
			// PaymentDetails
			
			JSONObject NEFTDetailsAnnObj = (JSONObject) jsonParser
					.parse(ProductAndPaymentObj.getOrDefault("NEFTDetailsAnnuitant2", "{}").toString());

			Payout_to_Account_ANN = (String) NEFTDetailsAnnObj.getOrDefault("IagreeforallPayouts","");
			Q_PRODUCT_AND_PAYMENT_INFO_BankAccountNumber1_ANN = (String) NEFTDetailsAnnObj.getOrDefault("BankAccountNumber","");
			Q_PRODUCT_AND_PAYMENT_INFO_AccountHoldername1_ANN = (String) NEFTDetailsAnnObj.getOrDefault("AccountHoldername","");
			Q_PRODUCT_AND_PAYMENT_INFO_MICRCode1_ANN = (String) NEFTDetailsAnnObj.getOrDefault("MICRCode","");
			Q_PRODUCT_AND_PAYMENT_INFO_IFSCCode1_ANN = (String) NEFTDetailsAnnObj.getOrDefault("IFSCCode","");
			Q_PRODUCT_AND_PAYMENT_INFO_BankNameandBranch1_ANN = (String) NEFTDetailsAnnObj.getOrDefault("BankNameandBranch","");
			Q_PRODUCT_AND_PAYMENT_INFO_TypeofBankAccount1_ANN = (String) NEFTDetailsAnnObj.getOrDefault("TypeofBankAccount","");
	

			attributesXML = attributesXML + "<Q_NEFT_DETIALS_ANNUITANT>" + "<ACC_NO_NEFT>"
					+ Q_PRODUCT_AND_PAYMENT_INFO_BankAccountNumber1_ANN + "</ACC_NO_NEFT>" + "<HOLDER_NAME_NEFT>"
					+ Q_PRODUCT_AND_PAYMENT_INFO_AccountHoldername1_ANN + "</HOLDER_NAME_NEFT>" + "<MICR_NEFT>"
					+ Q_PRODUCT_AND_PAYMENT_INFO_MICRCode1_ANN + "</MICR_NEFT>" + "<IFSC_NEFT>"
					+ Q_PRODUCT_AND_PAYMENT_INFO_IFSCCode1_ANN + "</IFSC_NEFT>" + "<NAME_BRANCH_NEFT>"
					+ Q_PRODUCT_AND_PAYMENT_INFO_BankNameandBranch1_ANN + "</NAME_BRANCH_NEFT>" + "<TYPE_OF_ACC_NEFT>"
					+ Q_PRODUCT_AND_PAYMENT_INFO_TypeofBankAccount1_ANN + "</TYPE_OF_ACC_NEFT>"	+ "<PAYOUTS_CREDITED>"
					+ Payout_to_Account_ANN + "</PAYOUTS_CREDITED>" + "</Q_NEFT_DETIALS_ANNUITANT>";
			
			
			JSONArray mwpaNEFTDETAILS;
			mwpaNEFTDETAILS = (JSONArray) NEFTDetailsObj.getOrDefault("NEFTDetailsMWPA",new JSONArray());
			insertionOrderId = 0;
			hashID = 1;

			for (Object j : mwpaNEFTDETAILS) {
				JSONObject jsonObj = (JSONObject) j;

				attributesXML = attributesXML + "<Q_LIST_MWPA_NEFT_DETAILS>\r\n" + "<InsertionOrderId>" + insertionOrderId
						+ "</InsertionOrderId>\r\n" + "<HashId>" + hashID++ + "</HashId>\r\n" + "<BANK_ACC_NO>"
						+ jsonObj.getOrDefault("BankAccountNumber","").toString() + "</BANK_ACC_NO>" +  "<CLIENT_ID>"  //aacnhal
						+ jsonObj.getOrDefault("ClientId","").toString() + "</CLIENT_ID>" +"<ACCOUNT_HOLDER_NAME>"
						+ jsonObj.getOrDefault("AccountHolderName","").toString() + "</ACCOUNT_HOLDER_NAME>\r\n" + "<MICR_CODE>"
						+ jsonObj.getOrDefault("MICRCode","").toString() + "</MICR_CODE>\r\n" + "<IFSC_CODE>"
						+ jsonObj.getOrDefault("IFSCCode","").toString() + "</IFSC_CODE>\r\n" + "<BANK_NAME_BRANCH>"
						+ jsonObj.getOrDefault("BankNameandBranch","").toString() + "</BANK_NAME_BRANCH>\r\n" + "<TYPE_OF_ACC>"
						+ jsonObj.getOrDefault("TypeofBankAccount","").toString() + "</TYPE_OF_ACC>\r\n" + 
						// "<REQD_MODAL_PREMIUM>"+jsonObj.get("RequriedModalPremium").toString()+"</REQD_MODAL_PREMIUM>\r\n"
						// +
						// "<TOTAL_REQD_PREMIUM>"+jsonObj.get("TotalRequiredPremium").toString()+"</TOTAL_REQD_PREMIUM>\r\n"
						// +
						// "<AFYP>"+jsonObj.get("AFYP").toString()+"</AFYP>\r\n"
						// +
						"</Q_LIST_MWPA_NEFT_DETAILS>";
			}
			hashID = 1;

			String Q_PAYMENT_DETAILS_BANK_ACC_NO = "", Q_PAYMENT_DETAILS_MICR_CODE = "",
					Q_PAYMENT_DETAILS_IFSC_CODE = "", Q_PAYMENT_DETAILS_BANK_NAME = "",Q_PAYMENT_DETAILS_MONEY_RECEIVED_DATE=""; // EDC DR-15359 by mansi;

			JSONObject PaymentDetailsObj = (JSONObject) jsonParser
					.parse(ProductAndPaymentObj.getOrDefault("PaymentDetails", "{}").toString());

			Q_PRODUCT_AND_PAYMENT_INFO_InitialPremiumPaid = (String) PaymentDetailsObj.get("InitialPremiumPaid");
			Q_PRODUCT_AND_PAYMENT_INFO_InitialPremiumMethod = (String) PaymentDetailsObj.get("InitialPremiumMethod");
			// Q_PRODUCT_AND_PAYMENT_INFO_CashletterReceived = (String)
			// PaymentDetailsObj.get("CashletterReceived");
			Q_PAYMENT_DETAILS_BANK_ACC_NO = (String) PaymentDetailsObj.get("BankAccountNumber");
			Q_PAYMENT_DETAILS_MICR_CODE = (String) PaymentDetailsObj.get("MICRCode");
			Q_PAYMENT_DETAILS_IFSC_CODE = (String) PaymentDetailsObj.get("IFSCCode");
			Q_PAYMENT_DETAILS_BANK_NAME = (String) PaymentDetailsObj.get("BankNameAndBranch");
			Q_PAYMENT_DETAILS_MONEY_RECEIVED_DATE = (String) PaymentDetailsObj.get("MoneyReceivedDate"); // EDC DR-15359 by mansi

			attributesXML = attributesXML + "<Q_PAYMENT_DETAILS>" + "<INIT_PREM_PAID>"
					+ Q_PRODUCT_AND_PAYMENT_INFO_InitialPremiumPaid + "</INIT_PREM_PAID>" + "<INIT_PREM_METHOD>"
					+ Q_PRODUCT_AND_PAYMENT_INFO_InitialPremiumMethod + "</INIT_PREM_METHOD>"
					// + "<LETTER_RECEIVED>" +
					// Q_PRODUCT_AND_PAYMENT_INFO_CashletterReceived +
					// "</LETTER_RECEIVED>"
					+ "<BANK_ACC_NO>" + Q_PAYMENT_DETAILS_BANK_ACC_NO + "</BANK_ACC_NO>" + "<MICR_CODE>"
					+ Q_PAYMENT_DETAILS_MICR_CODE + "</MICR_CODE>" + "<IFSC_CODE>" + Q_PAYMENT_DETAILS_IFSC_CODE
					+ "</IFSC_CODE>" + "<BANK_NAME>" + Q_PAYMENT_DETAILS_BANK_NAME + "</BANK_NAME>"
					+"<MONEY_RECEIVED_DATE>"+Q_PAYMENT_DETAILS_MONEY_RECEIVED_DATE+"</MONEY_RECEIVED_DATE>" // EDC DR-15359 by mansi
					+"<UPI_TYPE>"+(String) PaymentDetailsObj.getOrDefault("UPI_TYPE","")+"</UPI_TYPE>" 		// DR-30627 mansi
					+"<UPI_ID_VPA>"+(String) PaymentDetailsObj.getOrDefault("UPI_ID_VPA","")+"</UPI_ID_VPA>" 	
					+"<UPI_ACCOUNT_HOLDER_NAME>"+(String) PaymentDetailsObj.getOrDefault("UPI_ID_ACCOUNT_HOLDER_NAME","")+"</UPI_ACCOUNT_HOLDER_NAME>" 	
					+ "</Q_PAYMENT_DETAILS>";
			// RenewalPremiumDetails
			JSONObject RenewalPremiumDetailsObj = (JSONObject) jsonParser
					.parse(ProductAndPaymentObj.getOrDefault("RenewalPremiumDetails", "{}").toString());

			/*
			 * String Q_RENEWAL_PREMIUM_DETAILS_CC_HOLDER_NAME =
			 * "",Q_RENEWAL_PREMIUM_DETAILS_CC_NO = "",
			 * Q_RENEWAL_PREMIUM_DETAILS_CC_EXPIRY_DATE = "",
			 * Q_RENEWAL_PREMIUM_DETAILS_CC_TYPE = "";
			 * 
			 * Q_PRODUCT_AND_PAYMENT_INFO_RenewalPremiumMethod = (String)
			 * RenewalPremiumDetailsObj.get("RenewalPremiumMethod");
			 * Q_RENEWAL_PREMIUM_DETAILS_CC_HOLDER_NAME = (String)
			 * RenewalPremiumDetailsObj.get("CCHolderName");
			 * Q_RENEWAL_PREMIUM_DETAILS_CC_NO = (String)
			 * RenewalPremiumDetailsObj.get("CreditCardNo");
			 * Q_RENEWAL_PREMIUM_DETAILS_CC_EXPIRY_DATE = (String)
			 * RenewalPremiumDetailsObj.get("CCExpiryDate");
			 * Q_RENEWAL_PREMIUM_DETAILS_CC_TYPE = (String)
			 * RenewalPremiumDetailsObj.get("CreditCardType");
			 */

			attributesXML = attributesXML + "<Q_RENEWAL_PREMIUM_DETAILS>" + "<RENEWAL_PREM_METHOD>"
					+ (String) RenewalPremiumDetailsObj.get("RenewalPremiumMethod") + "</RENEWAL_PREM_METHOD>"
					+ "<BANK_ACCOUNT_NUMBER>" + (String) RenewalPremiumDetailsObj.get("BankAccountNumber")
					+ "</BANK_ACCOUNT_NUMBER>" + "<ACCOUNT_HOLDER_NAME>"
					+ (String) RenewalPremiumDetailsObj.get("AccountHolderName") + "</ACCOUNT_HOLDER_NAME>"
					+ "<MICR_CODE>" + (String) RenewalPremiumDetailsObj.get("MICRCode") + "</MICR_CODE>" + "<IFSC_CODE>"
					+ (String) RenewalPremiumDetailsObj.get("IFSCCode") + "</IFSC_CODE>" + "<BANK_NAME_BRANCH>"
					+ (String) RenewalPremiumDetailsObj.get("BankNameAndBranch") + "</BANK_NAME_BRANCH>"
					+ "<TYPE_OF_ACCOUNT>" + (String) RenewalPremiumDetailsObj.get("BankAccountType")
					+ "</TYPE_OF_ACCOUNT>" + "<BILL_DRAW_DATE2>"
					+ (String) RenewalPremiumDetailsObj.get("BillDrawDate1") + "</BILL_DRAW_DATE2>" + "<COMPANY_NAME>"
					+ (String) RenewalPremiumDetailsObj.get("CompanyName") + "</COMPANY_NAME>" + "<BILL_DRAW_DATE1>"
					+ (String) RenewalPremiumDetailsObj.get("BillDrawDate2") + "</BILL_DRAW_DATE1>" + "<CC_HOLDER_NAME>"
					+ (String) RenewalPremiumDetailsObj.get("CCHolderName") + "</CC_HOLDER_NAME>" + "<CC_NO>"
					+ (String) RenewalPremiumDetailsObj.get("CreditCardNo") + "</CC_NO>" + "<CREDIT_CARD_EXPIRY_DATE>"
					+ (String) RenewalPremiumDetailsObj.get("CCExpiryDate") + "</CREDIT_CARD_EXPIRY_DATE>" + "<CC_TYPE>"
					+ (String) RenewalPremiumDetailsObj.get("CreditCardType") + "</CC_TYPE>"
					//DR-30627 mansi
					+ "<UPI_Type>"+ (String) RenewalPremiumDetailsObj.getOrDefault("UPI_Type","") + "</UPI_Type>"
					+ "<UPI_RegistrationDate>"+ (String) RenewalPremiumDetailsObj.getOrDefault("UPI_RegistrationDate","") + "</UPI_RegistrationDate>"
					+ "<UPI_RegisteredAmount>"+ (String) RenewalPremiumDetailsObj.getOrDefault("UPI_RegisteredAmount","") + "</UPI_RegisteredAmount>"
					+ "<UPI_TokenNumber>"+ (String) RenewalPremiumDetailsObj.getOrDefault("UPI_TokenNumber","") + "</UPI_TokenNumber>"
					+ "<UPI_GatewayName>"+ (String) RenewalPremiumDetailsObj.getOrDefault("UPI_GatewayName","") + "</UPI_GatewayName>"
					+ "<UPI_MandateID>"+ (String) RenewalPremiumDetailsObj.getOrDefault("UPI_MandateID","") + "</UPI_MandateID>"
					+ "<UPI_SubscriptionID>"+ (String) RenewalPremiumDetailsObj.getOrDefault("UPI_SubscriptionID","") + "</UPI_SubscriptionID>"
					+ "<UPI_RegistrationStatus>"+ (String) RenewalPremiumDetailsObj.getOrDefault("UPI_RegistrationStatus","") + "</UPI_RegistrationStatus>"
					+ "<UPI_RejectedReason>"+ (String) RenewalPremiumDetailsObj.getOrDefault("UPI_RejectedReason","") + "</UPI_RejectedReason>"
					+ "<UPI_ID_VPA>"+ (String) RenewalPremiumDetailsObj.getOrDefault("UPI_ID_VPA","") + "</UPI_ID_VPA>"
					+ "<UPI_ID_AccountHolderName>"+ (String) RenewalPremiumDetailsObj.getOrDefault("UPI_ID_AccountHolderName","") + "</UPI_ID_AccountHolderName>"
					+ "<UPI_NameMatchStatus>"+ (String) RenewalPremiumDetailsObj.getOrDefault("UPI_NameMatchStatus","") + "</UPI_NameMatchStatus>"
					+ "<UPI_NameMatchScore>"+ (String) RenewalPremiumDetailsObj.getOrDefault("UPI_NameMatchScore","") + "</UPI_NameMatchScore>"
					+ "<eNACH_RegisteredAmount>"+ (String) RenewalPremiumDetailsObj.getOrDefault("eNACH_RegisteredAmount","") + "</eNACH_RegisteredAmount>"
					+ "<eNACH_TokenNumber>"+ (String) RenewalPremiumDetailsObj.getOrDefault("eNACH_TokenNumber","") + "</eNACH_TokenNumber>"
					+ "<eNACH_GatewayName>"+ (String) RenewalPremiumDetailsObj.getOrDefault("eNACH_GatewayName","") + "</eNACH_GatewayName>"
					+ "<eNACH_AccountNumber>"+ (String) RenewalPremiumDetailsObj.getOrDefault("eNACH_AccountNumber","") + "</eNACH_AccountNumber>"
					+ "<eNACH_AccountHolderName>"+ (String) RenewalPremiumDetailsObj.getOrDefault("eNACH_AccountHolderName","") + "</eNACH_AccountHolderName>"
					+ "<eNACH_IFSC_Code>"+ (String) RenewalPremiumDetailsObj.getOrDefault("eNACH_IFSC_Code","") + "</eNACH_IFSC_Code>"
					+ "<eNACH_MICR_Code>"+ (String) RenewalPremiumDetailsObj.getOrDefault("eNACH_MICR_Code","") + "</eNACH_MICR_Code>"
					+ "<eNACH_AccountType>"+ (String) RenewalPremiumDetailsObj.getOrDefault("eNACH_AccountType","") + "</eNACH_AccountType>"
					+ "<eNACH_Frequency>"+ (String) RenewalPremiumDetailsObj.getOrDefault("eNACH_Frequency","") + "</eNACH_Frequency>"
					+ "<eNACH_UMRN>"+ (String) RenewalPremiumDetailsObj.getOrDefault("eNACH_UMRN","") + "</eNACH_UMRN>"
					+ "<eNACH_PayeeID>"+ (String) RenewalPremiumDetailsObj.getOrDefault("eNACH_PayeeID","") + "</eNACH_PayeeID>"
					+ "<eNACH_StartDate>"+ (String) RenewalPremiumDetailsObj.getOrDefault("eNACH_StartDate","") + "</eNACH_StartDate>"
					+ "<eNACH_EndDate>"+ (String) RenewalPremiumDetailsObj.getOrDefault("eNACH_EndDate","") + "</eNACH_EndDate>"
					+ "<eNACH_RegistrationStatus>"+ (String) RenewalPremiumDetailsObj.getOrDefault("eNACH_RegistrationStatus","") + "</eNACH_RegistrationStatus>"
					+ "<eNACH_RejectedReason>"+ (String) RenewalPremiumDetailsObj.getOrDefault("eNACH_RejectedReason","") + "</eNACH_RejectedReason>"
					+ "<eNACH_RegistrationDate>"+ (String) RenewalPremiumDetailsObj.getOrDefault("eNACH_RegistrationDate","") + "</eNACH_RegistrationDate>"
					+ "<eNACH_PresentmentMode>"+ (String) RenewalPremiumDetailsObj.getOrDefault("eNACH_PresentmentMode","") + "</eNACH_PresentmentMode>"
					+ "<CC_RegistrationDate>"+ (String) RenewalPremiumDetailsObj.getOrDefault("CC_RegistrationDate","") + "</CC_RegistrationDate>"
					+ "<CC_GatewayName>"+ (String) RenewalPremiumDetailsObj.getOrDefault("CC_GatewayName","") + "</CC_GatewayName>"
					+ "<CC_LastFourDigit>"+ (String) RenewalPremiumDetailsObj.getOrDefault("CC_LastFourDigit","") + "</CC_LastFourDigit>"
					+ "<CC_MandateID>"+ (String) RenewalPremiumDetailsObj.getOrDefault("CC_MandateID","") + "</CC_MandateID>"
					+ "<CC_AccountHolderName>"+ (String) RenewalPremiumDetailsObj.getOrDefault("CC_AccountHolderName","") + "</CC_AccountHolderName>"
					+ "<CC_SubscriptionID>"+ (String) RenewalPremiumDetailsObj.getOrDefault("CC_SubscriptionID","") + "</CC_SubscriptionID>"
					+ "<CC_MID>"+ (String) RenewalPremiumDetailsObj.getOrDefault("CC_MID","") + "</CC_MID>"
					+ "<CC_TokenID>"+ (String) RenewalPremiumDetailsObj.getOrDefault("CC_TokenID","") + "</CC_TokenID>"					
					+ "<UPI_DrawDay>"+ (String) RenewalPremiumDetailsObj.getOrDefault("UPI_DrawDay","") + "</UPI_DrawDay>"					
					+ "<UPI_ID>"+ (String) RenewalPremiumDetailsObj.getOrDefault("UPI_ID","") + "</UPI_ID>" // DR-47480 Nikita			
					+ "</Q_RENEWAL_PREMIUM_DETAILS>";

			// PayorPANDetails
			JSONObject PayorPANDetailsObj = (JSONObject) jsonParser
					.parse(ProductAndPaymentObj.getOrDefault("PayorPANDetails", "{}").toString());

			String Q_PAYOR_PAN_DETAILS_PAYOR_DIFF_PROP = "", Q_PAYOR_PAN_DETAILS_RELATIONSHIP = "",
					Q_PAYOR_PAN_DETAILS_BANK_ACC_NO = "", Q_PAYOR_PAN_DETAILS_BANK_NAME = "",
					Q_PAYOR_PAN_DETAILS_CLIENT_ID = "";

			Q_PAYOR_PAN_DETAILS_PAYOR_DIFF_PROP = (String) PayorPANDetailsObj.get("IsPayorDifferent");
			Q_PAYOR_PAN_DETAILS_RELATIONSHIP = (String) PayorPANDetailsObj.get("PayorProposerRelationship");
			Q_PAYOR_PAN_DETAILS_BANK_ACC_NO = (String) PayorPANDetailsObj.get("BankAccountNumber");
			Q_PAYOR_PAN_DETAILS_BANK_NAME = (String) PayorPANDetailsObj.get("BankNameAndBranch");
			Q_PAYOR_PAN_DETAILS_CLIENT_ID = (String) PayorPANDetailsObj.get("PayorClientId");
			Q_PRODUCT_AND_PAYMENT_INFO_PayorsFirstName = (String) PayorPANDetailsObj.get("PayorFirstName");
			Q_PRODUCT_AND_PAYMENT_INFO_Middle = (String) PayorPANDetailsObj.get("Middle");
			Q_PRODUCT_AND_PAYMENT_INFO_Last = (String) PayorPANDetailsObj.get("Last");
			Q_PRODUCT_AND_PAYMENT_INFO_Dateofbirth = (String) PayorPANDetailsObj.get("DateofBirth");
			Q_PRODUCT_AND_PAYMENT_INFO_Gender = (String) PayorPANDetailsObj.get("Gender");
			Q_PRODUCT_AND_PAYMENT_INFO_PayorsPanNumber = (String) PayorPANDetailsObj.get("PayorPanNumber");
			String PayorPANCardStatus = (String) PayorPANDetailsObj.getOrDefault("PayorPANCardStatus", "");
			Q_PRODUCT_AND_PAYMENT_INFO_DateofApplication = (String) PayorPANDetailsObj.get("DateofApplication");
			Q_PRODUCT_AND_PAYMENT_INFO_ApplicationAcknowledgementNumber = (String) PayorPANDetailsObj
					.get("AppAckNumber");
			String Q_PAYOR_PAN_DETAILS_TITLE = (String) PayorPANDetailsObj.get("PayorTitle");
			String Q_PAYOR_PAN_DETAILS_SPECIFY_TITLE = (String) PayorPANDetailsObj.get("SpecifyTitle");
			String Q_PAYOR_PAN_DETAILS_COMPANYNAME = (String) PayorPANDetailsObj.getOrDefault("CompanyName","");
			String Q_PAYOR_PAN_DETAILS_PAN = (String) PayorPANDetailsObj.getOrDefault("PANNumberCompany","");
			String Q_PAYOR_PAN_DETAILS_DOC = (String) PayorPANDetailsObj.getOrDefault("DateOfIncorporation","");
			String EXACT_INCOME_COMPANY = (String) PayorPANDetailsObj.getOrDefault("ExactIncomeCompany","");
			String MproDedupe = (String) PayorPANDetailsObj.getOrDefault("MproDedupe","");  //dr-17412 mansi
			
			// Q_PRODUCT_AND_PAYMENT_INFO_PayorClientId = (String)
			// PayorPANDetailsObj.get("PayorClientId");

			// +
			// "<PAYOR_CLIENT_ID>"+OtherTagsObj.get("PayorClientId").toString()+"</PAYOR_CLIENT_ID>"

			attributesXML = attributesXML + "<PAYOR_CLIENT_ID>" + PayorPANDetailsObj.get("PayorClientId").toString()
					+ "</PAYOR_CLIENT_ID>";

			attributesXML = attributesXML + "<Q_PAYOR_PAN_DETAILS>" + "<PAYOR_DIFF_PROP>"
					+ Q_PAYOR_PAN_DETAILS_PAYOR_DIFF_PROP + "</PAYOR_DIFF_PROP>" + "<RELATIONSHIP>"
					+ Q_PAYOR_PAN_DETAILS_RELATIONSHIP + "</RELATIONSHIP>" + "<BANK_ACC_NO>"
					+ Q_PAYOR_PAN_DETAILS_BANK_ACC_NO + "</BANK_ACC_NO>" + "<BANK_NAME>" + Q_PAYOR_PAN_DETAILS_BANK_NAME
					+ "</BANK_NAME>" + "<CLIENT_ID>" + Q_PAYOR_PAN_DETAILS_CLIENT_ID + "</CLIENT_ID>" + "<FIRST_NAME>"
					+ Q_PRODUCT_AND_PAYMENT_INFO_PayorsFirstName + "</FIRST_NAME>" + "<MIDDLE_NAME>"
					+ Q_PRODUCT_AND_PAYMENT_INFO_Middle + "</MIDDLE_NAME>" + "<LAST_NAME>"
					+ Q_PRODUCT_AND_PAYMENT_INFO_Last + "</LAST_NAME>" + "<DATE_OF_BIRTH>"
					+ Q_PRODUCT_AND_PAYMENT_INFO_Dateofbirth + "</DATE_OF_BIRTH>" + "<Gender>"
					+ Q_PRODUCT_AND_PAYMENT_INFO_Gender + "</Gender>" + "<PAN_NUMBER>"
					+ Q_PRODUCT_AND_PAYMENT_INFO_PayorsPanNumber + "</PAN_NUMBER>" + "<DATE_OF_APPLICATION>"
					+ Q_PRODUCT_AND_PAYMENT_INFO_DateofApplication + "</DATE_OF_APPLICATION>" + "<APP_ACK_NO>"
					+ Q_PRODUCT_AND_PAYMENT_INFO_ApplicationAcknowledgementNumber + "</APP_ACK_NO>"
					+ "<APPLIED_FOR_PAN>" + PayorPANCardStatus + "</APPLIED_FOR_PAN>" + "<TITLE>"
					+ Q_PAYOR_PAN_DETAILS_TITLE + "</TITLE>" + "<SPECIFY_TITLE>" + Q_PAYOR_PAN_DETAILS_SPECIFY_TITLE
					+ "</SPECIFY_TITLE>"
					+ "<NAME_COMPANY>" + Q_PAYOR_PAN_DETAILS_COMPANYNAME
					+ "</NAME_COMPANY>"
					+ "<DATE_OF_INCOR>" + Q_PAYOR_PAN_DETAILS_DOC
					+ "</DATE_OF_INCOR>"
					+ "<PAN_NUMBER_COMPANY>" + Q_PAYOR_PAN_DETAILS_PAN
					+ "</PAN_NUMBER_COMPANY>"
					+ "<EXACT_INCOME_COMPANY>" + EXACT_INCOME_COMPANY
					+ "</EXACT_INCOME_COMPANY>"
					+ "<MPROLCIENTID>" + Q_PAYOR_PAN_DETAILS_CLIENT_ID
					+ "</MPROLCIENTID>"
					+ "<MproDedupe>" + MproDedupe + "</MproDedupe>"  	//dr-17412 mansi
					// + "<CLIENT_ID>" +
					// Q_PRODUCT_AND_PAYMENT_INFO_PayorClientId + "</CLIENT_ID>"
					+ "</Q_PAYOR_PAN_DETAILS>";
			/*
			 * attributesXML = attributesXML + "<AppliedFor>" + AppliedFor +
			 * "</AppliedFor>";
			 */

			// Medical&PreviousPolicyinformation
			JSONObject MedicalPrevPolInfoObj = (JSONObject) jsonParser
					.parse(json.getOrDefault("MedicalAndPreviousPolicyinformation", "{}").toString());

			// FamilyInformation
			JSONObject FamilyInformationObj = null;
			if (MedicalPrevPolInfoObj.containsKey("FamilyInformation")) {
				FamilyInformationObj = (JSONObject) jsonParser
						.parse(MedicalPrevPolInfoObj.getOrDefault("FamilyInformation","{}").toString());

				attributesXML = attributesXML + "<Q_FAMILY_INFORMATION>\r\n" + "<DIAGNOSED_WITH>"
						+ (String) FamilyInformationObj.get("HasDiagnosed") + "</DIAGNOSED_WITH>\r\n"
						+ "</Q_FAMILY_INFORMATION>";

			}
			// FemaleInformation
			JSONObject FemaleInformationObj = (JSONObject) jsonParser
					.parse(MedicalPrevPolInfoObj.getOrDefault("FemaleInformation", "{}").toString());

			attributesXML = attributesXML + "<Q_FEMALE_INFORMATION>\r\n" + "<ARE_YOU_PREGNANT>"
					+ (String) FemaleInformationObj.get("IsPregnant") + "</ARE_YOU_PREGNANT>\r\n" + "<HOW_MANY_MONTHS>"
					+ (String) FemaleInformationObj.get("HowManyMonths") + "</HOW_MANY_MONTHS>\r\n"
					+ "<PREGNANCY_COMPLICATIONS>" + (String) FemaleInformationObj.get("IsComplications")
					+ "</PREGNANCY_COMPLICATIONS>\r\n" + "<PREGNANCY_COMPLICATIONS_DETAILS>"
					+ (String) FemaleInformationObj.get("GiveDetails") + "</PREGNANCY_COMPLICATIONS_DETAILS>\r\n"
					+ "<SPOUCE_OCCUPATION>" + (String) FemaleInformationObj.get("SpouceOccupation")
					+ "</SPOUCE_OCCUPATION>\r\n" + "<SPOUCE_INCOME>" + (String) FemaleInformationObj.get("SpouceIncome")
					+ "</SPOUCE_INCOME>\r\n" + "<SPOUCE_INSURANCE_AMOUNT>"
					+ (String) FemaleInformationObj.get("SpouceInsuranceAmt") + "</SPOUCE_INSURANCE_AMOUNT>\r\n"
					+ "</Q_FEMALE_INFORMATION>";
			
			
			///PROP
			JSONObject PROP_FEMALE = (JSONObject) jsonParser
					.parse(FemaleInformationObj.getOrDefault("ProposerDetails", "{}").toString());
			attributesXML = attributesXML + "<Q_FEMALE_INFORMATION_PROP>\r\n" + "<ARE_YOU_PREGNANT>"
					+ (String) PROP_FEMALE.get("IsPregnant") + "</ARE_YOU_PREGNANT>\r\n" + "<HOW_MANY_MONTHS>"
					+ (String) PROP_FEMALE.get("HowManyMonths") + "</HOW_MANY_MONTHS>\r\n"
					+ "<PREGNANCY_COMPLICATIONS>" + (String) PROP_FEMALE.get("IsComplications")
					+ "</PREGNANCY_COMPLICATIONS>\r\n" + "<PREGNANCY_COMPLICATIONS_DETAILS>"
					+ (String) PROP_FEMALE.get("GiveDetails") + "</PREGNANCY_COMPLICATIONS_DETAILS>\r\n"
					+ "<SPOUCE_OCCUPATION>" + (String) PROP_FEMALE.get("SpouceOccupation")
					+ "</SPOUCE_OCCUPATION>\r\n" + "<SPOUCE_INCOME>" + (String) PROP_FEMALE.get("SpouceIncome")
					+ "</SPOUCE_INCOME>\r\n" + "<SPOUCE_INSURANCE_AMOUNT>"
					+ (String) PROP_FEMALE.get("SpouceInsuranceAmt") + "</SPOUCE_INSURANCE_AMOUNT>\r\n"
					+ "</Q_FEMALE_INFORMATION_PROP>";
			//PROP
			///INSUR
			JSONObject PROP_l2BI = (JSONObject) jsonParser
					.parse(FemaleInformationObj.getOrDefault("L2BIDetails", "{}").toString());
			attributesXML = attributesXML + "<Q_FEMALE_INFORMATION_INSUR>\r\n" + "<ARE_YOU_PREGNANT>"
					+ (String) PROP_l2BI.get("IsPregnant") + "</ARE_YOU_PREGNANT>\r\n" + "<HOW_MANY_MONTHS>"
					+ (String) PROP_l2BI.get("HowManyMonths") + "</HOW_MANY_MONTHS>\r\n"
					+ "<PREGNANCY_COMPLICATIONS>" + (String) PROP_l2BI.get("IsComplications")
					+ "</PREGNANCY_COMPLICATIONS>\r\n" + "<PREGNANCY_COMPLICATIONS_DETAILS>"
					+ (String) PROP_l2BI.get("GiveDetails") + "</PREGNANCY_COMPLICATIONS_DETAILS>\r\n"
					+ "<SPOUCE_OCCUPATION>" + (String) PROP_l2BI.get("SpouceOccupation")
					+ "</SPOUCE_OCCUPATION>\r\n" + "<SPOUCE_INCOME>" + (String) PROP_l2BI.get("SpouceIncome")
					+ "</SPOUCE_INCOME>\r\n" + "<SPOUCE_INSURANCE_AMOUNT>"
					+ (String) PROP_l2BI.get("SpouceInsuranceAmt") + "</SPOUCE_INSURANCE_AMOUNT>\r\n"
					+ "</Q_FEMALE_INFORMATION_INSUR>";
			//INSUR
			// Habit Information
			JSONObject HabitInformationObj = (JSONObject) jsonParser
					.parse(MedicalPrevPolInfoObj.getOrDefault("HabitInformation", "{}").toString());
			attributesXML = attributesXML + "<Q_HABIT_QUESTIONS>\r\n" + "<TOBACCO_PROP>"
					+ (String) HabitInformationObj.get("TobaccoProp") + "</TOBACCO_PROP>\r\n" + "<TOBACCO_INSUR>"
					+ (String) HabitInformationObj.get("TobaccoInsur") + "</TOBACCO_INSUR>\r\n" + "<SMOKING_PROP>"
					+ (String) HabitInformationObj.get("SmokingProp") + "</SMOKING_PROP>\r\n" + "<SMOKING_INSUR>"
					+ (String) HabitInformationObj.get("SmokingInsur") + "</SMOKING_INSUR>\r\n" + "<ALCOHOL_PROP>"
					+ (String) HabitInformationObj.get("AlcoholProp") + "</ALCOHOL_PROP>\r\n" + "<ALCOHOL_INSUR>"
					+ (String) HabitInformationObj.get("AlcoholInsur") + "</ALCOHOL_INSUR>\r\n" + "<LIQUOR_PROP>"
					+ (String) HabitInformationObj.get("LiquorProp") + "</LIQUOR_PROP>\r\n" + "<LIQUOR_INSUR>"
					+ (String) HabitInformationObj.get("LiquorInsur") + "</LIQUOR_INSUR>\r\n" + "<QUIT_ALCOHOL_PROP>"
					+ (String) HabitInformationObj.get("QuitAlcoholProp") + "</QUIT_ALCOHOL_PROP>\r\n"
					+ "<QUIT_ALCOHOL_INSUR>" + (String) HabitInformationObj.get("QuitAlcoholInsur")
					+ "</QUIT_ALCOHOL_INSUR>\r\n" + "<DRUGS_PROP>" + (String) HabitInformationObj.get("DrugsProp")
					+ "</DRUGS_PROP>\r\n" + "<DRUGS_INSUR>" + (String) HabitInformationObj.get("DrugsInsur")
					+ "</DRUGS_INSUR>\r\n" + "<DRUGS_DETAILS_PROP>"
					+ (String) HabitInformationObj.get("DrugsDetailsProp") + "</DRUGS_DETAILS_PROP>\r\n"
					+ "<DRUGS_DETAILS_INSUR>" + (String) HabitInformationObj.get("DrugsDetailsInsur")
					+ "</DRUGS_DETAILS_INSUR>\r\n" 
					
					+ "<TOBACCO_PROP_POS>" + (String) HabitInformationObj.get("TobaccoPropPOS")
					+ "</TOBACCO_PROP_POS>\r\n" 
					+ "<TOBACCO_INSUR_POS>" + (String) HabitInformationObj.get("TobaccoInsurPOS")
					+ "</TOBACCO_INSUR_POS>\r\n" 
					+ "<DRUGS_PROP_POS>" + (String) HabitInformationObj.get("DrugsPropPOS")
					+ "</DRUGS_PROP_POS>\r\n" 
					+ "<DRUGS_INSUR_POS>" + (String) HabitInformationObj.get("DrugsInsurPOS")
					+ "</DRUGS_INSUR_POS>\r\n" 
					+ "<ALCOHOL_PROP_POS>" + (String) HabitInformationObj.get("AlcoholPropPOS")
					+ "</ALCOHOL_PROP_POS>\r\n" 
					+ "<ALCOHOL_INSUR_POS>" + (String) HabitInformationObj.get("AlcoholInsurPOS")
					+ "</ALCOHOL_INSUR_POS>\r\n" 
					+ "<TOBACCO_PROP_SELECT_POS>" + (String) HabitInformationObj.get("TobaccoPropPOSSelect")
					+ "</TOBACCO_PROP_SELECT_POS>\r\n" 
					+ "<TOBACCO_INSUR_SELECT_POS>" + (String) HabitInformationObj.get("TobaccoInsurPOSSelect")
					+ "</TOBACCO_INSUR_SELECT_POS>\r\n" 
					+ "<TOBACCO_PROP_QUANTITY_POS>" + (String) HabitInformationObj.get("TobaccoPropPOSQuantity")
					+ "</TOBACCO_PROP_QUANTITY_POS>\r\n" 
					+ "<TOBACCO_INSUR_QUANTITY_POS>" + (String) HabitInformationObj.get("TobaccoInsurPOSQuantity")
					+ "</TOBACCO_INSUR_QUANTITY_POS>\r\n" 
					+ "<TOBACCO_PROP_NOYEAR_POS>" + (String) HabitInformationObj.get("TobaccoPropPOSYear")
					+ "</TOBACCO_PROP_NOYEAR_POS>\r\n" 
					+ "<TOBACCO_INSUR_NOYEAR_POS>" + (String) HabitInformationObj.get("TobaccoInsurPOSYear")
					+ "</TOBACCO_INSUR_NOYEAR_POS>\r\n" 
					+ "<ALCOHOL_PROP_SELECT_POS>" + (String) HabitInformationObj.get("AlcoholPropPOSSelect")
					+ "</ALCOHOL_PROP_SELECT_POS>\r\n" 
					+ "<ALCOHOL_INSUR_SELECT_POS>" + (String) HabitInformationObj.get("AlcoholInsurPOSSelect")
					+ "</ALCOHOL_INSUR_SELECT_POS>\r\n" 
					
					+ "<ALCOHOL_PROP_QUANTITY_POS>" + (String) HabitInformationObj.get("AlcoholPropPOSQuantity")
					+ "</ALCOHOL_PROP_QUANTITY_POS>\r\n" 
					+ "<ALCOHOL_INSUR_QUANTITY_POS>" + (String) HabitInformationObj.get("AlcoholInsurPOSQuantity")
					+ "</ALCOHOL_INSUR_QUANTITY_POS>\r\n" 
					+ "<ALCOHOL_PROP_NOYEAR_POS>" + (String) HabitInformationObj.get("AlcoholPropPOSYear")
					+ "</ALCOHOL_PROP_NOYEAR_POS>\r\n" 
					+ "<ALCOHOL_INSUR_NOYEAR_POS>" + (String) HabitInformationObj.get("AlcoholInsurPOSYear")
					+ "</ALCOHOL_INSUR_NOYEAR_POS>\r\n" 
					//NEALTH
					+ "<TOBACCO_INSUR_FREQ_POS>" + (String) HabitInformationObj.get("TobaccoInsurPOSFrequency")
					+ "</TOBACCO_INSUR_FREQ_POS>\r\n" 
					+ "<TOBACCO_PROP_FREQ_POS>" + (String) HabitInformationObj.get("TobaccoPropPOSFrequency")
					+ "</TOBACCO_PROP_FREQ_POS>\r\n" 
					+ "<ALCOHOL_PROP_FREQ_POS>" + (String) HabitInformationObj.get("AlcoholPropPOSFrequency")
					+ "</ALCOHOL_PROP_FREQ_POS>\r\n" 
					+ "<ALCOHOL_INSUR_FREQ_POS>" + (String) HabitInformationObj.get("AlcoholInsurPOSFrequency")
					+ "</ALCOHOL_INSUR_FREQ_POS>\r\n" 
					// dr-24067 mansi
					+ "<CONSUMPTION_PROP>" +  HabitInformationObj.getOrDefault("ConsumptionProp","").toString()
					+ "</CONSUMPTION_PROP>\r\n"
					+ "<CONSUMPTION_INSUR>" + HabitInformationObj.getOrDefault("ConsumptionInsur","").toString()
					+ "</CONSUMPTION_INSUR>\r\n"
					
					+ "<SMOKING_CONSUMPTION_PROP>" + HabitInformationObj.getOrDefault("SmokingConsumptionProp","").toString()
					+ "</SMOKING_CONSUMPTION_PROP>\r\n"
					+ "<SMOKING_CONSUMPTION_INSUR>" + HabitInformationObj.getOrDefault("SmokingConsumptionInsur","").toString()
					+ "</SMOKING_CONSUMPTION_INSUR>\r\n"
					+ "<SMOKING_QUANTITY_PROP>" + HabitInformationObj.getOrDefault("SmokingQuantityProp","").toString()
					+ "</SMOKING_QUANTITY_PROP>\r\n"
					+ "<SMOKING_QUANTITY_INSUR>" + HabitInformationObj.getOrDefault("SmokingQuantityInsur","").toString()
					+ "</SMOKING_QUANTITY_INSUR>\r\n"
					+ "<SMOKING_FREQUENCY_PROP>" + HabitInformationObj.getOrDefault("SmokingFreqProp","").toString()
					+ "</SMOKING_FREQUENCY_PROP>\r\n"
					+ "<SMOKING_FREQUENCY_INSUR>" + HabitInformationObj.getOrDefault("SmokingFreqInsur","").toString()
					+ "</SMOKING_FREQUENCY_INSUR>\r\n"
					
					+ "<TOBACCO_CONSUMPTION_PROP>" + HabitInformationObj.getOrDefault("TobaccoConsumptionProp","").toString()
					+ "</TOBACCO_CONSUMPTION_PROP>\r\n"
					+ "<TOBACCO_CONSUMPTION_INSUR>" + HabitInformationObj.getOrDefault("TobaccoConsumptionInsur","").toString()
					+ "</TOBACCO_CONSUMPTION_INSUR>\r\n"
					+ "<TOBACCO_QUANTITY_PROP>" + HabitInformationObj.getOrDefault("TobaccoQuantityProp","").toString()
					+ "</TOBACCO_QUANTITY_PROP>\r\n"
					+ "<TOBACCO_QUANTITY_INSUR>" + HabitInformationObj.getOrDefault("TobaccoQuantityInsur","").toString()
					+ "</TOBACCO_QUANTITY_INSUR>\r\n"
					+ "<TOBACCO_FREQUENCY_PROP>" + HabitInformationObj.getOrDefault("TobaccoFreqProp","").toString()
					+ "</TOBACCO_FREQUENCY_PROP>\r\n"
					+ "<TOBACCO_FREQUENCY_INSUR>" + HabitInformationObj.getOrDefault("TobaccoFreqInsur","").toString()
					+ "</TOBACCO_FREQUENCY_INSUR>\r\n"
					
					+ "<ALCOHOL_CONSUMPTION_PROP>" + HabitInformationObj.getOrDefault("AlcoholConsumptionProp","").toString()
					+ "</ALCOHOL_CONSUMPTION_PROP>\r\n"
					+ "<ALCOHOL_CONSUMPTION_INSUR>" + HabitInformationObj.getOrDefault("AlcoholConsumptionInsur","").toString()
					+ "</ALCOHOL_CONSUMPTION_INSUR>\r\n"
					
					+ "</Q_HABIT_QUESTIONS>";
			//dr-24067
			JSONArray AlcoholConsumptionProp;
			AlcoholConsumptionProp = (JSONArray) HabitInformationObj.getOrDefault("AlcoholConsumeProp",new JSONArray());
			insertionOrderId = 0;
			hashID = 1;

			for (Object j : AlcoholConsumptionProp) {
				JSONObject jsonObj = (JSONObject) j;
				attributesXML = attributesXML + "<Q_ALCOHOL_CONSUMPTION_PROP>\r\n" + "<InsertionOrderId>" + insertionOrderId
						+ "</InsertionOrderId>\r\n" + "<HashId>" + hashID++ + "</HashId>\r\n" 
						+ "<ALCOHOL_TYPE>" + (String) jsonObj.getOrDefault("AlcoholTypeProp","").toString()+ "</ALCOHOL_TYPE>\r\n"
						+ "<ALCOHOL_QUANTITY>"+ jsonObj.getOrDefault("AlcoholQuantityProp","").toString() + "</ALCOHOL_QUANTITY>\r\n" 
						+ "<ALCOHOL_FREQUENCY>"+ jsonObj.getOrDefault("AlcoholFreqProp","").toString() + "</ALCOHOL_FREQUENCY>\r\n" 
						+ "</Q_ALCOHOL_CONSUMPTION_PROP>";
			}
			JSONArray AlcoholConsumptionInsur;
			AlcoholConsumptionInsur = (JSONArray) HabitInformationObj.getOrDefault("AlcoholConsumeInsur",new JSONArray());
			insertionOrderId = 0;
			hashID = 1;

			for (Object j : AlcoholConsumptionInsur) {
				JSONObject jsonObj = (JSONObject) j;
				attributesXML = attributesXML + "<Q_ALCOHOL_CONSUMPTION_INSUR>\r\n" + "<InsertionOrderId>" + insertionOrderId
						+ "</InsertionOrderId>\r\n" + "<HashId>" + hashID++ + "</HashId>\r\n" 
						+ "<ALCOHOL_TYPE>" + (String) jsonObj.getOrDefault("AlcoholTypeInsur","").toString()+ "</ALCOHOL_TYPE>\r\n"
						+ "<ALCOHOL_QUANTITY>"+ jsonObj.getOrDefault("AlcoholQuantityInsur","").toString() + "</ALCOHOL_QUANTITY>\r\n" 
						+ "<ALCOHOL_FREQUENCY>"+ jsonObj.getOrDefault("AlcoholFreqInsur","").toString() + "</ALCOHOL_FREQUENCY>\r\n" 
						+ "</Q_ALCOHOL_CONSUMPTION_INSUR>";
			}
			
			// MedicalInformationProp
			JSONObject MedInfoProposer = (JSONObject) jsonParser
					.parse(MedicalPrevPolInfoObj.getOrDefault("MedicalInformationProp", "{}").toString());

			attributesXML = attributesXML + "<Q_MED_INFO_PROP>" + "<DIABETES>"
					+ (String) MedInfoProposer.get("Diabetes") + "</DIABETES>" + "<MANAGING_DIABETES>"
					+ (String) MedInfoProposer.get("ManagingDiabetes") + "</MANAGING_DIABETES>" + "<DIABETIC_FOR>"
					+ (String) MedInfoProposer.get("DiabeticFor") + "</DIABETIC_FOR>" + "<DIABETES_COMPLICATIONS>"
					+ (String) MedInfoProposer.get("DiabetesComplications") + "</DIABETES_COMPLICATIONS>"
					+ "<DIABETES_OTHER_DETAILS>" + (String) MedInfoProposer.get("DiabetesOtherDetails")
					+ "</DIABETES_OTHER_DETAILS>" + "<HYPERTENSION_BP>" + (String) MedInfoProposer.get("HypertensionBp")
					+ "</HYPERTENSION_BP>" + "<BP_UNDER_CONTROL>" + (String) MedInfoProposer.get("BpUnderControl")
					+ "</BP_UNDER_CONTROL>" + "<CHOLESTEROL_UNDER_CONTROL>"
					+ (String) MedInfoProposer.get("CholesterolUnderControl") + "</CHOLESTEROL_UNDER_CONTROL>"
					+ "<THYROID_UNDER_CONTROL>" + (String) MedInfoProposer.get("ThyroidUnderControl")
					+ "</THYROID_UNDER_CONTROL>" + "<BP_CHOLESTEROL_DETAILS>"
					+ (String) MedInfoProposer.get("BpCholesterolDetails") + "</BP_CHOLESTEROL_DETAILS>"
					+ "<HEART_DISORDER>" + (String) MedInfoProposer.get("HeartDisorder") + "</HEART_DISORDER>"
					+ "<HISTORY_OF_CHEST_PAIN>" + (String) MedInfoProposer.get("HistoryOfChestPain")
					+ "</HISTORY_OF_CHEST_PAIN>" + "<CHEST_PAIN_OTHER_DETAILS>"
					+ (String) MedInfoProposer.get("ChestPainOtherDetails") + "</CHEST_PAIN_OTHER_DETAILS>"
					+ "<LUNG_DISORDERS>" + (String) MedInfoProposer.get("LungDisorders") + "</LUNG_DISORDERS>"
					+ "<HISTORY_OF_TUBERCULOSIS>" + (String) MedInfoProposer.get("HistoryOfTuberculosis")
					+ "</HISTORY_OF_TUBERCULOSIS>" + "<ALLERGIC_BRONCHITIS>"
					+ (String) MedInfoProposer.get("AllergicBronchitis") + "</ALLERGIC_BRONCHITIS>"
					+ "<HISTORY_OF_ASTHMA>" + (String) MedInfoProposer.get("HistoryOfAsthma") + "</HISTORY_OF_ASTHMA>"
					+ "<LUNG_DISORDERS_DETAILS>" + (String) MedInfoProposer.get("LungDisordersDetails")
					+ "</LUNG_DISORDERS_DETAILS>" + "<LIVER_RELATED_DISORDER>"
					+ (String) MedInfoProposer.get("LiverRelatedDisorder") + "</LIVER_RELATED_DISORDER>"
					+ "<HISTORY_OF_JAUNDICE>" + (String) MedInfoProposer.get("HistoryOfJaundice")
					+ "</HISTORY_OF_JAUNDICE>" + "<INDIGESTION_CONSTIPATION>"
					+ (String) MedInfoProposer.get("IndigestionConstipation") + "</INDIGESTION_CONSTIPATION>"
					+ "<HISTORY_OF_GALL_BLADDER>" + (String) MedInfoProposer.get("HistoryOfGallBladder")
					+ "</HISTORY_OF_GALL_BLADDER>" + "<HISTORY_OF_STONES>"
					+ (String) MedInfoProposer.get("HistoryOfStones") + "</HISTORY_OF_STONES>" + "<LIVER_OTHER_DETAILS>"
					+ (String) MedInfoProposer.get("LiverOtherDetails") + "</LIVER_OTHER_DETAILS>"
					+ "<ABNORMAL_GROWTH_OR_STD>" + (String) MedInfoProposer.get("AbnormalGrowthOrStd")
					+ "</ABNORMAL_GROWTH_OR_STD>" + "<HISTORY_OF_IRON_DEFICIENCY>"
					+ (String) MedInfoProposer.get("HistoryOfIronDeficiency") + "</HISTORY_OF_IRON_DEFICIENCY>"
					+ "<HISTORY_OF_LIPOMA>" + (String) MedInfoProposer.get("HistoryOfLipoma") + "</HISTORY_OF_LIPOMA>"
					+ "<ABNORMAL_GROWTH_OTHER_DETAILS>" + (String) MedInfoProposer.get("AbnormalGrowthOtherDetails")
					+ "</ABNORMAL_GROWTH_OTHER_DETAILS>" + "<KIDNEY_DISORDER>"
					+ (String) MedInfoProposer.get("KidneyDisorder") + "</KIDNEY_DISORDER>" + "<HISTORY_OF_UTI>"
					+ (String) MedInfoProposer.get("HistoryOfUti") + "</HISTORY_OF_UTI>" + "<HISTORY_OF_KIDNEY_SURGERY>"
					+ (String) MedInfoProposer.get("HistoryOfKidneySurgery") + "</HISTORY_OF_KIDNEY_SURGERY>"
					+ "<HISTORY_OF_STONE>" + (String) MedInfoProposer.get("HistoryOfStone") + "</HISTORY_OF_STONE>"
					+ "<KIDNEY_OTHER_DETAILS>" + (String) MedInfoProposer.get("KidneyOtherDetails")
					+ "</KIDNEY_OTHER_DETAILS>" + "<NEUROLOGICAL_PROBLEM>"
					+ (String) MedInfoProposer.get("NeurologicalProblem") + "</NEUROLOGICAL_PROBLEM>"
					+ "<NEUROLOGICAL_DETAILS>" + (String) MedInfoProposer.get("NeurologicalDetails")
					+ "</NEUROLOGICAL_DETAILS>" + "<MUSCULAR_JOINT_DISORDERS>"
					+ (String) MedInfoProposer.get("MuscularJointDisorders") + "</MUSCULAR_JOINT_DISORDERS>"
					+ "<BACK_PAIN_SLIP_DISC>" + (String) MedInfoProposer.get("BackPainSlipDisc")
					+ "</BACK_PAIN_SLIP_DISC>" + "<SUGGESTED_PHYSIOTHERAPY>"
					+ (String) MedInfoProposer.get("SuggestedPhysiotherapy") + "</SUGGESTED_PHYSIOTHERAPY>"
					+ "<HISTORY_OF_HAIRLINE_FRACTURE>" + (String) MedInfoProposer.get("HistoryOfHairlineFracture")
					+ "</HISTORY_OF_HAIRLINE_FRACTURE>" + "<HISTORY_OF_OSTEOARTHRITIS>"
					+ (String) MedInfoProposer.get("HistoryOfOsteoarthritis") + "</HISTORY_OF_OSTEOARTHRITIS>"
					+ "<HISTORY_OF_ANY_FRACTURE>" + (String) MedInfoProposer.get("HistoryOfAnyFracture")
					+ "</HISTORY_OF_ANY_FRACTURE>" + "<MUSCULAR_JOINT_DETAILS>"
					+ (String) MedInfoProposer.get("MuscularJointDetails") + "</MUSCULAR_JOINT_DETAILS>"
					+ "<HISTORY_OF_HOSPITALIZATION>" + (String) MedInfoProposer.get("HistoryOfHospitalization")
					+ "</HISTORY_OF_HOSPITALIZATION>" + "<HOSPITALIZATION_FOR_FEVER>"
					+ (String) MedInfoProposer.get("HospitalizationForFever") + "</HOSPITALIZATION_FOR_FEVER>"
					+ "<HOSPITALIZATION_OF_POISONING>" + (String) MedInfoProposer.get("HospitalizationOfPoisoning")
					+ "</HOSPITALIZATION_OF_POISONING>" + "<HOSPITALIZATION_FOR_ACCIDENT>"
					+ (String) MedInfoProposer.get("HospitalizationForAccident") + "</HOSPITALIZATION_FOR_ACCIDENT>"
					+ "<HOSPITALIZED_FOR_CSECTION>" + (String) MedInfoProposer.get("HospitalizedForCsection")
					+ "</HOSPITALIZED_FOR_CSECTION>" + "<HOSPITALIZED_FOR_MALARIA>"
					+ (String) MedInfoProposer.get("HospitalizedForMalaria") + "</HOSPITALIZED_FOR_MALARIA>"
					+ "<HISTORY_OF_COLD>" + (String) MedInfoProposer.get("HistoryOfCold") + "</HISTORY_OF_COLD>"
					+ "<HOSPITALIZATION_OTHER_DETAILS>" + (String) MedInfoProposer.get("HospitalizationOtherDetails")
					+ "</HOSPITALIZATION_OTHER_DETAILS>" + "<ADVISED_TESTS_XRAY_SURGERY>"
					+ (String) MedInfoProposer.get("AdvisedTestsXraySurgery") + "</ADVISED_TESTS_XRAY_SURGERY>"
					+ "<HISTORY_OF_ACCIDENT_SURGERY>" + (String) MedInfoProposer.get("HistoryOfAccidentSurgery")
					+ "</HISTORY_OF_ACCIDENT_SURGERY>" + "<HISTORY_OF_APPENDIX_SURGERY>"
					+ (String) MedInfoProposer.get("HistoryOfAppendixSurgery") + "</HISTORY_OF_APPENDIX_SURGERY>"
					+ "<HISTORY_OF_PILES_SURGERY>" + (String) MedInfoProposer.get("HistoryOfPilesSurgery")
					+ "</HISTORY_OF_PILES_SURGERY>" + "<HISTORY_OF_STONE_SURGERY>"
					+ (String) MedInfoProposer.get("HistoryOfStoneSurgery") + "</HISTORY_OF_STONE_SURGERY>"
					+ "<SURGERY_FOR_INSERTION_RODS>" + (String) MedInfoProposer.get("SurgeryForInsertionRods")
					+ "</SURGERY_FOR_INSERTION_RODS>" + "<SIGHT_CORRECTION_LASIK>"
					+ (String) MedInfoProposer.get("SightCorrectionLasik") + "</SIGHT_CORRECTION_LASIK>"
					+ "<HISTORY_OF_CATARACT_SURGERY>" + (String) MedInfoProposer.get("HistoryOfCataractSurgery")
					+ "</HISTORY_OF_CATARACT_SURGERY>" + "<SURGERY_FOR_DNS>"
					+ (String) MedInfoProposer.get("SurgeryForDns") + "</SURGERY_FOR_DNS>" + "<HISTORY_MRI_FOR_BACK>"
					+ (String) MedInfoProposer.get("HistoryMriForBack") + "</HISTORY_MRI_FOR_BACK>"
					+ "<HEALTH_CHECK_UP_NORMAL>" + (String) MedInfoProposer.get("HealthCheckUpNormal")
					+ "</HEALTH_CHECK_UP_NORMAL>" + "<BLOOD_INVESTIGATIONS>"
					+ (String) MedInfoProposer.get("BloodInvestigations") + "</BLOOD_INVESTIGATIONS>"
					+ "<BLOOD_TEST_USG_DURING_PREGNANCY>" + (String) MedInfoProposer.get("BloodTestUsgDuringPregnancy")
					+ "</BLOOD_TEST_USG_DURING_PREGNANCY>" + "<HISTORY_OF_TEST_BLOOD_DONATION>"
					+ (String) MedInfoProposer.get("HistoryOfTestBloodDonation") + "</HISTORY_OF_TEST_BLOOD_DONATION>"
					+ "<ANY_OTHER_PLEASE_SPECIFY>" + (String) MedInfoProposer.get("AnyOtherPleaseSpecify")
					+ "</ANY_OTHER_PLEASE_SPECIFY>" + "<DIAGNOSED_CONGENITAL_ANOMALY>"
					+ (String) MedInfoProposer.get("DiagnosedCongenitalAnomaly") + "</DIAGNOSED_CONGENITAL_ANOMALY>"
					+ "<CONGENITAL_ANOMALY_DETAILS>" + (String) MedInfoProposer.get("CongenitalAnomalyDetails")
					+ "</CONGENITAL_ANOMALY_DETAILS>" + "<HAD_GENETIC_TESTING>"
					+ (String) MedInfoProposer.get("HadGeneticTesting") + "</HAD_GENETIC_TESTING>"
					+ "<GENETIC_TESTING_DETAILS>" + (String) MedInfoProposer.get("GeneticTestingDetails")
					+ "</GENETIC_TESTING_DETAILS>" +

					"<COVID_QUESTIONS>" + (String) MedInfoProposer.get("CovidQuestion") + "</COVID_QUESTIONS>"
					+ "<CONTACT_WITH_SUSPECT>" + (String) MedInfoProposer.get("ContactWithSuspect")
					+ "</CONTACT_WITH_SUSPECT>" + "<ADVISED_QUARANTINE_1>"
					+ (String) MedInfoProposer.get("AdvicedQuarantine1") + "</ADVISED_QUARANTINE_1>"
					+ "<TRAVEL_ABROAD_1_YEAR>" + (String) MedInfoProposer.get("TravelAbraod1Year")
					+ "</TRAVEL_ABROAD_1_YEAR>" + "<ADVISED_QUARANTINE_2>"
					+ (String) MedInfoProposer.get("AdvicedQuarantine2") + "</ADVISED_QUARANTINE_2>"
					+ "<SPECIFY_COUNTRIES_1>" + (String) MedInfoProposer.get("SpecifyCountries1")
					+ "</SPECIFY_COUNTRIES_1>" + "<DURATION_OF_STAY_1>"
					+ (String) MedInfoProposer.get("DurationOfStay1") + "</DURATION_OF_STAY_1>"
					+ "<DATE_OF_RETURN_INDIA_1>" + (String) MedInfoProposer.get("DateOfReturnIndia1")
					+ "</DATE_OF_RETURN_INDIA_1>" + "<PLAN_TRAVEL_OVERSEAS>"
					+ (String) MedInfoProposer.get("PlanTravelOverseas") + "</PLAN_TRAVEL_OVERSEAS>"
					+ "<SPECIFY_COUNTRIES_2>" + (String) MedInfoProposer.get("SpecifyCountries2")
					+ "</SPECIFY_COUNTRIES_2>" + "<DURATION_OF_STAY_2>"
					+ (String) MedInfoProposer.get("DurationOfStay2") + "</DURATION_OF_STAY_2>"
					+ "<DATE_OF_RETURN_INDIA_2>" + (String) MedInfoProposer.get("DateOfReturnIndia2")
					+ "</DATE_OF_RETURN_INDIA_2>" + "<ADVISED_TO_BE_TESTED>"
					+ (String) MedInfoProposer.get("AdvicedToBetested") + "</ADVISED_TO_BE_TESTED>"
					+ "<AWAITING_TEST_RESULT>" + (String) MedInfoProposer.get("AwaitingTestResults")
					+ "</AWAITING_TEST_RESULT>" + "<EXPERIENCED_SYMPTOMS>"
					+ (String) MedInfoProposer.get("ExperiencedSymptoms") + "</EXPERIENCED_SYMPTOMS>"
					+ "<PERSISTENT_COUGH>" + (String) MedInfoProposer.get("PersistentCough") + "</PERSISTENT_COUGH>"
					+ "<CONSULT_DOCTOR_1>" + (String) MedInfoProposer.get("ConsultDoctor1") + "</CONSULT_DOCTOR_1>"
					+ "<ANY_TREATMENT_GIVEN_1>" + (String) MedInfoProposer.get("AnyTreatmentGiven1")
					+ "</ANY_TREATMENT_GIVEN_1>" + "<EXACT_DIAGNOSIS_1>"
					+ (String) MedInfoProposer.get("ExactDiagnosis1") + "</EXACT_DIAGNOSIS_1>"
					+ "<MADE_FULL_RECOVERY_1>" + (String) MedInfoProposer.get("MadeFullRecovery1")
					+ "</MADE_FULL_RECOVERY_1>" + "<ADVISED_SELF_ISOLATE>"
					+ (String) MedInfoProposer.get("AdvisedSelfIsolate") + "</ADVISED_SELF_ISOLATE>"
					+ "<CONSULT_DOCTOR_2>" + (String) MedInfoProposer.get("ConsultDoctor2") + "</CONSULT_DOCTOR_2>"
					+ "<ANY_TREATMENT_GIVEN_2>" + (String) MedInfoProposer.get("AnyTreatmentGiven2")
					+ "</ANY_TREATMENT_GIVEN_2>" + "<EXACT_DIAGNOSIS_2>"
					+ (String) MedInfoProposer.get("ExactDiagnosis2") + "</EXACT_DIAGNOSIS_2>"
					+ "<MADE_FULL_RECOVERY_2>" + (String) MedInfoProposer.get("MadeFullRecovery2")
					+ "</MADE_FULL_RECOVERY_2>" + "<CURRENTLY_GOOD_HEALTH>"
					+ (String) MedInfoProposer.get("CurrentlyGoodHealth") + "</CURRENTLY_GOOD_HEALTH>"
					+ "<PROVIDE_DETAILS>" + (String) MedInfoProposer.get("CurrentlyGoodHealthDetails")
					+ "</PROVIDE_DETAILS>" +
					////// Added By Suraj
					"<CANCER_INVEST>" + (String) MedInfoProposer.getOrDefault("MedicalInvestigationCC", "") + "</CANCER_INVEST>"
					+ "<CANCER_DETAILS>" + (String) MedInfoProposer.getOrDefault("InvestigationDetailsCC", "")
					+ "</CANCER_DETAILS>" + "<CANC_PARENT>"
					+ (String) MedInfoProposer.getOrDefault("MedicalParentsCC", "") + "</CANC_PARENT>"
					+ "<CANCER_PARENT_DETAILS>" + (String) MedInfoProposer.getOrDefault("ParentsDetailsCC", "")
					+ "</CANCER_PARENT_DETAILS>" + "<HEPATITIS_B_C>"
					+ (String) MedInfoProposer.getOrDefault("MedicalHepatitisCC", "") + "</HEPATITIS_B_C>"
					+ "<HEPATITIS_B_C_DETAILS>" + (String) MedInfoProposer.getOrDefault("HepatitisDetailsCC", "")
					+ "</HEPATITIS_B_C_DETAILS>" + "<RECURR_COUGH>"
					+ (String) MedInfoProposer.getOrDefault("MedicalCoughCC", "") + "</RECURR_COUGH>"
					+ "<RECURR_COUGH_DETAILS>" + (String) MedInfoProposer.getOrDefault("CoughDetailsCC", "")
					+ "</RECURR_COUGH_DETAILS>" + "<TRAVEL_OUTSIDE>"
					+ (String) MedInfoProposer.getOrDefault("TravelOutSide", "") + "</TRAVEL_OUTSIDE>"
					+ "<TRAVEL_OUTSIDE_DETAILS>" + (String) MedInfoProposer.getOrDefault("TravelOutSideDetails", "")
					+ "</TRAVEL_OUTSIDE_DETAILS>" + "<FAMILY_HEART_SIXTY>"
					+ (String) MedInfoProposer.getOrDefault("FamilyHeartSixty", "") + "</FAMILY_HEART_SIXTY>"
					+ "<AIDS_DISORDER>" + (String) MedInfoProposer.getOrDefault("AidsDisorder", "") + "</AIDS_DISORDER>"
					+ "<BIOSPIES_DISORDER>" + (String) MedInfoProposer.getOrDefault("BiospiesDisorder", "")
					+ "</BIOSPIES_DISORDER>" +
					"<ATTACH_MEDICAL_REPORT>"
					+ (String) MedInfoProposer.getOrDefault("AttachMedicalReport", "") + "</ATTACH_MEDICAL_REPORT>" +
					//HEALTH
					"<MEDICAL_ULTRASOUND>"
					+ (String) MedInfoProposer.getOrDefault("MedicalUltrasoundCC", "") + "</MEDICAL_ULTRASOUND>" +
					"<ULTRASOUND_DETAILS>"
					+ (String) MedInfoProposer.getOrDefault("UltrasoundDetailsCC", "") + "</ULTRASOUND_DETAILS>" +
					"<MEDICAL_ALCOHOL>"
					+ (String) MedInfoProposer.getOrDefault("MedicalAlcoholCC", "") + "</MEDICAL_ALCOHOL>" +
					"<ALCOHOL_DETAILS>"
					+ (String) MedInfoProposer.getOrDefault("AlcoholDetailsCC", "") + "</ALCOHOL_DETAILS>" +
					"<POS_MEDICAL_CONDITION>"
					+ (String) MedInfoProposer.getOrDefault("MedicalConditionPOS", "") + "</POS_MEDICAL_CONDITION>" +
					"<POS_HOSPITALIZED>"
					+ (String) MedInfoProposer.getOrDefault("HospitalizedPOS", "") + "</POS_HOSPITALIZED>" +
					"<HISTORY_OF_HIV_STD>"+ (String) MedInfoProposer.getOrDefault("HistoryOfHIVSTD", "") + "</HISTORY_OF_HIV_STD>" + // DR-41542 mansi
					"<DIABETES_FIRST_DIAGONOSED_MONTH>"+ (String) MedInfoProposer.getOrDefault("DiabetesFirstDiagonosedMonth", "") + "</DIABETES_FIRST_DIAGONOSED_MONTH>" +
					"<DIABETES_FIRST_DIAGONOSED_YEAR>"+ (String) MedInfoProposer.getOrDefault("DiabetesFirstDiagonosedYear", "") + "</DIABETES_FIRST_DIAGONOSED_YEAR>" +
					"<SPECIFY_TYPE_DIABETES>"+ (String) MedInfoProposer.getOrDefault("SpecifyTypeDiabetes", "") + "</SPECIFY_TYPE_DIABETES>" +
					"<HYPERT_BP_FIRST_DIAGONOSED_MONTH>"+ (String) MedInfoProposer.getOrDefault("HypertBpFirstDiagonosedMonth", "") + "</HYPERT_BP_FIRST_DIAGONOSED_MONTH>" +
					"<HYPERT_BP_FIRST_DIAGONOSED_YEAR>"+ (String) MedInfoProposer.getOrDefault("HypertBpFirstDiagonosedYear", "") + "</HYPERT_BP_FIRST_DIAGONOSED_YEAR>" +
					"<HYPERTENSION_BP_TREATMENT>"+ (String) MedInfoProposer.getOrDefault("HypertBpTreatment", "") + "</HYPERTENSION_BP_TREATMENT>" +
					"<LAST_2YR_ECG_XRAY_TEST>"+ (String) MedInfoProposer.getOrDefault("Last2YrEcgXrayTest", "") + "</LAST_2YR_ECG_XRAY_TEST>" +
					"<LAST_DOCTOR_CONSULATION_MONTH>"+ (String) MedInfoProposer.getOrDefault("LastDoctorConsulationMonth", "") + "</LAST_DOCTOR_CONSULATION_MONTH>" +
					"<LAST_DOCTOR_CONSULATION_YEAR>"+ (String) MedInfoProposer.getOrDefault("LastDoctorConsulationYear", "") + "</LAST_DOCTOR_CONSULATION_YEAR>" +
					"<LUNG_DISORDER_HISTORY_OF_ASTHMA>"+ (String) MedInfoProposer.getOrDefault("LungDisorderHistoryOfAsthma", "") + "</LUNG_DISORDER_HISTORY_OF_ASTHMA>" +
					"<BREATH_LUNG_DISORDER_FREQUENCY>"+ (String) MedInfoProposer.getOrDefault("BreathLungDisorderFrequency", "") + "</BREATH_LUNG_DISORDER_FREQUENCY>" +
					"<DISORDER_TYPE_OF_TREATMENT>"+ (String) MedInfoProposer.getOrDefault("DisorderTypeOfTreatment", "") + "</DISORDER_TYPE_OF_TREATMENT>" +
					"<ADMITTED_TO_HOSPITAL>"+ (String) MedInfoProposer.getOrDefault("AdmittedToHospital", "") + "</ADMITTED_TO_HOSPITAL>" +
					"<SMOKED_CIGARETTES_TOBACCO>"+ (String) MedInfoProposer.getOrDefault("SmokedCigarettesTobacco", "") + "</SMOKED_CIGARETTES_TOBACCO>" +
					
					
					///////// Till Here//////////
					"</Q_MED_INFO_PROP>";
			
			JSONArray DiabetesAnyComplicationsProp = (JSONArray) MedInfoProposer.getOrDefault("DiabetesAnyComplications", new JSONArray());
			for (Object j : DiabetesAnyComplicationsProp) {
				attributesXML = attributesXML + "<Q_LIST_DIABETES_COMPLICATIONS_PROP>" + j.toString()
						+ "</Q_LIST_DIABETES_COMPLICATIONS_PROP>";
			}

			JSONArray HypertBpAnyComplicationsProp = (JSONArray) MedInfoProposer.getOrDefault("HypertBpAnyComplications", new JSONArray());
			for (Object j : HypertBpAnyComplicationsProp) {
				attributesXML = attributesXML + "<Q_LIST_BP_ANY_COMPLICATIONS_PROP>" + j.toString()
						+ "</Q_LIST_BP_ANY_COMPLICATIONS_PROP>";
			}

			JSONArray HypertBpInvestigatedForProp = (JSONArray) MedInfoProposer.getOrDefault("HypertBpInvestigatedFor", new JSONArray());
			for (Object j : HypertBpInvestigatedForProp) {
				attributesXML = attributesXML + "<Q_LIST_INVESTIGATED_FOR_PROP>" + j.toString()
						+ "</Q_LIST_INVESTIGATED_FOR_PROP>";
			}

			// MedicalInformationInsured
			JSONObject MedInfoInsuredObj = (JSONObject) jsonParser
					.parse(MedicalPrevPolInfoObj.getOrDefault("MedicalInformationInsured", "{}").toString());

			attributesXML = attributesXML +
			// Q_MED_INFO_INSUR_SUGGESTED_PHYSIOTHERAPY_label
					"<Q_MED_INFO_INSUR>" + "<DIABETES>" + (String) MedInfoInsuredObj.get("Diabetes") + "</DIABETES>"
					+ "<MANAGING_DIABETES>" + (String) MedInfoInsuredObj.get("ManagingDiabetes")
					+ "</MANAGING_DIABETES>" + "<DIABETIC_FOR>" + (String) MedInfoInsuredObj.get("DiabeticFor")
					+ "</DIABETIC_FOR>" + "<DIABETES_COMPLICATIONS>"
					+ (String) MedInfoInsuredObj.get("DiabetesComplications") + "</DIABETES_COMPLICATIONS>"
					+ "<DIABETES_OTHER_DETAILS>" + (String) MedInfoInsuredObj.get("DiabetesOtherDetails")
					+ "</DIABETES_OTHER_DETAILS>" + "<HYPERTENSION_BP>"
					+ (String) MedInfoInsuredObj.get("HypertensionBp") + "</HYPERTENSION_BP>" + "<BP_UNDER_CONTROL>"
					+ (String) MedInfoInsuredObj.get("BpUnderControl") + "</BP_UNDER_CONTROL>"
					+ "<CHOLESTEROL_UNDER_CONTROL>" + (String) MedInfoInsuredObj.get("CholesterolUnderControl")
					+ "</CHOLESTEROL_UNDER_CONTROL>" + "<THYROID_UNDER_CONTROL>"
					+ (String) MedInfoInsuredObj.get("ThyroidUnderControl") + "</THYROID_UNDER_CONTROL>"
					+ "<BP_CHOLESTEROL_DETAILS>" + (String) MedInfoInsuredObj.get("BpCholesterolDetails")
					+ "</BP_CHOLESTEROL_DETAILS>" + "<HEART_DISORDER>" + (String) MedInfoInsuredObj.get("HeartDisorder")
					+ "</HEART_DISORDER>" + "<HISTORY_OF_CHEST_PAIN>"
					+ (String) MedInfoInsuredObj.get("HistoryOfChestPain") + "</HISTORY_OF_CHEST_PAIN>"
					+ "<CHEST_PAIN_OTHER_DETAILS>" + (String) MedInfoInsuredObj.get("ChestPainOtherDetails")
					+ "</CHEST_PAIN_OTHER_DETAILS>" + "<LUNG_DISORDERS>"
					+ (String) MedInfoInsuredObj.get("LungDisorders") + "</LUNG_DISORDERS>"
					+ "<HISTORY_OF_TUBERCULOSIS>" + (String) MedInfoInsuredObj.get("HistoryOfTuberculosis")
					+ "</HISTORY_OF_TUBERCULOSIS>" + "<ALLERGIC_BRONCHITIS>"
					+ (String) MedInfoInsuredObj.get("AllergicBronchitis") + "</ALLERGIC_BRONCHITIS>"
					+ "<HISTORY_OF_ASTHMA>" + (String) MedInfoInsuredObj.get("HistoryOfAsthma") + "</HISTORY_OF_ASTHMA>"
					+ "<LUNG_DISORDERS_DETAILS>" + (String) MedInfoInsuredObj.get("LungDisordersDetails")
					+ "</LUNG_DISORDERS_DETAILS>" + "<LIVER_RELATED_DISORDER>"
					+ (String) MedInfoInsuredObj.get("LiverRelatedDisorder") + "</LIVER_RELATED_DISORDER>"
					+ "<HISTORY_OF_JAUNDICE>" + (String) MedInfoInsuredObj.get("HistoryOfJaundice")
					+ "</HISTORY_OF_JAUNDICE>" + "<INDIGESTION_CONSTIPATION>"
					+ (String) MedInfoInsuredObj.get("IndigestionConstipation") + "</INDIGESTION_CONSTIPATION>"
					+ "<HISTORY_OF_GALL_BLADDER>" + (String) MedInfoInsuredObj.get("HistoryOfGallBladder")
					+ "</HISTORY_OF_GALL_BLADDER>" + "<HISTORY_OF_STONES>"
					+ (String) MedInfoInsuredObj.get("HistoryOfStones") + "</HISTORY_OF_STONES>"
					+ "<LIVER_OTHER_DETAILS>" + (String) MedInfoInsuredObj.get("LiverOtherDetails")
					+ "</LIVER_OTHER_DETAILS>" + "<ABRMAL_GROWTH_OR_STD>"
					+ (String) MedInfoInsuredObj.get("AbnormalGrowthOrStd") + "</ABRMAL_GROWTH_OR_STD>"
					+ "<HISTORY_OF_IRON_DEFICIENCY>" + (String) MedInfoInsuredObj.get("HistoryOfIronDeficiency")
					+ "</HISTORY_OF_IRON_DEFICIENCY>" + "<HISTORY_OF_LIPOMA>"
					+ (String) MedInfoInsuredObj.get("HistoryOfLipoma") + "</HISTORY_OF_LIPOMA>"
					+ "<ABRMAL_GROWTH_OTHER_DETAILS>" + (String) MedInfoInsuredObj.get("AbnormalGrowthOtherDetails")
					+ "</ABRMAL_GROWTH_OTHER_DETAILS>" + "<KIDNEY_DISORDER>"
					+ (String) MedInfoInsuredObj.get("KidneyDisorder") + "</KIDNEY_DISORDER>" + "<HISTORY_OF_UTI>"
					+ (String) MedInfoInsuredObj.get("HistoryOfUti") + "</HISTORY_OF_UTI>"
					+ "<HISTORY_OF_KIDNEY_SURGERY>" + (String) MedInfoInsuredObj.get("HistoryOfKidneySurgery")
					+ "</HISTORY_OF_KIDNEY_SURGERY>" + "<HISTORY_OF_STONE>"
					+ (String) MedInfoInsuredObj.get("HistoryOfStone") + "</HISTORY_OF_STONE>"
					+ "<KIDNEY_OTHER_DETAILS>" + (String) MedInfoInsuredObj.get("KidneyOtherDetails")
					+ "</KIDNEY_OTHER_DETAILS>" + "<NEUROLOGICAL_PROBLEM>"
					+ (String) MedInfoInsuredObj.get("NeurologicalProblem") + "</NEUROLOGICAL_PROBLEM>"
					+ "<NEUROLOGICAL_DETAILS>" + (String) MedInfoInsuredObj.get("NeurologicalDetails")
					+ "</NEUROLOGICAL_DETAILS>" + "<MUSCULAR_JOINT_DISORDERS>"
					+ (String) MedInfoInsuredObj.get("MuscularJointDisorders") + "</MUSCULAR_JOINT_DISORDERS>"
					+ "<BACK_PAIN_SLIP_DISC>" + (String) MedInfoInsuredObj.get("BackPainSlipDisc")
					+ "</BACK_PAIN_SLIP_DISC>" + "<SUGGESTED_PHYSIOTHERAPY>"
					+ (String) MedInfoInsuredObj.get("SuggestedPhysiotherapy") + "</SUGGESTED_PHYSIOTHERAPY>"
					+ "<HISTORY_OF_HAIRLINE_FRACTURE>" + (String) MedInfoInsuredObj.get("HistoryOfHairlineFracture")
					+ "</HISTORY_OF_HAIRLINE_FRACTURE>" + "<HISTORY_OF_OSTEOARTHRITIS>"
					+ (String) MedInfoInsuredObj.get("HistoryOfOsteoarthritis") + "</HISTORY_OF_OSTEOARTHRITIS>"
					+ "<HISTORY_OF_ANY_FRACTURE>" + (String) MedInfoInsuredObj.get("HistoryOfAnyFracture")
					+ "</HISTORY_OF_ANY_FRACTURE>" + "<MUSCULAR_JOINT_DETAILS>"
					+ (String) MedInfoInsuredObj.get("MuscularJointDetails") + "</MUSCULAR_JOINT_DETAILS>"
					+ "<HISTORY_OF_HOSPITALIZATION>" + (String) MedInfoInsuredObj.get("HistoryOfHospitalization")
					+ "</HISTORY_OF_HOSPITALIZATION>" + "<HOSPITALIZATION_FOR_FEVER>"
					+ (String) MedInfoInsuredObj.get("HospitalizationForFever") + "</HOSPITALIZATION_FOR_FEVER>"
					+ "<HOSPITALIZATION_OF_POISONING>" + (String) MedInfoInsuredObj.get("HospitalizationOfPoisoning")
					+ "</HOSPITALIZATION_OF_POISONING>" + "<HOSPITALIZATION_FOR_ACCIDENT>"
					+ (String) MedInfoInsuredObj.get("HospitalizationForAccident") + "</HOSPITALIZATION_FOR_ACCIDENT>"
					+ "<HOSPITALIZED_FOR_CSECTION>" + (String) MedInfoInsuredObj.get("HospitalizedForCsection")
					+ "</HOSPITALIZED_FOR_CSECTION>" + "<HOSPITALIZED_FOR_MALARIA>"
					+ (String) MedInfoInsuredObj.get("HospitalizedForMalaria") + "</HOSPITALIZED_FOR_MALARIA>"
					+ "<HISTORY_OF_COLD>" + (String) MedInfoInsuredObj.get("HistoryOfCold") + "</HISTORY_OF_COLD>"
					+ "<HOSPITALIZATION_OTHER_DETAILS>" + (String) MedInfoInsuredObj.get("HospitalizationOtherDetails")
					+ "</HOSPITALIZATION_OTHER_DETAILS>" + "<ADVISED_TESTS_XRAY_SURGERY>"
					+ (String) MedInfoInsuredObj.get("AdvisedTestsXraySurgery") + "</ADVISED_TESTS_XRAY_SURGERY>"
					+ "<ADVISED_S_XRAY_SURGERY>" + (String) MedInfoInsuredObj.get("AdvisedTestsXraySurgery")
					+ "</ADVISED_S_XRAY_SURGERY>" + "<HISTORY_OF_ACCIDENT_SURGERY>"
					+ (String) MedInfoInsuredObj.get("HistoryOfAccidentSurgery") + "</HISTORY_OF_ACCIDENT_SURGERY>"
					+ "<HISTORY_OF_APPENDIX_SURGERY>" + (String) MedInfoInsuredObj.get("HistoryOfAppendixSurgery")
					+ "</HISTORY_OF_APPENDIX_SURGERY>" + "<HISTORY_OF_PILES_SURGERY>"
					+ (String) MedInfoInsuredObj.get("HistoryOfPilesSurgery") + "</HISTORY_OF_PILES_SURGERY>"
					+ "<HISTORY_OF_STONE_SURGERY>" + (String) MedInfoInsuredObj.get("HistoryOfStoneSurgery")
					+ "</HISTORY_OF_STONE_SURGERY>" + "<SURGERY_FOR_INSERTION_RODS>"
					+ (String) MedInfoInsuredObj.get("SurgeryForInsertionRods") + "</SURGERY_FOR_INSERTION_RODS>"
					+ "<SIGHT_CORRECTION_LASIK>" + (String) MedInfoInsuredObj.get("SightCorrectionLasik")
					+ "</SIGHT_CORRECTION_LASIK>" + "<HISTORY_OF_CATARACT_SURGERY>"
					+ (String) MedInfoInsuredObj.get("HistoryOfCataractSurgery") + "</HISTORY_OF_CATARACT_SURGERY>"
					+ "<SURGERY_FOR_DNS>" + (String) MedInfoInsuredObj.get("SurgeryForDns") + "</SURGERY_FOR_DNS>"
					+ "<HISTORY_MRI_FOR_BACK>" + (String) MedInfoInsuredObj.get("HistoryMriForBack")
					+ "</HISTORY_MRI_FOR_BACK>" + "<HEALTH_CHECK_UP_NORMAL>"
					+ (String) MedInfoInsuredObj.get("HealthCheckUpNormal") + "</HEALTH_CHECK_UP_NORMAL>"
					+ "<BLOOD_INVESTIGATIONS>" + (String) MedInfoInsuredObj.get("BloodInvestigations")
					+ "</BLOOD_INVESTIGATIONS>" + "<BLOOD__USG_DURING_PREGNANCY>"
					+ (String) MedInfoInsuredObj.get("BloodTestUsgDuringPregnancy") + "</BLOOD__USG_DURING_PREGNANCY>"
					+ "<HISTORY_OF__BLOOD_DONATION>" + (String) MedInfoInsuredObj.get("HistoryOfTestBloodDonation")
					+ "</HISTORY_OF__BLOOD_DONATION>" + "<ANY_OTHER_PLEASE_SPECIFY>"
					+ (String) MedInfoInsuredObj.get("AnyOtherPleaseSpecify") + "</ANY_OTHER_PLEASE_SPECIFY>"
					+ "<DIAGSED_CONGENITAL_AMALY>" + (String) MedInfoInsuredObj.get("DiagnosedCongenitalAnomaly")
					+ "</DIAGSED_CONGENITAL_AMALY>" + "<CONGENITAL_AMALY_DETAILS>"
					+ (String) MedInfoInsuredObj.get("CongenitalAnomalyDetails") + "</CONGENITAL_AMALY_DETAILS>"
					+ "<HAD_GENETIC_ING>" + (String) MedInfoInsuredObj.get("HadGeneticTesting") + "</HAD_GENETIC_ING>"
					+ "<GENETIC_ING_DETAILS>" + (String) MedInfoInsuredObj.get("GeneticTestingDetails")
					+ "</GENETIC_ING_DETAILS>" + "<BLOOD_TEST_USG_DURING_PREGNANCY>"
					+ (String) MedInfoInsuredObj.get("BloodTestUsgDuringPregnancy")
					+ "</BLOOD_TEST_USG_DURING_PREGNANCY>" + "<HISTORY_OF_TEST_BLOOD_DONATION>"
					+ (String) MedInfoInsuredObj.get("HistoryOfTestBloodDonation") + "</HISTORY_OF_TEST_BLOOD_DONATION>"
					+ "<DIAGNOSED_CONGENITAL_ANOMALY>" + (String) MedInfoInsuredObj.get("DiagnosedCongenitalAnomaly")
					+ "</DIAGNOSED_CONGENITAL_ANOMALY>" + "<CONGENITAL_ANOMALY_DETAILS>"
					+ (String) MedInfoInsuredObj.get("CongenitalAnomalyDetails") + "</CONGENITAL_ANOMALY_DETAILS>"
					+ "<HAD_GENETIC_TESTING>" + (String) MedInfoInsuredObj.get("HadGeneticTesting")
					+ "</HAD_GENETIC_TESTING>" + "<GENETIC_TESTING_DETAILS>"
					+ (String) MedInfoInsuredObj.get("GeneticTestingDetails") + "</GENETIC_TESTING_DETAILS>"
					+ "<ABNORMAL_GROWTH_OR_STD>" + (String) MedInfoInsuredObj.get("AbnormalGrowthOrStd")
					+ "</ABNORMAL_GROWTH_OR_STD>" + "<ABNORMAL_GROWTH_OTHER_DETAILS>"
					+ (String) MedInfoInsuredObj.get("AbnormalGrowthOtherDetails") + "</ABNORMAL_GROWTH_OTHER_DETAILS>"
					+

					"<COVID_QUESTIONS>" + (String) MedInfoInsuredObj.get("CovidQuestion") + "</COVID_QUESTIONS>"
					+ "<CONTACT_WITH_SUSPECT>" + (String) MedInfoInsuredObj.get("ContactWithSuspect")
					+ "</CONTACT_WITH_SUSPECT>" + "<ADVISED_QUARANTINE_1>"
					+ (String) MedInfoInsuredObj.get("AdvicedQuarantine1") + "</ADVISED_QUARANTINE_1>"
					+ "<TRAVEL_ABROAD_1_YEAR>" + (String) MedInfoInsuredObj.get("TravelAbraod1Year")
					+ "</TRAVEL_ABROAD_1_YEAR>" + "<ADVISED_QUARANTINE_2>"
					+ (String) MedInfoInsuredObj.get("AdvicedQuarantine2") + "</ADVISED_QUARANTINE_2>"
					+ "<SPECIFY_COUNTRIES_1>" + (String) MedInfoInsuredObj.get("SpecifyCountries1")
					+ "</SPECIFY_COUNTRIES_1>" + "<DURATION_OF_STAY_1>"
					+ (String) MedInfoInsuredObj.get("DurationOfStay1") + "</DURATION_OF_STAY_1>"
					+ "<DATE_OF_RETURN_INDIA_1>" + (String) MedInfoInsuredObj.get("DateOfReturnIndia1")
					+ "</DATE_OF_RETURN_INDIA_1>" + "<PLAN_TRAVEL_OVERSEAS>"
					+ (String) MedInfoInsuredObj.get("PlanTravelOverseas") + "</PLAN_TRAVEL_OVERSEAS>"
					+ "<SPECIFY_COUNTRIES_2>" + (String) MedInfoInsuredObj.get("SpecifyCountries2")
					+ "</SPECIFY_COUNTRIES_2>" + "<DURATION_OF_STAY_2>"
					+ (String) MedInfoInsuredObj.get("DurationOfStay2") + "</DURATION_OF_STAY_2>"
					+ "<DATE_OF_RETURN_INDIA_2>" + (String) MedInfoInsuredObj.get("DateOfReturnIndia2")
					+ "</DATE_OF_RETURN_INDIA_2>" + "<ADVISED_TO_BE_TESTED>"
					+ (String) MedInfoInsuredObj.get("AdvicedToBetested") + "</ADVISED_TO_BE_TESTED>"
					+ "<AWAITING_TEST_RESULT>" + (String) MedInfoInsuredObj.get("AwaitingTestResults")
					+ "</AWAITING_TEST_RESULT>" + "<EXPERIENCED_SYMPTOMS>"
					+ (String) MedInfoInsuredObj.get("ExperiencedSymptoms") + "</EXPERIENCED_SYMPTOMS>"
					+ "<PERSISTENT_COUGH>" + (String) MedInfoInsuredObj.get("PersistentCough") + "</PERSISTENT_COUGH>"
					+ "<CONSULT_DOCTOR_1>" + (String) MedInfoInsuredObj.get("ConsultDoctor1") + "</CONSULT_DOCTOR_1>"
					+ "<ANY_TREATMENT_GIVEN_1>" + (String) MedInfoInsuredObj.get("AnyTreatmentGiven1")
					+ "</ANY_TREATMENT_GIVEN_1>" + "<EXACT_DIAGNOSIS_1>"
					+ (String) MedInfoInsuredObj.get("ExactDiagnosis1") + "</EXACT_DIAGNOSIS_1>"
					+ "<MADE_FULL_RECOVERY_1>" + (String) MedInfoInsuredObj.get("MadeFullRecovery1")
					+ "</MADE_FULL_RECOVERY_1>" + "<ADVISED_SELF_ISOLATE>"
					+ (String) MedInfoInsuredObj.get("AdvisedSelfIsolate") + "</ADVISED_SELF_ISOLATE>"
					+ "<CONSULT_DOCTOR_2>" + (String) MedInfoInsuredObj.get("ConsultDoctor2") + "</CONSULT_DOCTOR_2>"
					+ "<ANY_TREATMENT_GIVEN_2>" + (String) MedInfoInsuredObj.get("AnyTreatmentGiven2")
					+ "</ANY_TREATMENT_GIVEN_2>" + "<EXACT_DIAGNOSIS_2>"
					+ (String) MedInfoInsuredObj.get("ExactDiagnosis2") + "</EXACT_DIAGNOSIS_2>"
					+ "<MADE_FULL_RECOVERY_2>" + (String) MedInfoInsuredObj.get("MadeFullRecovery2")
					+ "</MADE_FULL_RECOVERY_2>" + "<CURRENTLY_GOOD_HEALTH>"
					+ (String) MedInfoInsuredObj.get("CurrentlyGoodHealth") + "</CURRENTLY_GOOD_HEALTH>"
					+ "<PROVIDE_DETAILS>" + (String) MedInfoInsuredObj.get("CurrentlyGoodHealthDetails")
					+ "</PROVIDE_DETAILS>" +
					////// Added By Suraj
					"<CANCER_INVEST>" + (String) MedInfoInsuredObj.getOrDefault("MedicalInvestigationCC", "") + "</CANCER_INVEST>"
					+ "<CANCER_DETAILS>" + (String) MedInfoInsuredObj.getOrDefault("InvestigationDetailsCC", "")
					+ "</CANCER_DETAILS>" + "<CANCER_PARENT>"
					+ (String) MedInfoInsuredObj.getOrDefault("MedicalParentsCC", "") + "</CANCER_PARENT>"
					+ "<CANCER_PARENT_DETAILS>" + (String) MedInfoInsuredObj.getOrDefault("ParentsDetailsCC", "")
					+ "</CANCER_PARENT_DETAILS>" + "<HEPATITIS_B_C>"
					+ (String) MedInfoInsuredObj.getOrDefault("MedicalHepatitisCC", "") + "</HEPATITIS_B_C>"
					+ "<HEPATITIS_B_C_DETAILS>" + (String) MedInfoInsuredObj.getOrDefault("HepatitisDetailsCC", "")
					+ "</HEPATITIS_B_C_DETAILS>" + "<RECURR_COUGH>"
					+ (String) MedInfoInsuredObj.getOrDefault("MedicalCoughCC", "") + "</RECURR_COUGH>"
					+ "<RECURR_COUGH_DETAILS>" + (String) MedInfoInsuredObj.getOrDefault("CoughDetailsCC", "")
					+ "</RECURR_COUGH_DETAILS>" + "<TRAVEL_OUTSIDE>"
					+ (String) MedInfoInsuredObj.getOrDefault("TravelOutSide", "") + "</TRAVEL_OUTSIDE>"
					+ "<TRAVEL_OUTSIDE_DETAILS>" + (String) MedInfoInsuredObj.getOrDefault("TravelOutSideDetails", "")
					+ "</TRAVEL_OUTSIDE_DETAILS>" + "<FAMILY_HEART_SIXTY>"
					+ (String) MedInfoInsuredObj.getOrDefault("FamilyHeartSixty", "") + "</FAMILY_HEART_SIXTY>"
					+ "<AIDS_DISORDER>" + (String) MedInfoInsuredObj.getOrDefault("AidsDisorder", "")
					+ "</AIDS_DISORDER>" + "<BIOSPIES_DISORDER>"
					+ (String) MedInfoInsuredObj.getOrDefault("BiospiesDisorder", "") + "</BIOSPIES_DISORDER>"
					+ "<ATTACH_MEDICAL_REPORT>" + (String) MedInfoInsuredObj.getOrDefault("AttachMedicalReport", "")
					+ "</ATTACH_MEDICAL_REPORT>" +
					"<POS_MEDICAL_CONDITION>"
					+ (String) MedInfoInsuredObj.getOrDefault("MedicalConditionPOS", "") + "</POS_MEDICAL_CONDITION>" +
					"<POS_HOSPITALIZED>"
					+ (String) MedInfoInsuredObj.getOrDefault("HospitalizedPOS", "") + "</POS_HOSPITALIZED>" +
					
	//HEALTH
	"<MEDICAL_ULTRASOUND>"
	+ (String) MedInfoInsuredObj.getOrDefault("MedicalUltrasoundCC", "") + "</MEDICAL_ULTRASOUND>" +
	"<ULTRASOUND_DETAILS>"
	+ (String) MedInfoInsuredObj.getOrDefault("UltrasoundDetailsCC", "") + "</ULTRASOUND_DETAILS>" +
	"<MEDICAL_ALCOHOL>"
	+ (String) MedInfoInsuredObj.getOrDefault("MedicalAlcoholCC", "") + "</MEDICAL_ALCOHOL>" +
	"<ALCOHOL_DETAILS>"
	+ (String) MedInfoInsuredObj.getOrDefault("AlcoholDetailsCC", "") + "</ALCOHOL_DETAILS>" +
					///////// Till Here//////////
					"<HISTORY_OF_HIV_STD>"+ (String) MedInfoInsuredObj.getOrDefault("HistoryOfHIVSTD", "") + "</HISTORY_OF_HIV_STD>" + // DR-41542 mansi
					"<DIABETES_FIRST_DIAGONOSED_MONTH>"+ (String) MedInfoInsuredObj.getOrDefault("DiabetesFirstDiagonosedMonth", "") + "</DIABETES_FIRST_DIAGONOSED_MONTH>" +
					"<DIABETES_FIRST_DIAGONOSED_YEAR>"+ (String) MedInfoInsuredObj.getOrDefault("DiabetesFirstDiagonosedYear", "") + "</DIABETES_FIRST_DIAGONOSED_YEAR>" +
					"<SPECIFY_TYPE_DIABETES>"+ (String) MedInfoInsuredObj.getOrDefault("SpecifyTypeDiabetes", "") + "</SPECIFY_TYPE_DIABETES>" +
					"<HYPERT_BP_FIRST_DIAGONOSED_MONTH>"+ (String) MedInfoInsuredObj.getOrDefault("HypertBpFirstDiagonosedMonth", "") + "</HYPERT_BP_FIRST_DIAGONOSED_MONTH>" +
					"<HYPERT_BP_FIRST_DIAGONOSED_YEAR>"+ (String) MedInfoInsuredObj.getOrDefault("HypertBpFirstDiagonosedYear", "") + "</HYPERT_BP_FIRST_DIAGONOSED_YEAR>" +
					"<HYPERTENSION_BP_TREATMENT>"+ (String) MedInfoInsuredObj.getOrDefault("HypertBpTreatment", "") + "</HYPERTENSION_BP_TREATMENT>" +
					"<LAST_2YR_ECG_XRAY_TEST>"+ (String) MedInfoInsuredObj.getOrDefault("Last2YrEcgXrayTest", "") + "</LAST_2YR_ECG_XRAY_TEST>" +
					"<LAST_DOCTOR_CONSULATION_MONTH>"+ (String) MedInfoInsuredObj.getOrDefault("LastDoctorConsulationMonth", "") + "</LAST_DOCTOR_CONSULATION_MONTH>" +
					"<LAST_DOCTOR_CONSULATION_YEAR>"+ (String) MedInfoInsuredObj.getOrDefault("LastDoctorConsulationYear", "") + "</LAST_DOCTOR_CONSULATION_YEAR>" +
					"<LUNG_DISORDER_HISTORY_OF_ASTHMA>"+ (String) MedInfoInsuredObj.getOrDefault("LungDisorderHistoryOfAsthma", "") + "</LUNG_DISORDER_HISTORY_OF_ASTHMA>" +
					"<BREATH_LUNG_DISORDER_FREQUENCY>"+ (String) MedInfoInsuredObj.getOrDefault("BreathLungDisorderFrequency", "") + "</BREATH_LUNG_DISORDER_FREQUENCY>" +
					"<DISORDER_TYPE_OF_TREATMENT>"+ (String) MedInfoInsuredObj.getOrDefault("DisorderTypeOfTreatment", "") + "</DISORDER_TYPE_OF_TREATMENT>" +
					"<ADMITTED_TO_HOSPITAL>"+ (String) MedInfoInsuredObj.getOrDefault("AdmittedToHospital", "") + "</ADMITTED_TO_HOSPITAL>" +
					"<SMOKED_CIGARETTES_TOBACCO>"+ (String) MedInfoInsuredObj.getOrDefault("SmokedCigarettesTobacco", "") + "</SMOKED_CIGARETTES_TOBACCO>" +
					
					"</Q_MED_INFO_INSUR>";
			
			JSONArray DiabetesAnyComplicationsInsur = (JSONArray) MedInfoInsuredObj.getOrDefault("DiabetesAnyComplications", new JSONArray());
			for (Object j : DiabetesAnyComplicationsInsur) {
				attributesXML = attributesXML + "<Q_LIST_DIABETES_COMPLICATIONS_INSUR>" + j.toString()
						+ "</Q_LIST_DIABETES_COMPLICATIONS_INSUR>";
			}

			JSONArray HypertBpAnyComplicationsInsur = (JSONArray) MedInfoInsuredObj.getOrDefault("HypertBpAnyComplications", new JSONArray());
			for (Object j : HypertBpAnyComplicationsInsur) {
				attributesXML = attributesXML + "<Q_LIST_BP_ANY_COMPLICATIONS_INSUR>" + j.toString()
						+ "</Q_LIST_BP_ANY_COMPLICATIONS_INSUR>";
			}

			JSONArray HypertBpInvestigatedForInsur = (JSONArray) MedInfoInsuredObj.getOrDefault("HypertBpInvestigatedFor", new JSONArray());
			for (Object j : HypertBpInvestigatedForInsur) {
				attributesXML = attributesXML + "<Q_LIST_INVESTIGATED_FOR_INSUR>" + j.toString()
						+ "</Q_LIST_INVESTIGATED_FOR_INSUR>";
			}

			// Height and Weight
			JSONObject HeightAndWeightObj = (JSONObject) jsonParser
					.parse(MedicalPrevPolInfoObj.getOrDefault("HeightandWeight", "{}").toString());
			attributesXML = attributesXML + "<Q_HEIGHT_AND_WEIGHT>\r\n" + "<HEIGHT_CM>"
					+ (String) HeightAndWeightObj.get("HeightCM") + "</HEIGHT_CM>\r\n" + "<WEIGHT_KG>"
					+ (String) HeightAndWeightObj.get("WeightKG") + "</WEIGHT_KG>\r\n"  + "<WEIGHT_CHANGED>"
					+ (String) HeightAndWeightObj.getOrDefault("WEIGHT_CHANGED","") + "</WEIGHT_CHANGED>\r\n" + "</Q_HEIGHT_AND_WEIGHT>"; // DR-24067 MANSI
					
					
			//PROP
			JSONObject HEIGHT_PROP = (JSONObject) jsonParser
					.parse(HeightAndWeightObj.getOrDefault("ProposerDetails", "{}").toString());
			attributesXML = attributesXML + "<Q_HEIGHT_AND_WEIGHT_PROP>\r\n" + "<HEIGHT_CM>"
					+ (String) HEIGHT_PROP.get("HeightCM") + "</HEIGHT_CM>\r\n" + "<WEIGHT_KG>"
					+ (String) HEIGHT_PROP.get("WeightKG") + "</WEIGHT_KG>\r\n"+ "<WEIGHT_CHANGED>"
					+ (String) HEIGHT_PROP.getOrDefault("WEIGHT_CHANGED","") + "</WEIGHT_CHANGED>\r\n"+ "</Q_HEIGHT_AND_WEIGHT_PROP>";// DR-24067 MANSI
			
			//ISNUR
			JSONObject HEIGHT_INSUR = (JSONObject) jsonParser
					.parse(HeightAndWeightObj.getOrDefault("L2BIDetails", "{}").toString());
			attributesXML = attributesXML + "<Q_HEIGHT_AND_WEIGHT_INSUR>\r\n" + "<HEIGHT_CM>"
					+ (String) HEIGHT_INSUR.get("HeightCM") + "</HEIGHT_CM>\r\n" + "<WEIGHT_KG>"
					+ (String) HEIGHT_INSUR.get("WeightKG") + "</WEIGHT_KG>\r\n" + "<WEIGHT_CHANGED>"
					+ (String) HEIGHT_INSUR.getOrDefault("WEIGHT_CHANGED","") + "</WEIGHT_CHANGED>\r\n"+ "</Q_HEIGHT_AND_WEIGHT_INSUR>";// DR-24067 MANSI

			// JuvenilleInformation
			JSONObject JuvenilleInformationObj = (JSONObject) jsonParser
					.parse(MedicalPrevPolInfoObj.getOrDefault("JuvenilleInformation", "{}").toString());
			attributesXML = attributesXML + "<Q_JUVENILLE_INFO>\r\n" + "<PARENT_OCCUPATION>"
					+ (String) JuvenilleInformationObj.get("ParentOccupation") + "</PARENT_OCCUPATION>\r\n"
					+ "<PARENT_ANNUAL_INC>" + (String) JuvenilleInformationObj.get("ParentAnnualIncome")
					+ "</PARENT_ANNUAL_INC>\r\n" + "<PARENT_TOTAL_INSURANCE>"
					+ (String) JuvenilleInformationObj.get("ParentTotalInsurance") + "</PARENT_TOTAL_INSURANCE>\r\n"
					+ "</Q_JUVENILLE_INFO>";

			// LifeStyleInformation
			JSONObject LifeStyleInformationObj = (JSONObject) jsonParser
					.parse(MedicalPrevPolInfoObj.getOrDefault("LifeStyleInformation", "{}").toString());

			attributesXML = attributesXML + "<Q_LIFE_STYLE_INFO>\r\n" + "<HAZARDOUS_PROP>"
					+ (String) LifeStyleInformationObj.get("HazardousProp") + "</HAZARDOUS_PROP>\r\n"
					+ "<HAZARDOUS_INSUR>" + (String) LifeStyleInformationObj.get("HazardousInsur")
					+ "</HAZARDOUS_INSUR>\r\n" + "<CONVICTED_PROP>"
					+ (String) LifeStyleInformationObj.get("ConvictedProp") + "</CONVICTED_PROP>\r\n"
					+ "<CONVICTED_INSUR>" + (String) LifeStyleInformationObj.get("ConvictedInsur")
					+ "</CONVICTED_INSUR>\r\n" + "<INVOLVED_PROP>"
					+ (String) LifeStyleInformationObj.get("InvolvedProp") + "</INVOLVED_PROP>\r\n" + "<INVOLVED_INSUR>"
					+ (String) LifeStyleInformationObj.get("InvolvedInsur") + "</INVOLVED_INSUR>\r\n"
					+ "<CONVICT_DETAILS_PROP>" + (String) LifeStyleInformationObj.get("ConvictDetailsProp")
					+ "</CONVICT_DETAILS_PROP>\r\n" + "<CONVICT_DETAILS_INSUR>"
					+ (String) LifeStyleInformationObj.get("ConvictDetailsInsur") + "</CONVICT_DETAILS_INSUR>\r\n"
					+ "</Q_LIFE_STYLE_INFO>";

			// OtherPolicyInformation
			JSONObject OtherPolicyInformationObj = (JSONObject) jsonParser
					.parse(MedicalPrevPolInfoObj.getOrDefault("OtherPolicyInformation", "{}").toString());
			attributesXML = attributesXML + "<Q_OTHER_POLICY_INFO>\r\n" + "<INSUR_POLICY_PROP>"
					+ (String) OtherPolicyInformationObj.get("InsurPolicyProp") + "</INSUR_POLICY_PROP>\r\n"
					+ "<INSUR_POLICY_INSUR>" + (String) OtherPolicyInformationObj.get("InsurPolicyInsur")
					+ "</INSUR_POLICY_INSUR>\r\n" + "<OFFERED_PROP>"
					+ (String) OtherPolicyInformationObj.get("OfferedProp") + "</OFFERED_PROP>\r\n" + "<OFFERED_INSUR>"
					+ (String) OtherPolicyInformationObj.get("OfferedInsur") + "</OFFERED_INSUR>\r\n" + "<ISSUED_PROP>"
					+ (String) OtherPolicyInformationObj.get("IssuedProp") + "</ISSUED_PROP>\r\n" + "<ISSUED_INSUR>"
					+ (String) OtherPolicyInformationObj.get("IssuedInsur") + "</ISSUED_INSUR>\r\n"
					+ "<LIFE_TOTAL_SUM_PROP>" + (String) OtherPolicyInformationObj.get("LifeTotalSumProp")
					+ "</LIFE_TOTAL_SUM_PROP>\r\n" + "<LIFE_TOTAL_SUM_INSUR>"
					+ (String) OtherPolicyInformationObj.get("LifeTotalSumInsur") + "</LIFE_TOTAL_SUM_INSUR>\r\n"
					+ "<TOTAL_SUM_PROP>" + (String) OtherPolicyInformationObj.get("TotalSumProp")
					+ "</TOTAL_SUM_PROP>\r\n" + "<TOTAL_SUM_INSUR>"
					+ (String) OtherPolicyInformationObj.get("TotalSumInsur") + "</TOTAL_SUM_INSUR>\r\n"
					+ "</Q_OTHER_POLICY_INFO>";

			// SpouseInformation
			JSONObject SpouseInformationObj = (JSONObject) jsonParser
					.parse(MedicalPrevPolInfoObj.getOrDefault("SpouseInformation", "{}").toString());
			attributesXML = attributesXML + "<Q_SPOUSE_INFO>\r\n" + "<SPOUSE_OCCUPATION>"
					+ (String) SpouseInformationObj.get("SpouseOccupation") + "</SPOUSE_OCCUPATION>\r\n"
					+ "<SPOUSE_ANNUAL_INC>" + (String) SpouseInformationObj.get("SpouseAnnualInc")
					+ "</SPOUSE_ANNUAL_INC>\r\n" + "<TOTAL_INSUR_COVER>"
					+ (String) SpouseInformationObj.get("TotalInsurCover") + "</TOTAL_INSUR_COVER>\r\n"
					+ "</Q_SPOUSE_INFO>";

			// TravelInformation
			JSONObject TravelInformationObj = (JSONObject) jsonParser
					.parse(MedicalPrevPolInfoObj.getOrDefault("TravelInformation", "{}").toString());
			attributesXML = attributesXML + "<Q_TRAVEL_INFO>\r\n" + "<TRAVEL_PROP>"
					+ (String) TravelInformationObj.get("TravelProp") + "</TRAVEL_PROP>\r\n" + "<TRAVEL_INSUR>"
					+ (String) TravelInformationObj.get("TravelInsur") + "</TRAVEL_INSUR>\r\n" + "</Q_TRAVEL_INFO>";

			JSONArray CountriesProp = (JSONArray) TravelInformationObj.getOrDefault("CountriesProp", "[]");
			for (Object j : CountriesProp) {
				attributesXML = attributesXML + "<Q_LIST_COUNTRY_PROP>" + j.toString() + "</Q_LIST_COUNTRY_PROP>";
			}

			JSONArray CountriesInsur = (JSONArray) TravelInformationObj.getOrDefault("CountriesInsur", "[]");
			for (Object j : CountriesInsur) {
				attributesXML = attributesXML + "<Q_LIST_COUNTRY_INSUR>" + j.toString() + "</Q_LIST_COUNTRY_INSUR>";
			}
			
			//UnderwriterReview Section
			JSONObject UnderwriterReview = (JSONObject) jsonParser
					.parse(json.getOrDefault("UnderwriterReview", "{}").toString());
			attributesXML = attributesXML + "<Q_DECISION_SECTION_UW>\r\n" +
                    "<AI_Assessed_Income>"
		            + UnderwriterReview.getOrDefault("AIAssessedIncome", "").toString() + "</AI_Assessed_Income>\r\n" +
					 "<Service_Name>"
		            + UnderwriterReview.getOrDefault("ServiceName", "").toString() + "</Service_Name>\r\n"
					
		           + "</Q_DECISION_SECTION_UW>";

			JSONObject GovernDetails = (JSONObject) jsonParser
					.parse(UnderwriterReview.getOrDefault("UwGovernDetails", "{}").toString());
			
			attributesXML = attributesXML + "<Q_GOVERN_DETAILS>\r\n" + "<POLICY_NUMBER>"
					+ GovernDetails.getOrDefault("PolicyNumber", "").toString() + "</POLICY_NUMBER>\r\n" + "<SCORING_DATE>"
					+ GovernDetails.getOrDefault("ScoringDate", "").toString() + "</SCORING_DATE>\r\n"
					+ "<PLAN_CAT>" + GovernDetails.getOrDefault("PlanCat", "").toString()
					+ "</PLAN_CAT>\r\n" + "<CHANNEL>"
					+ GovernDetails.getOrDefault("Channel", "").toString()
					+ "</CHANNEL>\r\n" + "<CALCULATED_MSA>"
					+ GovernDetails.getOrDefault("CalculatedMsa", "").toString() + "</CALCULATED_MSA>\r\n"
					+"<CALCULATED_FSA>"
					+ GovernDetails.getOrDefault("CalculatedFsa", "").toString() + ""
					+ "</CALCULATED_FSA>\r\n"
					+"<GOVERN_API_STATUS>"
					+ GovernDetails.getOrDefault("GuwernApiStatus", "").toString() + ""
					+ "</GOVERN_API_STATUS>\r\n"+"<GOVERN_GRID>"
					+ GovernDetails.getOrDefault("GuwernGrid", "").toString() + ""
					+ "</GOVERN_GRID>\r\n"+"<GOVERN_RESULT>"
					+ GovernDetails.getOrDefault("GuwernResult", "").toString() + ""
					+ "</GOVERN_RESULT>\r\n"+"<REASON_OF_BREACH>"
					+ GovernDetails.getOrDefault("ReasonOfBreach", "").toString() + ""
					+ "</REASON_OF_BREACH>\r\n"+"<MSA_MATCH_RESULT>"
					+ GovernDetails.getOrDefault("MsaMatchResult", "").toString() + ""
					+ "</MSA_MATCH_RESULT>\r\n"+"<FSA_MATCH_RESULT>"
					+ GovernDetails.getOrDefault("FsaMatchResult", "").toString() + ""
					+ "</FSA_MATCH_RESULT>\r\n"+"<MAX_SUC_LIMIT>"
					+ GovernDetails.getOrDefault("MaxSucLimit", "").toString() + ""
					+ "</MAX_SUC_LIMIT>\r\n"+"<SUC_OVER_ISSUED_PERC>"
					+ GovernDetails.getOrDefault("SucOverIssuedPerc", "").toString() + ""
					+ "</SUC_OVER_ISSUED_PERC>\r\n"+"<ERRORCODE>"
					+ GovernDetails.getOrDefault("ErrorCode", "").toString() + ""
					+ "</ERRORCODE>\r\n"+"<ERRORMESSAGE>"
					+ GovernDetails.getOrDefault("ErrorMessage", "").toString() + ""
					+ "</ERRORMESSAGE>\r\n"
                    + "<AI_Recommended_Tag_Initiative>" //DR-46362 Komal
                    + GovernDetails.getOrDefault("AIRecommendedTagInitiative", "").toString() 
                    + "</AI_Recommended_Tag_Initiative>\r\n"	
					+ "</Q_GOVERN_DETAILS>";
			
			// UnderwriterSummarySheet Section
			JSONObject UnderwriterSummaryObj = (JSONObject) jsonParser
					.parse(json.getOrDefault("UnderwriterSummarySheet", "{}").toString());
			attributesXML = attributesXML + "<Q_SUC_PARAMETERES>\r\n" + "<MSA>"
					+ UnderwriterSummaryObj.getOrDefault("MSA", "").toString() + "</MSA>\r\n" + "<FSA>"
					+ UnderwriterSummaryObj.getOrDefault("FSA", "").toString() + "</FSA>\r\n"
					+ "<SUM_UNDER_CONSIDERATION>" + UnderwriterSummaryObj.getOrDefault("SUC", "").toString()
					+ "</SUM_UNDER_CONSIDERATION>\r\n" + "<DD_CI_SA_CLIENT_LEVEL>"
					+ UnderwriterSummaryObj.getOrDefault("SumAssuredClient", "").toString()
					+ "</DD_CI_SA_CLIENT_LEVEL>\r\n" + "<AFYP>"
					+ UnderwriterSummaryObj.getOrDefault("CLIENT_AFYP", "").toString() + "</AFYP>\r\n"
					//added by Prakhar on 31May21
					+"<IIB_FSA>"
					+ UnderwriterSummaryObj.getOrDefault("IIB_FSA", "").toString() + ""
					+ "</IIB_FSA>\r\n"
					+"<INITIATIVE_TYPE_SA>"
					+ UnderwriterSummaryObj.getOrDefault("InitiativeTypeSumAssured", "").toString() + ""
					+ "</INITIATIVE_TYPE_SA>\r\n"
					+ "</Q_SUC_PARAMETERES>";
					
					
			attributesXML = attributesXML + "<Q_LIST_CREDIT_SCORE>\r\n" + "<NAME_BUREAU>"
					+ UnderwriterSummaryObj.getOrDefault("NameOfBureau", "").toString() + "</NAME_BUREAU>\r\n" + "<CREDIT_SCORE>"
					+ UnderwriterSummaryObj.getOrDefault("CreditScore", "").toString() + "</CREDIT_SCORE>\r\n"
					+ "<INCOME_ESTIMATED>" + UnderwriterSummaryObj.getOrDefault("IncomeEstimated", "").toString()
					+ "</INCOME_ESTIMATED>\r\n" + "<CIBIL_SCORE>"
					+ UnderwriterSummaryObj.getOrDefault("TRU_TU_CibilScore", "").toString()
					+ "</CIBIL_SCORE>\r\n" +"<AI_Assessed_Income>"                           //50249 ezaz
					+ UnderwriterSummaryObj.getOrDefault("AIAssessedIncome", "").toString()
					+ "</AI_Assessed_Income>\r\n"
					+ "</Q_LIST_CREDIT_SCORE>";
				
			attributesXML = attributesXML + "<Q_BRMS_MED_GRID_OP>\r\n" + "<GRID_OUTPUT>"
					+ UnderwriterSummaryObj.getOrDefault("MedicalGridOutput", "").toString() + "</GRID_OUTPUT>\r\n"
					+ "<TPA_1_INVOLVED>" + UnderwriterSummaryObj.getOrDefault("TPA1_BRMS", "").toString()
					+ "</TPA_1_INVOLVED>\r\n" + "<TPA_2_INVOLVED>"
					+ UnderwriterSummaryObj.getOrDefault("TPA2_BRMS", "").toString() + "</TPA_2_INVOLVED>\r\n"
					+ "<TPA_3_INVOLVED>" + UnderwriterSummaryObj.getOrDefault("TPA3_BRMS", "").toString()
					+ "</TPA_3_INVOLVED>\r\n" + "</Q_BRMS_MED_GRID_OP>";
			
			attributesXML = attributesXML + "<Q_TPA_DETAILS>\r\n" 
					+ "<TPA_1_INVOLVED>" + UnderwriterSummaryObj.getOrDefault("TPA1", "").toString()
					+ "</TPA_1_INVOLVED>\r\n" + "<TPA_2_INVOLVED>"
					+ UnderwriterSummaryObj.getOrDefault("TPA2", "").toString() + "</TPA_2_INVOLVED>\r\n"
					+ "<TPA_3_INVOLVED>" + UnderwriterSummaryObj.getOrDefault("TPA3", "").toString()
					+ "</TPA_3_INVOLVED>\r\n" + "</Q_TPA_DETAILS>";

			attributesXML = attributesXML + "<Q_BRMS_UW_MOD_OP>\r\n" + "<MISC_MOD_OP>"
					+ UnderwriterSummaryObj.getOrDefault("MiscellaneousModuleOP", "").toString() + "</MISC_MOD_OP>\r\n"
					+ "<PROPOSAL_FORM_MOD_OP>"
					+ UnderwriterSummaryObj.getOrDefault("ProposalFormModuleOP", "").toString()
					+ "</PROPOSAL_FORM_MOD_OP>\r\n" + "<URMU_MOD_OP>"
					+ UnderwriterSummaryObj.getOrDefault("URMUModuleOP", "").toString() + "</URMU_MOD_OP>\r\n"
					+ "<MER_MOD_OP>" + UnderwriterSummaryObj.getOrDefault("MERModuleOP", "").toString()
					+ "</MER_MOD_OP>\r\n" + "<TELE_MER_MOD_OP>"
					+ UnderwriterSummaryObj.getOrDefault("TeleMerModuleOP", "").toString() + "</TELE_MER_MOD_OP>\r\n"
					+ "<BLOOD_PROFILE_MOD_OP>"
					+ UnderwriterSummaryObj.getOrDefault("BloodProfileModuleOP", "").toString()
					+ "</BLOOD_PROFILE_MOD_OP>\r\n" + "<FINANCIAL_MOD_OP>"
					+ UnderwriterSummaryObj.getOrDefault("FinancialModuleOP", "").toString() + "</FINANCIAL_MOD_OP>\r\n"
					+ "</Q_BRMS_UW_MOD_OP>";
	
			//DR-16841 By Sparsh
			//Prop
			JSONArray PreviousPolicyDetails;
			PreviousPolicyDetails = (JSONArray) UnderwriterSummaryObj.getOrDefault("PreviousPolicyDetails",new JSONArray());
			insertionOrderId = 0;
			hashID = 1;

			for (Object j : PreviousPolicyDetails) {
				JSONObject jsonObj = (JSONObject) j;
				attributesXML = attributesXML + "<Q_LIST_PREVIOUS_POLICY_UW>\r\n" + "<InsertionOrderId>"
						+ insertionOrderId + "</InsertionOrderId>" + "<HashId>" + hashID++ + "</HashId>" 
						+ "<PROPOSAL_NUMBER>" + jsonObj.getOrDefault("policyNo","").toString() + "</PROPOSAL_NUMBER>"
						+ "<PLAN_DETAILS>" + jsonObj.getOrDefault("planCode","").toString() + "</PLAN_DETAILS>" 
						+ "<CURRENT_STATUS>" + jsonObj.getOrDefault("baseCoverStatusCode","").toString() + "</CURRENT_STATUS>" 
						+ "<SUM_ASSURED_APPLIED>" + jsonObj.getOrDefault("sumAssured","").toString() + "</SUM_ASSURED_APPLIED>" 
						+ "<ANNUAL_PREMIUM>" + jsonObj.getOrDefault("annualPremium","").toString() + "</ANNUAL_PREMIUM>" 
						+ "<PREMIUM_PAYING_TERM>" + jsonObj.getOrDefault("premiumPayingTerm","").toString() + "</PREMIUM_PAYING_TERM>" 
						+ "<ISSUE_EFFECTIVE_DATE>" + jsonObj.getOrDefault("issueDate","").toString() + "</ISSUE_EFFECTIVE_DATE>" 
						+ "<PREMIUM_PAID_DATE>" + jsonObj.getOrDefault("premiumPaidToDate","").toString() + "</PREMIUM_PAID_DATE>" 
						+ "<LAST_MEDICAL_DATE>" + jsonObj.getOrDefault("lastMedicalDate","").toString() + "</LAST_MEDICAL_DATE>"
						+ "<ATR_FLAG>" + jsonObj.getOrDefault("atrMarked","").toString() + "</ATR_FLAG>" 
						+ "<TRANSFER_EXT_SYSTEM>" + jsonObj.getOrDefault("transferToExternalSystemCode","").toString() + "</TRANSFER_EXT_SYSTEM>"
						+ "<CLAIM_PAID_POLICY>" + jsonObj.getOrDefault("claimPaidRequestedOnAnyPolicyCode","").toString() + "</CLAIM_PAID_POLICY>" 
						+ "<TOTAL_PREMIUM>" + jsonObj.getOrDefault("proposerTotalAnnualPremium","").toString() + "</TOTAL_PREMIUM>" 
						+ "<MONTHLY_INCOME>" + jsonObj.getOrDefault("monthlyIncome","").toString() + "</MONTHLY_INCOME>" 
						+ "<UW_DECISION>" + jsonObj.getOrDefault("uwDecision","").toString() + "</UW_DECISION>" 
						+ "<MODAL_PREMIUM>" + jsonObj.getOrDefault("modelPremium","").toString() + "</MODAL_PREMIUM>" 
						+ "<COUNTER_OFFER>" + jsonObj.getOrDefault("counterOfferStatus","").toString() + "</COUNTER_OFFER>"
						+ "<GO_CODE>" + jsonObj.getOrDefault("channelCode","").toString() + "</GO_CODE>"
						+ "<EMR>" + jsonObj.getOrDefault("emrMultExtraFlatExtraCases","").toString() + "</EMR>" 
						+ "<REPLACEMENT_SALE>" + jsonObj.getOrDefault("replacementSale","").toString() + "</REPLACEMENT_SALE>" 
						+ "<IS_PROPOSER>" + jsonObj.getOrDefault("isProposer","").toString() + "</IS_PROPOSER>" 
						+ "<IS_INSURED>" + jsonObj.getOrDefault("isInsured","").toString() + "</IS_INSURED>" 
						+ "<DEATH_BENEFIT>" + jsonObj.getOrDefault("deathBenefitOption","").toString() + "</DEATH_BENEFIT>" 
						+ "<LIFE_STAGE>" + jsonObj.getOrDefault("lifeEvent","").toString() + "</LIFE_STAGE>" 
						+ "<GUARANTEED_DEATH_BENEFIT>" + jsonObj.getOrDefault("gdb","").toString() + "</GUARANTEED_DEATH_BENEFIT>"
						+ "<POLICY_TERM>" + jsonObj.getOrDefault("policyTerm","").toString() + "</POLICY_TERM>"
						+ "<ATR_COMMENTS>" + jsonObj.getOrDefault("atrComments","").toString() + "</ATR_COMMENTS>"
						+ "<REASON_FOR_COUNTER>" + jsonObj.getOrDefault("reasonForCoDecCanPst","").toString() + "</REASON_FOR_COUNTER>"		
						+ "</Q_LIST_PREVIOUS_POLICY_UW>";
			}
			// Insur
			JSONArray PreviousPolicyDetailsInsuredDetails;
			PreviousPolicyDetailsInsuredDetails = (JSONArray) UnderwriterSummaryObj.getOrDefault("PreviousPolicyDetailsInsured",new JSONArray());
			insertionOrderId = 0;
			hashID = 1;

			for (Object j : PreviousPolicyDetailsInsuredDetails) {
				JSONObject jsonObj = (JSONObject) j;
				attributesXML = attributesXML + "<Q_LIST_PREVIOUS_POLICY_INSURED>\r\n" + "<InsertionOrderId>"
						+ insertionOrderId + "</InsertionOrderId>" + "<HashId>" + hashID++ + "</HashId>" 
						+ "<PROPOSAL_NUMBER>" + jsonObj.getOrDefault("policyNo","").toString() + "</PROPOSAL_NUMBER>"
						+ "<PLAN_DETAILS>" + jsonObj.getOrDefault("planCode","").toString() + "</PLAN_DETAILS>" 
						+ "<CURRENT_STATUS>" + jsonObj.getOrDefault("baseCoverStatusCode","").toString() + "</CURRENT_STATUS>" 
						+ "<SUM_ASSURED_APPLIED>" + jsonObj.getOrDefault("sumAssured","").toString() + "</SUM_ASSURED_APPLIED>" 
						+ "<ANNUAL_PREMIUM>" + jsonObj.getOrDefault("annualPremium","").toString() + "</ANNUAL_PREMIUM>" 
						+ "<PREMIUM_PAYING_TERM>" + jsonObj.getOrDefault("premiumPayingTerm","").toString() + "</PREMIUM_PAYING_TERM>" 
						+ "<ISSUE_EFFECTIVE_DATE>" + jsonObj.getOrDefault("issueDate","").toString() + "</ISSUE_EFFECTIVE_DATE>" 
						+ "<PREMIUM_PAID_DATE>" + jsonObj.getOrDefault("premiumPaidToDate","").toString() + "</PREMIUM_PAID_DATE>" 
						+ "<LAST_MEDICAL_DATE>" + jsonObj.getOrDefault("lastMedicalDate","").toString() + "</LAST_MEDICAL_DATE>"
						+ "<ATR_FLAG>" + jsonObj.getOrDefault("atrMarked","").toString() + "</ATR_FLAG>" 
						+ "<TRANSFER_EXT_SYSTEM>" + jsonObj.getOrDefault("transferToExternalSystemCode","").toString() + "</TRANSFER_EXT_SYSTEM>"
						+ "<CLAIM_PAID_POLICY>" + jsonObj.getOrDefault("claimPaidRequestedOnAnyPolicyCode","").toString() + "</CLAIM_PAID_POLICY>" 
						+ "<TOTAL_PREMIUM>" + jsonObj.getOrDefault("proposerTotalAnnualPremium","").toString() + "</TOTAL_PREMIUM>" 
						+ "<MONTHLY_INCOME>" + jsonObj.getOrDefault("monthlyIncome","").toString() + "</MONTHLY_INCOME>" 
						+ "<UW_DECISION>" + jsonObj.getOrDefault("uwDecision","").toString() + "</UW_DECISION>" 
						+ "<MODAL_PREMIUM>" + jsonObj.getOrDefault("modelPremium","").toString() + "</MODAL_PREMIUM>" 
						+ "<COUNTER_OFFER>" + jsonObj.getOrDefault("counterOfferStatus","").toString() + "</COUNTER_OFFER>"
						+ "<GO_CODE>" + jsonObj.getOrDefault("channelCode","").toString() + "</GO_CODE>"
						+ "<EMR>" + jsonObj.getOrDefault("emrMultExtraFlatExtraCases","").toString() + "</EMR>" 
						+ "<REPLACEMENT_SALE>" + jsonObj.getOrDefault("replacementSale","").toString() + "</REPLACEMENT_SALE>" 
						+ "<IS_PROPOSER>" + jsonObj.getOrDefault("isProposer","").toString() + "</IS_PROPOSER>" 
						+ "<IS_INSURED>" + jsonObj.getOrDefault("isInsured","").toString() + "</IS_INSURED>" 
						+ "<DEATH_BENEFIT>" + jsonObj.getOrDefault("deathBenefitOption","").toString() + "</DEATH_BENEFIT>" 
						+ "<LIFE_STAGE>" + jsonObj.getOrDefault("lifeEvent","").toString() + "</LIFE_STAGE>" 
						+ "<GUARANTEED_DEATH_BENEFIT>" + jsonObj.getOrDefault("gdb","").toString() + "</GUARANTEED_DEATH_BENEFIT>"
						+ "<POLICY_TERM>" + jsonObj.getOrDefault("policyTerm","").toString() + "</POLICY_TERM>"
						+ "<ATR_COMMENTS>" + jsonObj.getOrDefault("atrComments","").toString() + "</ATR_COMMENTS>"
						+ "<REASON_FOR_COUNTER>" + jsonObj.getOrDefault("reasonForCoDecCanPst","").toString() + "</REASON_FOR_COUNTER>"				
						+ "</Q_LIST_PREVIOUS_POLICY_INSURED>";
			}
			
			//PROP
			JSONObject UW_PROP = (JSONObject) jsonParser
					.parse(UnderwriterSummaryObj.getOrDefault("ProposerDetails", "{}").toString());
			attributesXML = attributesXML + "<Q_SUC_PARAMETERS_PROP>\r\n" + "<MSA>"
					+ UW_PROP.getOrDefault("MSA", "").toString() + "</MSA>\r\n" + "<FSA>"
					+ UW_PROP.getOrDefault("FSA", "").toString() + "</FSA>\r\n"
					+ "<SUM_UNDER_CONSIDERATION>" + UW_PROP.getOrDefault("SUC", "").toString()
					+ "</SUM_UNDER_CONSIDERATION>\r\n" + "<DD_CI_SA_CLIENT_LEVEL>"
					+ UW_PROP.getOrDefault("SumAssuredClient", "").toString()
					+ "</DD_CI_SA_CLIENT_LEVEL>\r\n" + "<AFYP>"
					+ UW_PROP.getOrDefault("CLIENT_AFYP", "").toString() + "</AFYP>\r\n"
							+"<INITIATIVE_TYPE_SA>"
							+ UW_PROP.getOrDefault("InitiativeTypeSumAssured", "").toString() + ""
							+ "</INITIATIVE_TYPE_SA>\r\n"
					+ "</Q_SUC_PARAMETERS_PROP>";
					
					
					
			attributesXML = attributesXML + "<Q_LIST_CREDIT_SCORE_PROP>\r\n" + "<NAME_BUREAU>"
					+ UW_PROP.getOrDefault("NameOfBureau", "").toString() + "</NAME_BUREAU>\r\n" + "<CREDIT_SCORE>"
					+ UW_PROP.getOrDefault("CreditScore", "").toString() + "</CREDIT_SCORE>\r\n"
					+ "<INCOME_ESTIMATED>" + UW_PROP.getOrDefault("IncomeEstimated", "").toString()
					+ "</INCOME_ESTIMATED>\r\n" + "<CIBIL_SCORE>"
					+ UW_PROP.getOrDefault("TRU_TU_CibilScore", "").toString()
					+ "</CIBIL_SCORE>\r\n" +"<AI_Assessed_Income>"
					+ UW_PROP.getOrDefault("AIAssessedIncomeProp", "").toString() //50249 ezaz
					+ "</AI_Assessed_Income>\r\n" 
					+ "</Q_LIST_CREDIT_SCORE_PROP>";

			attributesXML = attributesXML + "<Q_BRMS_MED_GRID_OP_PROP>\r\n" + "<GRID_OUTPUT>"
					+ UW_PROP.getOrDefault("MedicalGridOutput", "").toString() + "</GRID_OUTPUT>\r\n"
					+ "<TPA_1_INVOLVED>" + UW_PROP.getOrDefault("TPA1_BRMS", "").toString()
					+ "</TPA_1_INVOLVED>\r\n" + "<TPA_2_INVOLVED>"
					+ UW_PROP.getOrDefault("TPA2_BRMS", "").toString() + "</TPA_2_INVOLVED>\r\n"
					+ "<TPA_3_INVOLVED>" + UW_PROP.getOrDefault("TPA3_BRMS", "").toString()
					+ "</TPA_3_INVOLVED>\r\n" + "</Q_BRMS_MED_GRID_OP_PROP>";
			
			attributesXML = attributesXML + "<Q_TPA_DETAILS_PROP>\r\n" 
					+ "<TPA_1_INVOLVED>" + UnderwriterSummaryObj.getOrDefault("TPA1", "").toString()
					+ "</TPA_1_INVOLVED>\r\n" + "<TPA_2_INVOLVED>"
					+ UnderwriterSummaryObj.getOrDefault("TPA2", "").toString() + "</TPA_2_INVOLVED>\r\n"
					+ "<TPA_3_INVOLVED>" + UnderwriterSummaryObj.getOrDefault("TPA3", "").toString()
					+ "</TPA_3_INVOLVED>\r\n" + "</Q_TPA_DETAILS_PROP>";

			attributesXML = attributesXML + "<Q_BRMS_UW_MOD_OP_PROP>\r\n" + "<MISC_MOD_OP>"
					+ UW_PROP.getOrDefault("MiscellaneousModuleOP", "").toString() + "</MISC_MOD_OP>\r\n"
					+ "<PROPOSAL_FORM_MOD_OP>"
					+ UW_PROP.getOrDefault("ProposalFormModuleOP", "").toString()
					+ "</PROPOSAL_FORM_MOD_OP>\r\n" + "<URMU_MOD_OP>"
					+ UW_PROP.getOrDefault("URMUModuleOP", "").toString() + "</URMU_MOD_OP>\r\n"
					+ "<MER_MOD_OP>" + UW_PROP.getOrDefault("MERModuleOP", "").toString()
					+ "</MER_MOD_OP>\r\n" + "<TELE_MER_MOD_OP>"
					+ UW_PROP.getOrDefault("TeleMerModuleOP", "").toString() + "</TELE_MER_MOD_OP>\r\n"
					+ "<BLOOD_PROFILE_MOD_OP>"
					+ UW_PROP.getOrDefault("BloodProfileModuleOP", "").toString()
					+ "</BLOOD_PROFILE_MOD_OP>\r\n" + "<FINANCIAL_MOD_OP>"
					+ UW_PROP.getOrDefault("FinancialModuleOP", "").toString() + "</FINANCIAL_MOD_OP>\r\n"
					+ "</Q_BRMS_UW_MOD_OP_PROP>";
			
			//Prop
			JSONArray PreviousPolicyDetailsProp;
			PreviousPolicyDetailsProp = (JSONArray) UW_PROP.getOrDefault("PreviousPolicyDetails",new JSONArray());
			insertionOrderId = 0;
			hashID = 1;

			for (Object j : PreviousPolicyDetailsProp) {
				JSONObject jsonObj = (JSONObject) j;
				attributesXML = attributesXML + "<Q_LIST_PREVIOUS_POLICY_UW_PROP>\r\n" + "<InsertionOrderId>"
						+ insertionOrderId + "</InsertionOrderId>" + "<HashId>" + hashID++ + "</HashId>" 
						+ "<PROPOSAL_NUMBER>" + jsonObj.getOrDefault("policyNo","").toString() + "</PROPOSAL_NUMBER>"
						+ "<PLAN_DETAILS>" + jsonObj.getOrDefault("planCode","").toString() + "</PLAN_DETAILS>" 
						+ "<CURRENT_STATUS>" + jsonObj.getOrDefault("baseCoverStatusCode","").toString() + "</CURRENT_STATUS>" 
						+ "<SUM_ASSURED_APPLIED>" + jsonObj.getOrDefault("sumAssured","").toString() + "</SUM_ASSURED_APPLIED>" 
						+ "<ANNUAL_PREMIUM>" + jsonObj.getOrDefault("annualPremium","").toString() + "</ANNUAL_PREMIUM>" 
						+ "<PREMIUM_PAYING_TERM>" + jsonObj.getOrDefault("premiumPayingTerm","").toString() + "</PREMIUM_PAYING_TERM>" 
						+ "<ISSUE_EFFECTIVE_DATE>" + jsonObj.getOrDefault("issueDate","").toString() + "</ISSUE_EFFECTIVE_DATE>" 
						+ "<PREMIUM_PAID_DATE>" + jsonObj.getOrDefault("premiumPaidToDate","").toString() + "</PREMIUM_PAID_DATE>" 
						+ "<LAST_MEDICAL_DATE>" + jsonObj.getOrDefault("lastMedicalDate","").toString() + "</LAST_MEDICAL_DATE>"
						+ "<ATR_FLAG>" + jsonObj.getOrDefault("atrMarked","").toString() + "</ATR_FLAG>" 
						+ "<TRANSFER_EXT_SYSTEM>" + jsonObj.getOrDefault("transferToExternalSystemCode","").toString() + "</TRANSFER_EXT_SYSTEM>"
						+ "<CLAIM_PAID_POLICY>" + jsonObj.getOrDefault("claimPaidRequestedOnAnyPolicyCode","").toString() + "</CLAIM_PAID_POLICY>" 
						+ "<TOTAL_PREMIUM>" + jsonObj.getOrDefault("proposerTotalAnnualPremium","").toString() + "</TOTAL_PREMIUM>" 
						+ "<MONTHLY_INCOME>" + jsonObj.getOrDefault("monthlyIncome","").toString() + "</MONTHLY_INCOME>" 
						+ "<UW_DECISION>" + jsonObj.getOrDefault("uwDecision","").toString() + "</UW_DECISION>" 
						+ "<MODAL_PREMIUM>" + jsonObj.getOrDefault("modelPremium","").toString() + "</MODAL_PREMIUM>" 
						+ "<COUNTER_OFFER>" + jsonObj.getOrDefault("counterOfferStatus","").toString() + "</COUNTER_OFFER>"
						+ "<GO_CODE>" + jsonObj.getOrDefault("channelCode","").toString() + "</GO_CODE>"
						+ "<EMR>" + jsonObj.getOrDefault("emrMultExtraFlatExtraCases","").toString() + "</EMR>" 
						+ "<REPLACEMENT_SALE>" + jsonObj.getOrDefault("replacementSale","").toString() + "</REPLACEMENT_SALE>" 
						+ "<IS_PROPOSER>" + jsonObj.getOrDefault("isProposer","").toString() + "</IS_PROPOSER>" 
						+ "<IS_INSURED>" + jsonObj.getOrDefault("isInsured","").toString() + "</IS_INSURED>" 
						+ "<DEATH_BENEFIT>" + jsonObj.getOrDefault("deathBenefitOption","").toString() + "</DEATH_BENEFIT>" 
						+ "<LIFE_STAGE>" + jsonObj.getOrDefault("lifeEvent","").toString() + "</LIFE_STAGE>" 
						+ "<GUARANTEED_DEATH_BENEFIT>" + jsonObj.getOrDefault("gdb","").toString() + "</GUARANTEED_DEATH_BENEFIT>"
						+ "<POLICY_TERM>" + jsonObj.getOrDefault("policyTerm","").toString() + "</POLICY_TERM>"
						+ "<ATR_COMMENTS>" + jsonObj.getOrDefault("atrComments","").toString() + "</ATR_COMMENTS>"
						+ "<REASON_FOR_COUNTER>" + jsonObj.getOrDefault("reasonForCoDecCanPst","").toString() + "</REASON_FOR_COUNTER>"	
						+ "</Q_LIST_PREVIOUS_POLICY_UW_PROP>";
			}
			//PROP
			//INSUR
			JSONObject UW_L2bi = (JSONObject) jsonParser
					.parse(UnderwriterSummaryObj.getOrDefault("L2BIDetails", "{}").toString());
			attributesXML = attributesXML + "<Q_SUC_PARAMETERS_INSUR>\r\n" + "<MSA>"
					+ UW_L2bi.getOrDefault("MSA", "").toString() + "</MSA>\r\n" + "<FSA>"
					+ UW_L2bi.getOrDefault("FSA", "").toString() + "</FSA>\r\n"
					+ "<SUM_UNDER_CONSIDERATION>" + UW_L2bi.getOrDefault("SUC", "").toString()
					+ "</SUM_UNDER_CONSIDERATION>\r\n" + "<DD_CI_SA_CLIENT_LEVEL>"
					+ UW_L2bi.getOrDefault("SumAssuredClient", "").toString()
					+ "</DD_CI_SA_CLIENT_LEVEL>\r\n" + "<AFYP>"
					+ UW_L2bi.getOrDefault("CLIENT_AFYP", "").toString() + "</AFYP>\r\n"
							+"<INITIATIVE_TYPE_SA>"
							+ UW_L2bi.getOrDefault("InitiativeTypeSumAssured", "").toString() + ""
							+ "</INITIATIVE_TYPE_SA>\r\n"
					+ "</Q_SUC_PARAMETERS_INSUR>";
			
			attributesXML = attributesXML + "<Q_LIST_CREDIT_SCORE_INSUR>\r\n" + "<NAME_BUREAU>"
					+ UW_L2bi.getOrDefault("NameOfBureau", "").toString() + "</NAME_BUREAU>\r\n" + "<CREDIT_SCORE>"
					+ UW_L2bi.getOrDefault("CreditScore", "").toString() + "</CREDIT_SCORE>\r\n"
					+ "<INCOME_ESTIMATED>" + UW_L2bi.getOrDefault("IncomeEstimated", "").toString()
					+ "</INCOME_ESTIMATED>\r\n" + "<CIBIL_SCORE>"
					+ UW_L2bi.getOrDefault("TRU_TU_CibilScore", "").toString()
					+ "</CIBIL_SCORE>\r\n" +"<AI_Assessed_Income>"
					+ UW_L2bi.getOrDefault("AIAssessedIncomeInsur", "").toString()     //50249 ezaz
					+ "</AI_Assessed_Income>\r\n"
					+ "</Q_LIST_CREDIT_SCORE_INSUR>";					
			
			attributesXML = attributesXML + "<Q_BRMS_MED_GRID_OP_INSUR>\r\n" + "<GRID_OUTPUT>"
					+ UW_L2bi.getOrDefault("MedicalGridOutput", "").toString() + "</GRID_OUTPUT>\r\n"
					+ "<TPA_1_INVOLVED>" + UW_L2bi.getOrDefault("TPA1_BRMS", "").toString()
					+ "</TPA_1_INVOLVED>\r\n" + "<TPA_2_INVOLVED>"
					+ UW_L2bi.getOrDefault("TPA2_BRMS", "").toString() + "</TPA_2_INVOLVED>\r\n"
					+ "<TPA_3_INVOLVED>" + UW_L2bi.getOrDefault("TPA3_BRMS", "").toString()
					+ "</TPA_3_INVOLVED>\r\n" + "</Q_BRMS_MED_GRID_OP_INSUR>";
			
			
			attributesXML = attributesXML + "<Q_TPA_DETAILS_INSUR>\r\n" 
					+ "<TPA_1_INVOLVED>" + UnderwriterSummaryObj.getOrDefault("TPA1", "").toString()
					+ "</TPA_1_INVOLVED>\r\n" + "<TPA_2_INVOLVED>"
					+ UnderwriterSummaryObj.getOrDefault("TPA2", "").toString() + "</TPA_2_INVOLVED>\r\n"
					+ "<TPA_3_INVOLVED>" + UnderwriterSummaryObj.getOrDefault("TPA3", "").toString()
					+ "</TPA_3_INVOLVED>\r\n" + "</Q_TPA_DETAILS_INSUR>";

			attributesXML = attributesXML + "<Q_BRMS_UW_MOD_OP_INSUR>\r\n" + "<MISC_MOD_OP>"
					+ UW_L2bi.getOrDefault("MiscellaneousModuleOP", "").toString() + "</MISC_MOD_OP>\r\n"
					+ "<PROPOSAL_FORM_MOD_OP>"
					+ UW_L2bi.getOrDefault("ProposalFormModuleOP", "").toString()
					+ "</PROPOSAL_FORM_MOD_OP>\r\n" + "<URMU_MOD_OP>"
					+ UW_L2bi.getOrDefault("URMUModuleOP", "").toString() + "</URMU_MOD_OP>\r\n"
					+ "<MER_MOD_OP>" + UW_L2bi.getOrDefault("MERModuleOP", "").toString()
					+ "</MER_MOD_OP>\r\n" + "<TELE_MER_MOD_OP>"
					+ UW_L2bi.getOrDefault("TeleMerModuleOP", "").toString() + "</TELE_MER_MOD_OP>\r\n"
					+ "<BLOOD_PROFILE_MOD_OP>"
					+ UW_L2bi.getOrDefault("BloodProfileModuleOP", "").toString()
					+ "</BLOOD_PROFILE_MOD_OP>\r\n" + "<FINANCIAL_MOD_OP>"
					+ UW_L2bi.getOrDefault("FinancialModuleOP", "").toString() + "</FINANCIAL_MOD_OP>\r\n"
					+ "</Q_BRMS_UW_MOD_OP_INSUR>";
			
			JSONArray PreviousPolicyDetailsInsured;
			PreviousPolicyDetailsInsured = (JSONArray) UW_L2bi.getOrDefault("PreviousPolicyDetails",new JSONArray());
			insertionOrderId = 0;
			hashID = 1;

			for (Object j : PreviousPolicyDetailsInsured) {
				JSONObject jsonObj = (JSONObject) j;
				attributesXML = attributesXML + "<Q_LIST_PREVIOUS_POLICY_UW_INSUR>\r\n" + "<InsertionOrderId>"
						+ insertionOrderId + "</InsertionOrderId>" + "<HashId>" + hashID++ + "</HashId>" 
						+ "<PROPOSAL_NUMBER>" + jsonObj.getOrDefault("policyNo","").toString() + "</PROPOSAL_NUMBER>"
						+ "<PLAN_DETAILS>" + jsonObj.getOrDefault("planCode","").toString() + "</PLAN_DETAILS>" 
						+ "<CURRENT_STATUS>" + jsonObj.getOrDefault("baseCoverStatusCode","").toString() + "</CURRENT_STATUS>" 
						+ "<SUM_ASSURED_APPLIED>" + jsonObj.getOrDefault("sumAssured","").toString() + "</SUM_ASSURED_APPLIED>" 
						+ "<ANNUAL_PREMIUM>" + jsonObj.getOrDefault("annualPremium","").toString() + "</ANNUAL_PREMIUM>" 
						+ "<PREMIUM_PAYING_TERM>" + jsonObj.getOrDefault("premiumPayingTerm","").toString() + "</PREMIUM_PAYING_TERM>" 
						+ "<ISSUE_EFFECTIVE_DATE>" + jsonObj.getOrDefault("issueDate","").toString() + "</ISSUE_EFFECTIVE_DATE>" 
						+ "<PREMIUM_PAID_DATE>" + jsonObj.getOrDefault("premiumPaidToDate","").toString() + "</PREMIUM_PAID_DATE>" 
						+ "<LAST_MEDICAL_DATE>" + jsonObj.getOrDefault("lastMedicalDate","").toString() + "</LAST_MEDICAL_DATE>"
						+ "<ATR_FLAG>" + jsonObj.getOrDefault("atrMarked","").toString() + "</ATR_FLAG>" 
						+ "<TRANSFER_EXT_SYSTEM>" + jsonObj.getOrDefault("transferToExternalSystemCode","").toString() + "</TRANSFER_EXT_SYSTEM>"
						+ "<CLAIM_PAID_POLICY>" + jsonObj.getOrDefault("claimPaidRequestedOnAnyPolicyCode","").toString() + "</CLAIM_PAID_POLICY>" 
						+ "<TOTAL_PREMIUM>" + jsonObj.getOrDefault("proposerTotalAnnualPremium","").toString() + "</TOTAL_PREMIUM>" 
						+ "<MONTHLY_INCOME>" + jsonObj.getOrDefault("monthlyIncome","").toString() + "</MONTHLY_INCOME>" 
						+ "<UW_DECISION>" + jsonObj.getOrDefault("uwDecision","").toString() + "</UW_DECISION>" 
						+ "<MODAL_PREMIUM>" + jsonObj.getOrDefault("modelPremium","").toString() + "</MODAL_PREMIUM>" 
						+ "<COUNTER_OFFER>" + jsonObj.getOrDefault("counterOfferStatus","").toString() + "</COUNTER_OFFER>"
						+ "<GO_CODE>" + jsonObj.getOrDefault("channelCode","").toString() + "</GO_CODE>"
						+ "<EMR>" + jsonObj.getOrDefault("emrMultExtraFlatExtraCases","").toString() + "</EMR>" 
						+ "<REPLACEMENT_SALE>" + jsonObj.getOrDefault("replacementSale","").toString() + "</REPLACEMENT_SALE>" 
						+ "<IS_PROPOSER>" + jsonObj.getOrDefault("isProposer","").toString() + "</IS_PROPOSER>" 
						+ "<IS_INSURED>" + jsonObj.getOrDefault("isInsured","").toString() + "</IS_INSURED>" 
						+ "<DEATH_BENEFIT>" + jsonObj.getOrDefault("deathBenefitOption","").toString() + "</DEATH_BENEFIT>" 
						+ "<LIFE_STAGE>" + jsonObj.getOrDefault("lifeEvent","").toString() + "</LIFE_STAGE>" 
						+ "<GUARANTEED_DEATH_BENEFIT>" + jsonObj.getOrDefault("gdb","").toString() + "</GUARANTEED_DEATH_BENEFIT>"
						+ "<POLICY_TERM>" + jsonObj.getOrDefault("policyTerm","").toString() + "</POLICY_TERM>"
						+ "<ATR_COMMENTS>" + jsonObj.getOrDefault("atrComments","").toString() + "</ATR_COMMENTS>"
						+ "<REASON_FOR_COUNTER>" + jsonObj.getOrDefault("reasonForCoDecCanPst","").toString() + "</REASON_FOR_COUNTER>"	
						+ "</Q_LIST_PREVIOUS_POLICY_UW_INSUR>";
			}

			//INSUR
			
			//URMU SUMMARY
			JSONObject URMUSummarySheet = (JSONObject) jsonParser
					.parse(json.getOrDefault("URMUSummarySheet", "{}").toString());
			
			JSONArray IIBDETAILS;
			IIBDETAILS = (JSONArray) URMUSummarySheet.getOrDefault("IIBDetails",new JSONArray());
			insertionOrderId = 0;
			hashID = 1;

			for (Object j : IIBDETAILS) {
				JSONObject jsonObj = (JSONObject) j;

				attributesXML = attributesXML + "<Q_LIST_IIB_DETAILS>\r\n" + "<InsertionOrderId>" + insertionOrderId
						+ "</InsertionOrderId>\r\n" + "<HashId>" + hashID++ + "</HashId>\r\n" + "<COMPANY_NAME>"
						+ jsonObj.getOrDefault("CompanyName","").toString() + "</COMPANY_NAME>" +  "<POLICY_NO>"  //aacnhal
						+ jsonObj.getOrDefault("PolicyNo","").toString() + "</POLICY_NO>" +"<SUM_ASSURED>"
						+ jsonObj.getOrDefault("SumAssured","").toString() + "</SUM_ASSURED>\r\n" + "<COMMENCEMENT_DATE>"
						+ jsonObj.getOrDefault("CommencementDate","").toString() + "</COMMENCEMENT_DATE>\r\n" + "<POLICY_STATUS>"
						+ jsonObj.getOrDefault("PolicyStatus","").toString() + "</POLICY_STATUS>\r\n" + "<MATCH_PARAMETER>"
						+ jsonObj.getOrDefault("MatchParameter","").toString() + "</MATCH_PARAMETER>\r\n" + "<SUBMISSION_DATE>"
						+ jsonObj.getOrDefault("SubmissionDate","").toString() + "</SUBMISSION_DATE>\r\n" + "<DATE_OF_EXIST>"
						+ jsonObj.getOrDefault("DateOfExist","").toString() + "</DATE_OF_EXIST>\r\n" + "<DATE_OF_DEATH>"
						+ jsonObj.getOrDefault("DateOfDeath","").toString() + "</DATE_OF_DEATH>\r\n" + "<CAUSE_OF_DEATH>"
						+ jsonObj.getOrDefault("CauseOfDeath","").toString() + "</CAUSE_OF_DEATH>\r\n" + "<ENTITY_CAUTION_STATUS>"
						+ jsonObj.getOrDefault("EntityCautionStatus","").toString() + "</ENTITY_CAUTION_STATUS>\r\n" + "<INTERM_CAUTION_STATUS>"
						+ jsonObj.getOrDefault("IntermediaryCautionStatus","").toString() + "</INTERM_CAUTION_STATUS>\r\n" + "<IS_NEG_MATCH>"
						+ jsonObj.getOrDefault("IsNegativeMatch","").toString() + "</IS_NEG_MATCH>\r\n" + "<RECORD_LAST_UPD>"
						+ jsonObj.getOrDefault("RecordLastUpdated","").toString() + "</RECORD_LAST_UPD>\r\n" +
						
						"<PRODUCT_TYPE>"
						+ jsonObj.getOrDefault("ProductType","").toString() + "</PRODUCT_TYPE>\r\n" +
						"<MEDICAL_NONMEDICAL>"
						+ jsonObj.getOrDefault("MedicalNonMedical","").toString() + "</MEDICAL_NONMEDICAL>\r\n" +
						"<LINKED_NONLINKED>"
						+ jsonObj.getOrDefault("LinkedNonLinked","").toString() + "</LINKED_NONLINKED>\r\n" +
						"<WHETHER_STANDARDLIFE>"
						+ jsonObj.getOrDefault("WhetherStandardLife","").toString() + "</WHETHER_STANDARDLIFE>\r\n" +
						"<REASON_FOR_DECLINE>"
						+ jsonObj.getOrDefault("ReasonForDecline","").toString() + "</REASON_FOR_DECLINE>\r\n" +
						"<REASON_FOR_POSTPONE>"
						+ jsonObj.getOrDefault("ReasonForPostpone","").toString() + "</REASON_FOR_POSTPONE>\r\n" +
						"<REASON_FOR_REPUDIATION>"
						+ jsonObj.getOrDefault("ReasonForRepudiation","").toString() + "</REASON_FOR_REPUDIATION>\r\n" +
						
						
						// "<REQD_MODAL_PREMIUM>"+jsonObj.get("RequriedModalPremium").toString()+"</REQD_MODAL_PREMIUM>\r\n"
						// +
						// "<TOTAL_REQD_PREMIUM>"+jsonObj.get("TotalRequiredPremium").toString()+"</TOTAL_REQD_PREMIUM>\r\n"
						// +
						// "<AFYP>"+jsonObj.get("AFYP").toString()+"</AFYP>\r\n"
						// +
						"</Q_LIST_IIB_DETAILS>";
			}
			hashID = 1;
			//added by Prakhar on 31May21
			/*attributesXML = attributesXML 
					+ "<Q_LIST_IIB_DETAILS>\r\n" 
						+ "<COMPANY_NAME>"
						+ UnderwriterSummaryObj.getOrDefault("CompanyName", "").toString() 
						+ "</COMPANY_NAME>\r\n"
						+ "<POLICY_NO>"
						+ UnderwriterSummaryObj.getOrDefault("PolicyNo", "").toString()
						+ "</POLICY_NO>\r\n" 
						+ "<SUM_ASSURED>"
						+ UnderwriterSummaryObj.getOrDefault("SumAssured", "").toString() 
						+ "</SUM_ASSURED>\r\n"
						+ "<COMMENCEMENT_DATE>" 
						+ UnderwriterSummaryObj.getOrDefault("CommencementDate", "").toString()
						+ "</COMMENCEMENT_DATE>\r\n" 
						+ "<POLICY_STATUS>"
						+ UnderwriterSummaryObj.getOrDefault("PolicyStatus", "").toString() 
						+ "</POLICY_STATUS>\r\n"
						+ "<MATCH_PARAMETER>"
						+ UnderwriterSummaryObj.getOrDefault("MatchParameter", "").toString()
						+ "</MATCH_PARAMETER>\r\n" 
						+ "<SUBMISSION_DATE>"
						+ UnderwriterSummaryObj.getOrDefault("SubmissionDate", "").toString() 
						+ "</MATCH_PARAMETER>\r\n"
					+ "</Q_LIST_IIB_DETAILS>";*/
			JSONObject MortalityRelated = (JSONObject) jsonParser
					.parse(URMUSummarySheet.getOrDefault("MortalityRelated", "{}").toString());
			attributesXML = attributesXML 
					+ "<Q_MORTALITY_RELATED>\r\n" 
						+ "<SHIELD_MODULE_SCORE>"
						+ MortalityRelated.getOrDefault("ShieldModuleScore", "").toString() 
						+ "</SHIELD_MODULE_SCORE>\r\n"
						+ "<IIB_KICKOUT>"
						+ MortalityRelated.getOrDefault("IIBKickout", "").toString()
						+ "</IIB_KICKOUT>\r\n" 
						+ "<IIB_PRISM_SCORE>"
						+ MortalityRelated.getOrDefault("IIBPrismScore", "").toString() 
						+ "</IIB_PRISM_SCORE>\r\n"	
						+ "<URMU_MODULE_KICKOUT>" 
						+ MortalityRelated.getOrDefault("UrmuModuleKickout", "").toString()
						+ "</URMU_MODULE_KICKOUT>\r\n" 
						+ "<SHIELD_MODULE_CATEGORY>"
						+ MortalityRelated.getOrDefault("ShieldModuleCategory", "").toString() 
						+ "</SHIELD_MODULE_CATEGORY>\r\n"
						+ "<VIDEO_POSV>"
						+ MortalityRelated.getOrDefault("VideoPOSV", "").toString() 
						+ "</VIDEO_POSV>\r\n"
						+ "<SHIELD_MODULE_SCORE_COMBO>"
						+ MortalityRelated.getOrDefault("ShieldModuleScoreCombo", "").toString() 
						+ "</SHIELD_MODULE_SCORE_COMBO>\r\n"
						+ "<URMU_MODULE_KICKOUT_COMBO>"
						+ MortalityRelated.getOrDefault("UrmuModuleKickoutCombo", "").toString() 
						+ "</URMU_MODULE_KICKOUT_COMBO>\r\n"
						+ "<SHIELD_MODULE_CATEGORY_COMBO>"
						+ MortalityRelated.getOrDefault("ShieldModuleCategoryCombo", "").toString() 
						+ "</SHIELD_MODULE_CATEGORY_COMBO>\r\n"
						+ "<PB_MODEL_RISK_SCORE>" //DR-46347 Ajay Start
                        + MortalityRelated.getOrDefault("pbModelRiskScore", "").toString() 
                        + "</PB_MODEL_RISK_SCORE>\r\n"						
                        + "<FACE_MATCH_SCORE>"
                        + MortalityRelated.getOrDefault("faceMatchScore", "").toString() 
                        + "</FACE_MATCH_SCORE>\r\n"
                        + "<FACE_MATCH_REMARKS>"
                        + MortalityRelated.getOrDefault("faceMatchRemarks", "").toString() 
                        + "</FACE_MATCH_REMARKS>\r\n"
                        + "<VOICE_MATCH_SCORE>"
                        + MortalityRelated.getOrDefault("voiceMatchScore", "").toString() 
                        + "</VOICE_MATCH_SCORE>\r\n"
                        + "<VOICE_MATCH_REMARKS>"
                        + MortalityRelated.getOrDefault("voiceMatchRemarks", "").toString() 
                        + "</VOICE_MATCH_REMARKS>\r\n"
                        + "<PB_UW_STATUS>"
                        + MortalityRelated.getOrDefault("pbUwStatus", "").toString() 
                        + "</PB_UW_STATUS>\r\n"
                        + "<PB_QC_FINAL_REMARKS>"
                        + MortalityRelated.getOrDefault("pbQcFinalRemarks", "").toString() 
                        + "</PB_QC_FINAL_REMARKS>\r\n"	 //DR-46347 Ajay End
					+ "</Q_MORTALITY_RELATED>";
			//added by Prakhar ends
			
			// QCSummary Failed Tags
			
			
			JSONObject QCSummaryObj = (JSONObject) jsonParser.parse(json.getOrDefault("QCSummary", "{}").toString());
			attributesXML = attributesXML + "<Q_FAILED_TAGS>\r\n" + "<CurrAddProofProp>"
					+ QCSummaryObj.getOrDefault("CurrAddProofProp", "").toString() + "</CurrAddProofProp>\r\n"
					+ "<IdDobProofProp>" + QCSummaryObj.getOrDefault("IdDobProofProp", "").toString()
					+ "</IdDobProofProp>\r\n" + "<IncomeProofProp>"
					+ QCSummaryObj.getOrDefault("IncomeProofProp", "").toString() + "</IncomeProofProp>\r\n"
					+ "<NachRequiredProp>" + QCSummaryObj.getOrDefault("NachRequiredProp", "").toString()
					+ "</NachRequiredProp>\r\n" + "<NeftSupportDocProp>"
					+ QCSummaryObj.getOrDefault("NeftSupportDocProp", "").toString() + "</NeftSupportDocProp>\r\n"
					+ "<PanCardCopyProp>" + QCSummaryObj.getOrDefault("PanCardCopyProp", "").toString()
					+ "</PanCardCopyProp>\r\n" + "<PermanentAddressProofProp>"
					+ QCSummaryObj.getOrDefault("PermanentAddressProofProp", "").toString()
					+ "</PermanentAddressProofProp>\r\n" + "<PhotographProp>"
					+ QCSummaryObj.getOrDefault("PhotographProp", "").toString() + "</PhotographProp>\r\n"
					+ "<IdDobProofInsur>" + QCSummaryObj.getOrDefault("IdDobProofInsur", "").toString()
					+ "</IdDobProofInsur>\r\n" + "<IncomeProofInsur>"
					+ QCSummaryObj.getOrDefault("IncomeProofInsur", "").toString() + "</IncomeProofInsur>\r\n"
					+ "<PhotographInsur>" + QCSummaryObj.getOrDefault("PhotographInsur", "").toString()
					+ "</PhotographInsur>\r\n" + "<CurrAddProofPayor>"
					+ QCSummaryObj.getOrDefault("CurrAddProofPayor", "").toString() + "</CurrAddProofPayor>\r\n"
					+ "<IdDobProofPayor>" + QCSummaryObj.getOrDefault("IdDobProofPayor", "").toString()
					+ "</IdDobProofPayor>\r\n" + "<IncomeProofPayor>"
					+ QCSummaryObj.getOrDefault("IncomeProofPayor", "").toString() + "</IncomeProofPayor>\r\n"
					+ "<NachRequiredPayor>" + QCSummaryObj.getOrDefault("NachRequiredPayor", "").toString()
					+ "</NachRequiredPayor>\r\n" + "<PanCardCopyPayor>"
					+ QCSummaryObj.getOrDefault("PanCardCopyPayor", "").toString() + "</PanCardCopyPayor>\r\n"
					+ "<PhotographPayor>" + QCSummaryObj.getOrDefault("PhotographPayor", "").toString()
					+ "</PhotographPayor>\r\n" 
					+ "<PanCardCopyInsur>" + QCSummaryObj.getOrDefault("PanCardCopyInsur", "").toString()
					+ "</PanCardCopyInsur>\r\n" 
					+ "<PanCardCopyPropCompany>" + QCSummaryObj.getOrDefault("PanCardCopyPropCompany", "").toString()
					+ "</PanCardCopyPropCompany>\r\n" 
					+ "<PanCardCopyPayorCompany>" + QCSummaryObj.getOrDefault("PanCardCopyPayorCompany", "").toString()
					+ "</PanCardCopyPayorCompany>\r\n" 
					+ "<OASDocument>" + QCSummaryObj.getOrDefault("OASDocument", "").toString()
					+ "</OASDocument>\r\n" 
					// DR-18296 By sparsh
					+ "<MID>" + QCSummaryObj.getOrDefault("MID", "").toString()
					+ "</MID>\r\n" 
					
					+ "</Q_FAILED_TAGS>";
			// QCSummaryAdditionalTags
						//DR-14620 mansi[start] & DR-48434 Farman
						JSONObject QCAdditionalTagObj = (JSONObject) jsonParser.parse(json.getOrDefault("QCSummaryAdditionalTags", "{}").toString());
						attributesXML = attributesXML + "<Q_QC_ADDITIONAL_TAGS>\r\n" 
								+ "<PayorPhoto>"+ QCAdditionalTagObj.getOrDefault("PayorPhoto", "").toString() + "</PayorPhoto>\r\n"
								+ "<L2BIPhoto>" + QCAdditionalTagObj.getOrDefault("L2BIPhoto", "").toString()+ "</L2BIPhoto>\r\n" 
								+ "<PayorPanCard>"+ QCAdditionalTagObj.getOrDefault("PayorPanCard", "").toString() + "</PayorPanCard>\r\n"
								+ "<NomineePanCard>" + QCAdditionalTagObj.getOrDefault("NomineePanCard", "").toString()+ "</NomineePanCard>\r\n" 
								+ "<NEFTSupportDocProp>"+ QCAdditionalTagObj.getOrDefault("NEFTSupportDocProp", "").toString() + "</NEFTSupportDocProp>\r\n"
								+ "<TitleGenderProp>" + QCAdditionalTagObj.getOrDefault("TitleGenderProp", "").toString()+ "</TitleGenderProp>\r\n" 
								+ "<TitleGenderInsur>"+ QCAdditionalTagObj.getOrDefault("TitleGenderInsur", "").toString()+ "</TitleGenderInsur>\r\n" 
								+ "<VideoPOSV>"+ QCAdditionalTagObj.getOrDefault("VideoPOSV", "").toString() + "</VideoPOSV>\r\n"
								+ "<SellerDeclarationReqd>"+ QCAdditionalTagObj.getOrDefault("SellerDeclarationReqd", "").toString() + "</SellerDeclarationReqd>\r\n"
								+ "<CustomerDeclarationFormProp>"+ QCAdditionalTagObj.getOrDefault("CustomerDeclarationFormProp", "").toString() + "</CustomerDeclarationFormProp>\r\n"
								+ "<customerIDProof>"+ QCAdditionalTagObj.getOrDefault("customerIDProof", "").toString() + "</customerIDProof>\r\n"
							    + "<CustInformSheetofProduct>"+ QCAdditionalTagObj.getOrDefault("CustInformSheetofProduct", "").toString() + "</CustInformSheetofProduct>\r\n"
							    + "<CriticalIllnessAndDisabiltyRider>"+ QCAdditionalTagObj.getOrDefault("CriticalIllnessAndDisabiltyRider", "").toString() + "</CriticalIllnessAndDisabiltyRider>\r\n"
								+ "<CriticalIllnessAndDisabiltySecureRider>"+ QCAdditionalTagObj.getOrDefault("CriticalIllnessAndDisabiltySecureRider", "").toString() + "</CriticalIllnessAndDisabiltySecureRider>\r\n"
								+ "<WaiverOfPremPlusRider>"+ QCAdditionalTagObj.getOrDefault("WaiverOfPremPlusRider", "").toString() + "</WaiverOfPremPlusRider>\r\n"
								+ "<SmrtUltraProtectRider>"+ QCAdditionalTagObj.getOrDefault("SmrtUltraProtectRider", "").toString() + "</SmrtUltraProtectRider>\r\n"
								+ "<TermPlusRider>"+ QCAdditionalTagObj.getOrDefault("TermPlusRider", "").toString() + "</TermPlusRider>\r\n"
							    + "<AccdntalDeathAndDismembermntRider>"+ QCAdditionalTagObj.getOrDefault("AccdntalDeathAndDismembermntRider", "").toString() + "</AccdntalDeathAndDismembermntRider>\r\n"
							    + "<IVC>"+ QCAdditionalTagObj.getOrDefault("IVC", "").toString() + "</IVC>\r\n" //DR-48924 BY SPARSH
							    + "<LPOSV>"+ QCAdditionalTagObj.getOrDefault("LPOSV", "").toString() + "</LPOSV>\r\n" //DR-49096 BY SPARSH
							    + "<IncomeProofPropSpouse>"+ QCAdditionalTagObj.getOrDefault("IncomeProofPropSpouse", "").toString() + "</IncomeProofPropSpouse>\r\n"  //DR-49133 By Farman
							    + "<LiveSelfieOfProp>"+ QCAdditionalTagObj.getOrDefault("LiveSelfieOfProp", "").toString() + "</LiveSelfieOfProp>\r\n"  //DR-49133 By Farman
							    + "<RakshakDocRequired>"+ QCAdditionalTagObj.getOrDefault("RakshakDocRequired", "").toString() + "</RakshakDocRequired>\r\n"  //DR-49133 By Farman
							    + "<FTINDocument>"+ QCAdditionalTagObj.getOrDefault("FTINDocument", "").toString() + "</FTINDocument>\r\n"  //DR-49133 By Farman
							    + "<NRICase>"+ QCAdditionalTagObj.getOrDefault("NRICase", "").toString() + "</NRICase>\r\n"  //DR-49133 By Farman
							    + "<FormCtag>"+ QCAdditionalTagObj.getOrDefault("FormCtag", "").toString() + "</FormCtag>\r\n"  //DR-49133 By Farman
							    + "<PhysicalJourney>"+ QCAdditionalTagObj.getOrDefault("PhysicalJourney", "").toString() + "</PhysicalJourney>\r\n"  //DR-49133 By Farman	
							    + "<OCRFinancialProp>"+ QCAdditionalTagObj.getOrDefault("OCRFinancialProp", "").toString() + "</OCRFinancialProp>\r\n"  //DR-52462 By SParsh/mansi
							    + "<finQCDiscrepancy>"+ QCAdditionalTagObj.getOrDefault("finQCDiscrepancy", "").toString() + "</finQCDiscrepancy>\r\n"  //DR-52462 By Sparsh/mansi
								+ "</Q_QC_ADDITIONAL_TAGS>";
						//DR-14620 mansi[end] & DR-48434 Farman
						
	
			// ProposerDocumentDetail DR-48024 sparsh
			JSONArray ProposerDocumentDetail;
			ProposerDocumentDetail = (JSONArray) ProposerDetails.getOrDefault("IVCDocumentDetails",new JSONArray());
			insertionOrderId = 0;
			hashID = 1;
			for (Object j : ProposerDocumentDetail) {
				JSONObject jsonObj = (JSONObject) j;
				attributesXML = attributesXML + "<Q_CALLBACK_DOCUMENTS>\r\n" + "<InsertionOrderId>"
				+ insertionOrderId + "</InsertionOrderId>" + "<HashId>" + hashID++ + "</HashId>" 
								+ "<DOCUMENT_NAME>" + jsonObj.getOrDefault("DocumentName","").toString() + "</DOCUMENT_NAME>"
								+ "<LINK>" + jsonObj.getOrDefault("Link","").toString() + "</LINK>" 
								+ "</Q_CALLBACK_DOCUMENTS>";
		}
			
			// Proposal_No
			// to be removed later - prakhar
		//	attributesXML = attributesXML + "<PROPOSAL_NUMBER>" + Proposal_No + "</PROPOSAL_NUMBER>";

			// String ValidationRequired="NG_ME_DST_DCNNO"+ (char)(21) +"DCNNO"+
			// (char)(21)+ "'as123'" +(char)(25);
			String ValidationRequired = "";
			// logger.info(ValidationRequired);
			logger.info("attributesXML: " + attributesXML);

			// attributesXML=URLEncoder.encode(attributesXML);
			String method = "POST";
			// ipAddress = "192.168.54.97";
			String url = "http://" + ipAddress + ":"+port+"/iBPSRestFulWebServices/ibps/Restful/" + cabinetName
					+ "/WFUploadWorkItem";
			logger.info("url: " + url);
			HashMap<String, String> hm = new HashMap<>();
			// hm.put("sessionId", sessionID);
			// hm.put("attributeXML",attributesXML);

			String WFUploadWorkItem_XML = "";

			// attaching documents by creating a folder with the name of
			// proposal number and then moving the documents to WI in case of
			// success
			String isDocPresent = "false";
			String statusCode = "", errMsg = "";
			try {
				// String ProposalNumber = null;
				String docResult = "";

				JSONArray DocumentsArr;
				DocumentsArr = (JSONArray) json.get("Documents");

				int totalDocs = DocumentsArr.size();
				// hardcoded to disable document functionality
				totalDocs = -1;

				if (totalDocs > 1 && multipleDocAllowed.equalsIgnoreCase("N")) {
					return "{\r\n" + "\"Exception\": {\r\n"
							+ "			\"Subject\":\"Error in creating Workitem.Number of documents are greater than one.\";\r\n"
							+ "			 }\r\n" + "}";
				} else if (totalDocs >= 1 && multipleDocAllowed.equalsIgnoreCase("Y")) {
					isDocPresent = "true";
					// String proposalFolderIndex =
					// CommonFunctions.createFolder(Proposal_No,sessionID);

					// if(proposalFolderIndex.indexOf("Error")==-1) {
					JSONArray DocumentsArray;
					DocumentsArray = (JSONArray) json.get("Documents");

					for (Object j : DocumentsArray) {
						JSONObject jsonObj = (JSONObject) j;
						// attributesXML = attributesXML +
						String DocumentCategory = (String) jsonObj.get("DocumentCategory");
						String documentData = (String) jsonObj.get("DocumentDataBase64");
						String DocumentName = (String) jsonObj.get("DocumentName");

						String createdByAppName = DocumentName.substring(DocumentName.indexOf(".") + 1,
								DocumentName.length());
						String DocumentNameOD = DocumentName.substring(0, DocumentName.indexOf("."));

						// Adding document to Image Server and inserting the
						// entries to NG_NB_DOCUMENTS_UPLOADED table to
						// associate with the Workitem later in case of no
						// error.

						String filePath = CommonFunctions.base64toFile(documentData, Proposal_No, DocumentName);
						String isIndex = CommonFunctions.AddDocument_MT(filePath);
						if (isIndex.equalsIgnoreCase("Error")) {
							statusCode = "Error in adding doument to image server. Check SMS logs.";
							return statusCode;
						} else
							statusCode = "0";

						// Adding data to NG_NB_DOCUMENTS_UPLOADED
						String documentType = "", noOfPages = "", documentSize = "", createdByApp = "", comment = "",
								createdDateTime = "", proposalNumber = "", DocIndex = "", parentFolderIndex = "";
						documentType = DocumentCategory;// docResult.substring(docResult.indexOf("<documentName>")+14,docResult.indexOf("</documentName>"));
						// isIndex = IsIndex.m_nDocIndex+ "#"+
						// IsIndex.m_sVolumeId;
						noOfPages = "";// docResult.substring(docResult.indexOf("<noOfPages>")+11,docResult.indexOf("</noOfPages>"));
						documentSize = "";// docResult.substring(docResult.indexOf("<documentSize>")+14,docResult.indexOf("</documentSize>"));
						createdByApp = createdByAppName;// docResult.substring(docResult.indexOf("<createdByAppName>")+18,docResult.indexOf("</createdByAppName>"));
						comment = DocumentNameOD;// docResult.substring(docResult.indexOf("<comment>")+9,docResult.indexOf("</comment>"));
						Date date = (Date) Calendar.getInstance().getTime();
						DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
						createdDateTime = dateFormat.format(date); // docResult.substring(docResult.indexOf("<createdDateTime>")+17,docResult.indexOf("</createdDateTime>"));
						proposalNumber = Proposal_No;
						DocIndex = "";// docResult.substring(docResult.indexOf("<documentIndex>")+15,docResult.indexOf("</documentIndex>"));
						parentFolderIndex = "";// docResult.substring(docResult.indexOf("<parentFolderIndex>")+19,docResult.indexOf("</parentFolderIndex>"));

						String query = "INSERT INTO NG_NB_DOCUMENTS_UPLOADED (DOCUMENT_TYPE, IS_INDEX, NO_OF_PAGES, DOCUMENT_SIZE, CREATED_BY_APP,"
								+ " COMMENT, CREATED_DATE_TIME, PROPOSAL_NUMBER, DOC_INDEX, PARENT_FOLDER_INDEX, IS_ASSOCIATED)\r\n"
								+ "VALUES ('" + documentType + "', '" + isIndex + "', '" + noOfPages + "', '"
								+ documentSize + "', '" + createdByApp + "'," + " '" + comment + "', '"
								+ createdDateTime + "', '" + proposalNumber + "', '" + DocIndex + "', '"
								+ parentFolderIndex + "', 'N')";
						// //getting sessionID
						// inputXML =
						// XMLGen.get_WMConnect_Input(cabinetName,username,password,"N");
						// logger.info("get_WMConnect_Input_inputXML:
						// "+inputXML);
						// outputXML = callRestAPI_JTS(inputXML);
						// sessionID =
						// outputXML.substring(outputXML.indexOf("<SessionId>")+11,outputXML.indexOf("</SessionId>"));
						// logger.info("get_WMConnect_Input_outputXML:
						// "+outputXML);

						String inputXML = XMLGen.APSelectWithColumnNames(cabinetName, query, sessionID);
						logger.info("APSelectWithColumnNames_Input_inputXML: " + inputXML);
						// String outputXML = WFCallBroker.execute(inputXML,
						// "192.168.54.97", 3333, 1);
						String outputXML = CommonFunctions.callRestAPI_JTS(inputXML);
						logger.info("APSelectWithColumnNames_outputXML: " + outputXML);

					}

				}

			} catch (Exception ex) {
				ex.printStackTrace();
				logger.error("Exception Occured: ", ex);
				return "{\\r\\n\" + \r\n" + "		        			\"	\\\"Exception\\\":\\r\\n\" + \r\n"
						+ "		        			\"		{\\r\\n\" + \r\n"
						+ "		        			\"			\\\"statusCode\\\": 1,\\r\\n\" + \r\n"
						+ "		        			\"			\\\"Subject\\\":\"" + ex + "\"\\r\\n\"+\r\n"
						+ "		        			\"		}\\r\\n\" + \r\n" + "		        			\"}";
			}

			if ((statusCode.equalsIgnoreCase("0") && isDocPresent.equalsIgnoreCase("true"))
					|| isDocPresent.equalsIgnoreCase("false")) {

				String documetAttribute = "";
				if (isDocPresent.equalsIgnoreCase("true")) {
					// documetAttribute =
					// CommonFunctions.generateDocument(Proposal_No,sessionID);
				}

				// sessionID=callRestAPI(urlSessionID, methodsessionID, hm2);
				// if(sessionID.indexOf("<SessionId>")==-1) {
				// String result = sessionID;
				// return result;
				// }
				// else {
				// sessionID =
				// sessionID.substring(sessionID.indexOf("<SessionId>")+11,
				// sessionID.indexOf("</SessionId>"));
				// }
				String WFUploadWorkItem_XML_COMBO="";
				attributesXML = attributesXML.replaceAll("null", "");
				attributesXML_COMBO=attributesXML;
				attributesXML = attributesXML + "<PROPOSAL_NUMBER>" + Proposal_No + "</PROPOSAL_NUMBER><COMBO_PROPOSAL_NUMBER>" + Combo_Proposal_Number + "</COMBO_PROPOSAL_NUMBER>";
				WFUploadWorkItem_XML = WFUploadWorkItem_XML + "<WFUploadWorkItem>" + "<Option>WFUploadWorkItem</Option>"
						+ "<EngineName>" + cabinetName + "</EngineName>" + "<SessionId>" + sessionID + "</SessionId>"
						+ "<ProcessDefId>" + processDefId + "</ProcessDefId>"
						+ "<InitiateFromActivityId>1</InitiateFromActivityId>" + "<UserDefVarFlag>Y</UserDefVarFlag>"
						+ "<Attributes>" + attributesXML + "</Attributes>"
						// + "<Documents>"+documetAttribute+"</Documents>"
						+ "<Documents>" + documentsTag + "</Documents>" + "<PSFlag>Y</PSFlag>"
						// bug 1080315
						+ "<ValidationRequired>NG_NB_PolicyCheck" + (char) 21 + "PolicyNumber" + (char) 21 + "'"
						+ Proposal_No + "'" + (char) 25 + "</ValidationRequired>" + "</WFUploadWorkItem>";
				hm.put("Content-Type", "application/xml");
				logger.info("wfuploadXML_Input: " + WFUploadWorkItem_XML);
				wfuploadXML = CommonFunctions.callRestAPI(url, method, WFUploadWorkItem_XML, hm);
				logger.info("wfuploadXML: " + wfuploadXML);
				String wiName = "", itemIndex = "", userName = "";
				if (wfuploadXML.contains("ProcessInstanceId")) {
					wiName = wfuploadXML.substring(wfuploadXML.indexOf("ProcessInstanceId") + 18,
							wfuploadXML.indexOf("</ProcessInstanceId>"));
					itemIndex = wfuploadXML.substring(wfuploadXML.indexOf("FolderIndex") + 12,
							wfuploadXML.indexOf("</FolderIndex>"));
					userName = wfuploadXML.substring(wfuploadXML.indexOf("UserName") + 9,
							wfuploadXML.indexOf("</UserName>"));
					// inserting doc data to table
					if (!documentsArr.isEmpty()) {
						for (Object tag : documentsArr) {
							JSONObject jsonObj = (JSONObject) tag;
							documentsTag = documentsTag + jsonObj.get("documentName") + (char) 21
									+ jsonObj.get("documentIndex") + "#" + jsonObj.get("volumeId") + (char) 21
									+ jsonObj.get("noOfPages") + (char) 21 + jsonObj.get("documentSize") + (char) 21
									+ jsonObj.get("extension") + (char) 21 + jsonObj.get("documentName") + (char) 25;
							String query = "INSERT INTO NG_NB_DOLPHIN_DOC_DETAILS (Policyid, DocIndex, "
									+ "VolumeId, Polfolderid, "
									+ "Docname, Docsize, Userid, CreatedDateTime, CASE_STATUS, WI_NAME)\r\n"
									+ "VALUES ('" + Proposal_No + "', " + jsonObj.getOrDefault("docIndex1","") + "" + ", "
									+ jsonObj.get("volumeId") + ", '" + itemIndex + "', " + "'"
									+ jsonObj.get("documentName") + "', '" + jsonObj.get("documentSize") + "'"
									+ ", 'restServiceUser', getDate(), NULL, '" + wiName + "')";

							String inputXML = XMLGen.APSelectWithColumnNames(cabinetName, query, sessionID);
							logger.info("APSelectWithColumnNames_Input_inputXML: " + inputXML);
							// String outputXML = WFCallBroker.execute(inputXML,
							// "192.168.54.97", 3333, 1);
							String outputXML = CommonFunctions.callRestAPI_JTS(inputXML);
							logger.info("APSelectWithColumnNames_outputXML: " + outputXML);

						}
					}

					// adding data class
					String inputXML = "<?xml version=\"1.0\"?>"
							+ "<NGOChangeFolderProperty_Input><Option>NGOChangeFolderProperty</Option>"
							+ "<CabinetName>" + cabinetName + "</CabinetName>" + "<UserDBId>" + sessionID
							+ "</UserDBId>" + "<Folder><FolderIndex>" + itemIndex + "</FolderIndex>" + "<FolderName>"
							+ wiName + "</FolderName>" + "<EnableFTSFlag>N</EnableFTSFlag>"
							+ "<AccessType>S</AccessType>" + "<VersionFlag>N</VersionFlag>"
							+ "<Comment>Not Defined</Comment>" + "<Owner>" + userName + "</Owner>"
							+ "<OwnerType>U</OwnerType>" + "<OwnerIndex></OwnerIndex>" + "<DataDefinition>"
							+ "<DataDefIndex>48</DataDefIndex>" + "<Fields>" + "<Field><IndexId>92</IndexId>"
							+ "<IndexType>S</IndexType>" + "<IndexValue>" + Proposal_No + "</IndexValue>"
							+ "</Field></Fields></DataDefinition>" + "</Folder>" + "</NGOChangeFolderProperty_Input>";
					logger.info("APSelectWithColumnNames_Input_inputXML: " + inputXML);
					// String outputXML = WFCallBroker.execute(inputXML,
					// "192.168.54.97", 3333, 1);
					String outputXML = CommonFunctions.callRestAPI_JTS(inputXML);
					logger.info("APSelectWithColumnNames_outputXML: " + outputXML);
				} else {
					failFlag = "Y";
				}
				
				
				
				if((!(Combo_Proposal_Number.equalsIgnoreCase(""))) && (!(failFlag.equalsIgnoreCase("Y"))))
				{
					attributesXML_COMBO = attributesXML_COMBO + "<PROPOSAL_NUMBER>" + Combo_Proposal_Number + "</PROPOSAL_NUMBER><PRIMARY_PROPOSAL_NUMBER>" + Proposal_No + "</PRIMARY_PROPOSAL_NUMBER><COMBO_PROPOSAL_NUMBER>"+ Proposal_No + "</COMBO_PROPOSAL_NUMBER>";
					attributesXML_COMBO = attributesXML_COMBO + "<IS_COMBO_SECONDARY>" + "Y" + "</IS_COMBO_SECONDARY>";
				WFUploadWorkItem_XML_COMBO = WFUploadWorkItem_XML_COMBO + "<WFUploadWorkItem>" + "<Option>WFUploadWorkItem</Option>"
						+ "<EngineName>" + cabinetName + "</EngineName>" + "<SessionId>" + sessionID + "</SessionId>"
						+ "<ProcessDefId>" + processDefId + "</ProcessDefId>"
						+ "<InitiateFromActivityId>1</InitiateFromActivityId>" + "<UserDefVarFlag>Y</UserDefVarFlag>"
						+ "<Attributes>" + attributesXML_COMBO + "</Attributes>"
						// + "<Documents>"+documetAttribute+"</Documents>"
						+ "<Documents>" + documentsTagCOMBO+ "</Documents>" + "<PSFlag>Y</PSFlag>"
						// bug 1080315
						+ "<ValidationRequired>NG_NB_PolicyCheck" + (char) 21 + "PolicyNumber" + (char) 21 + "'"
						+ Combo_Proposal_Number + "'" + (char) 25 + "</ValidationRequired>" + "</WFUploadWorkItem>";
				hm.put("Content-Type", "application/xml");
				logger.info("wfuploadXML_Input_COMBO: " + WFUploadWorkItem_XML_COMBO);
				wfuploadXML_COMBO = CommonFunctions.callRestAPI(url, method, WFUploadWorkItem_XML_COMBO, hm);
				logger.info("wfuploadXML: " + wfuploadXML_COMBO);
				String wiName_COMBO = "", itemIndex_COMBO = "", userName_COMBO = "";
				
				
				if (wfuploadXML_COMBO.contains("ProcessInstanceId")) {
					wiName_COMBO = wfuploadXML_COMBO.substring(wfuploadXML_COMBO.indexOf("ProcessInstanceId") + 18,
							wfuploadXML_COMBO.indexOf("</ProcessInstanceId>"));
					itemIndex_COMBO = wfuploadXML_COMBO.substring(wfuploadXML_COMBO.indexOf("FolderIndex") + 12,
							wfuploadXML_COMBO.indexOf("</FolderIndex>"));
					userName_COMBO = wfuploadXML_COMBO.substring(wfuploadXML_COMBO.indexOf("UserName") + 9,
							wfuploadXML_COMBO.indexOf("</UserName>"));
					// inserting doc data to table
					if (!documentsArrCOMBO.isEmpty()) {
						for (Object tag : documentsArrCOMBO) {
							JSONObject jsonObj = (JSONObject) tag;
							documentsTagCOMBO = documentsTagCOMBO + jsonObj.get("documentName") + (char) 21
									+ jsonObj.get("documentIndex") + "#" + jsonObj.get("volumeId") + (char) 21
									+ jsonObj.get("noOfPages") + (char) 21 + jsonObj.get("documentSize") + (char) 21
									+ jsonObj.get("extension") + (char) 21 + jsonObj.get("documentName") + (char) 25;
							String query = "INSERT INTO NG_NB_DOLPHIN_DOC_DETAILS (Policyid, DocIndex, "
									+ "VolumeId, Polfolderid, "
									+ "Docname, Docsize, Userid, CreatedDateTime, CASE_STATUS, WI_NAME)\r\n"
									+ "VALUES ('" + Combo_Proposal_Number + "', " + jsonObj.getOrDefault("docIndex1","") + "" + ", "
									+ jsonObj.get("volumeId") + ", '" + itemIndex_COMBO + "', " + "'"
									+ jsonObj.get("documentName") + "', '" + jsonObj.get("documentSize") + "'"
									+ ", 'restServiceUser', getDate(), NULL, '" + wiName_COMBO + "')";

							String inputXML = XMLGen.APSelectWithColumnNames(cabinetName, query, sessionID);
							logger.info("APSelectWithColumnNames_Input_inputXML: " + inputXML);
							// String outputXML = WFCallBroker.execute(inputXML,
							// "192.168.54.97", 3333, 1);
							String outputXML = CommonFunctions.callRestAPI_JTS(inputXML);
							logger.info("APSelectWithColumnNames_outputXML: " + outputXML);

						}
					}

					// adding data class
					String inputXML = "<?xml version=\"1.0\"?>"
							+ "<NGOChangeFolderProperty_Input><Option>NGOChangeFolderProperty</Option>"
							+ "<CabinetName>" + cabinetName + "</CabinetName>" + "<UserDBId>" + sessionID
							+ "</UserDBId>" + "<Folder><FolderIndex>" + itemIndex_COMBO + "</FolderIndex>" + "<FolderName>"
							+ wiName_COMBO + "</FolderName>" + "<EnableFTSFlag>N</EnableFTSFlag>"
							+ "<AccessType>S</AccessType>" + "<VersionFlag>N</VersionFlag>"
							+ "<Comment>Not Defined</Comment>" + "<Owner>" + userName_COMBO + "</Owner>"
							+ "<OwnerType>U</OwnerType>" + "<OwnerIndex></OwnerIndex>" + "<DataDefinition>"
							+ "<DataDefIndex>48</DataDefIndex>" + "<Fields>" + "<Field><IndexId>92</IndexId>"
							+ "<IndexType>S</IndexType>" + "<IndexValue>" + Combo_Proposal_Number + "</IndexValue>"
							+ "</Field></Fields></DataDefinition>" + "</Folder>" + "</NGOChangeFolderProperty_Input>";
					logger.info("APSelectWithColumnNames_Input_inputXML: " + inputXML);
					// String outputXML = WFCallBroker.execute(inputXML,
					// "192.168.54.97", 3333, 1);
					String outputXML = CommonFunctions.callRestAPI_JTS(inputXML);
					logger.info("APSelectWithColumnNames_outputXML: " + outputXML);
				} else {
					failFlag_COMBO = "Y";
				}
				}
				
				
			} else {
				String delResult = "";
				wfuploadXML = wfuploadXML + "<statusCode>" + statusCode
						+ "</statusCode><message>Error in uplodaing document! Workitem Creation failed.</message>"
						+ "<msgInfo><msgCode>500</msgCode><msg>Exception</msg></msgInfo>";
				// delResult = deleteFolder(Proposal_No);
				wfuploadXML = wfuploadXML + delResult;
			}

		} catch (Exception ex) {

			logger.info("Exception" + ex.getMessage());
			wfuploadXML = "<Exception><Message>" + ex.toString() + "</Message></Exception>"
					+ "<msgInfo><msgCode>500</msgCode><msg>Exception</msg></msgInfo>";
			// "<Response><MainCode>1</MainCode><Status>Error</Status><Errormsg>"+ex.getMessage()+"</Errormsg></Response>";
		}

		
		if (failFlag.equalsIgnoreCase("Y")) {
			wfuploadXML = "<status>" + wfuploadXML + "</status>"
					+ "<msgInfo><msgCode>500</msgCode><msg>Exception</msg></msgInfo>";
		} 
		else if ((!(failFlag.equalsIgnoreCase("Y"))) &&  failFlag_COMBO.equalsIgnoreCase("Y")) {
			wfuploadXML = "<status>" +  wfuploadXML_COMBO + "</status>"
					+"<comboPOlICYSTATUS> FAIL </comboPOlICYSTATUS>"
					+ "<msgInfo><msgCode>500</msgCode><msg>Exception</msg></msgInfo>";
		} 
		else {
			wfuploadXML=wfuploadXML+wfuploadXML_COMBO;
			if(!(wfuploadXML_COMBO.equalsIgnoreCase("")))
				wfuploadXML += "<msgInfo><msgCode>200</msgCode><msg>Success</msg><IsCombo>Y</IsCombo></msgInfo>";
			else
			wfuploadXML += "<msgInfo><msgCode>200</msgCode><msg>Success</msg><IsCombo>N</IsCombo></msgInfo>";
		}
		
		

		org.json.JSONObject jsonObj = XML.toJSONObject(wfuploadXML);
		wfuploadXML = jsonObj.toString();
		return wfuploadXML;
	}

	public JSONObject createErrorJson(String msgCode, String msg) {
		JSONObject error = new JSONObject();
		error.put("msgCode", msgCode);
		error.put("msg", msg);
		return error;
	}

}
