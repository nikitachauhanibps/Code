package com.newgen.services;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;

import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.log4j.Logger;

import com.newgen.gui.Server;

public class LE_STP_Gen_Cal {
	static Logger logger = Logger.getLogger("LE_STP_Gen_Cal");
	public static String generateDOC(String token, String serverData, String flag,String planCode) {
		logger.info("planCode: "+planCode);
		logger.info("flag: "+flag);
		HashMap<String, String> hm = new HashMap<>();
		//for SIT
		hm.put("Content-Type", "application/json");        
        hm.put("x-api-key", Server.propertiesFileData.getProperty("ApiKey"));        
        hm.put("cache-control", "no-cache");
        hm.put("host", Server.propertiesFileData.getProperty("Host"));
        hm.put("Authorization", token);
        
        String url="";
        if(flag.equalsIgnoreCase("Generate"))	//illustration for document generation
        	url = Server.propertiesFileData.getProperty("LE_GenDocUrl");
        else        							//calculation of premium
        	url=Server.propertiesFileData.getProperty("LE_CalcPremiumUrl");
        
		String jsonString = "";
		jsonString = callAPI(url,"POST", hm, serverData,planCode);
		logger.info("jsonString: "+jsonString);		
		return jsonString;
	}
	
	private static String callAPI(String url, String string, HashMap<String, String> hm, String serverData, String planCode) {
			String postEndpoint = url;
			CloseableHttpClient httpclient = HttpClients.createDefault();
			HttpPost httpPost = new HttpPost(postEndpoint);
			for (String i : hm.keySet()) {
				httpPost.setHeader(i, hm.get(i)); // set userId
			}
			String inputJson = serverData;
			System.out.println("inputJson: "+inputJson);
			logger.info("inputJson: "+inputJson);	
			StringEntity stringEntity;
			StringBuffer result = new StringBuffer();
			try {
				stringEntity = new StringEntity(inputJson);
				httpPost.setEntity(stringEntity);
				System.out.println("Executing request " + httpPost.getRequestLine());
				HttpResponse response = httpclient.execute(httpPost);
				BufferedReader br = new BufferedReader(
						new InputStreamReader((response.getEntity().getContent())));
				if (response.getStatusLine().getStatusCode() != 200) {
					throw new RuntimeException("Failed : HTTP error code : "
							+ response.getStatusLine().getStatusCode());
				}
				String line = "";
				while ((line = br.readLine()) != null) {
				result.append(line);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		return result.toString();
	}

	
}
