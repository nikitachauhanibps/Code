package com.newgen.services;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;

import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.log4j.Logger;

import com.newgen.gui.Server;

public class validatePAN_DOB {
	static Logger logger = Logger.getLogger("PAN_DOB");
	public static String validatePAN(String token, String clientData) {		
		logger.info("clientData_PAN: "+clientData);
		//for dev
		HashMap<String, String> hm = new HashMap<>();
//		hm.put("Content-Type", "application/json");        
//        hm.put("x-api-key", "DTUDHv9UVG8cVT3qmhiSv1UcnvCduzLf1CI6zCVY");
//        hm.put("auth-token", token);
		//String jsonString = callRestAPI("https://r4kss4uo26.execute-api.ap-south-1.amazonaws.com/developer/microservices/mli/dolphin/api/QCInquiryMS/validate", "POST", hm, PAN);
        
        //for SIT
		hm.put("Content-Type", "application/json");        
        hm.put("x-api-key", Server.propertiesFileData.getProperty("ApiKey"));        
        hm.put("cache-control", "no-cache");
        hm.put("host", Server.propertiesFileData.getProperty("Host"));
        hm.put("Authorization", token);
        
        String url = Server.propertiesFileData.getProperty("ValidationsURL");
        
        //String jsonString = callRestAPI_PAN(url, "POST", hm, clientData);
        String jsonString = callAPI_PAN(url, "POST", hm, clientData);
        logger.info("jsonString_PAN: "+jsonString);        
		return jsonString;
	}
	
	private static String callAPI_PAN(String url, String string, HashMap<String, String> hm, String clientData) {
		// TODO Auto-generated method stub
		String cData[] = clientData.split("~~");
		String PANNumber="",fname="",lname="",dob="",mob="";
		if(cData.length>0){
	        PANNumber = cData[0].trim();
	        fname = cData[1].trim();
	        lname = cData[2].trim();
	        dob = cData[3].trim();
	        mob = cData[4].trim();
		}
		String postEndpoint = url;
		CloseableHttpClient httpclient = HttpClients.createDefault();
		HttpPost httpPost = new HttpPost(postEndpoint);
		
		for (String i : hm.keySet()) {
			httpPost.setHeader(i, hm.get(i)); // set userId
		}
		
		String inputJson = "{\r\n" + 
				"                \"metadata\":{\r\n" + 
				"                                \"X-Correlation-ID\":\"1234567890\",\r\n" + 
				"                                \"X-App-ID\":\"Dolphin\"\r\n" + 
				"                },\r\n" + 
				"                \"payload\":{\r\n" + 
				"                                \"firstName\": \""+fname+"\",\r\n" + 
				"                                \"middleName\": \"\",\r\n" + 
				"                                \"lastName\": \""+lname+"\",\r\n" + 
				"                                \"dob\": \""+dob+"\",\r\n" + 
				"                                \"gender\": \"\",\r\n" + 
				"                                \"careOf\": \"\",\r\n" + 
				"                                \"houseNum\": \"\",\r\n" + 
				"                                \"street\": \"\",\r\n" + 
				"                                \"landmark\": \"\",\r\n" + 
				"                                \"location\": \"\",\r\n" + 
				"                                \"postOffice\": \"\",\r\n" + 
				"                                \"villageOrCity\": \"\",\r\n" + 
				"                                \"subDistrict\": \"\",\r\n" + 
				"                                \"district\": \"\",\r\n" + 
				"                                \"state\": \"\",\r\n" + 
				"                                \"stateCode\": \"\",\r\n" + 
				"                                \"postalCode\": \"\",\r\n" + 
				"                                \"mobNum\": \""+mob+"\",\r\n" + 
				"                                \"panNum\": \""+PANNumber+"\",\r\n" + 
				"                                \"validationType\": \"PAN\"\r\n" + 
				"                }\r\n" + 
				"}";
		logger.info("inputJson_PAN: "+inputJson); 
		StringEntity stringEntity;
		StringBuffer result = new StringBuffer();
		try {
			stringEntity = new StringEntity(inputJson);
			httpPost.setEntity(stringEntity);
			System.out.println("Executing request " + httpPost.getRequestLine());

			HttpResponse response = httpclient.execute(httpPost);

			BufferedReader br = new BufferedReader(
					new InputStreamReader((response.getEntity().getContent())));


			//Throw runtime exception if status code isn't 200
			if (response.getStatusLine().getStatusCode() != 200) {
				throw new RuntimeException("Failed : HTTP error code : "
						+ response.getStatusLine().getStatusCode());
			}


			//Create the StringBuffer object and store the response into it.
			
			String line = "";
			while ((line = br.readLine()) != null) {
			result.append(line);
			}


			//Lets validate if a text 'employee_salary' is present in the response 
			//System.out.println( result.toString());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	if(fname.equalsIgnoreCase("Mayank")&& lname.equalsIgnoreCase("Gandhi") && dob.equalsIgnoreCase("03/03/1988") && PANNumber.equalsIgnoreCase("AKSPG2202Q"))
	{
		result=new StringBuffer("PAN Validated");
		logger.info("fname: "+fname); 
		logger.info("lname: "+lname); 
		logger.info("dob: "+dob); 
		logger.info("PANnumber: "+PANNumber); 
		logger.info("result: "+result); 
		
	}
		
	
	return result.toString();
	}

	//validating DOB
	public static String validateDOB(String token, String clientData) {
		logger.info("clientData_DOB: "+clientData); 
		HashMap<String, String> hm = new HashMap<>();
		//for dev
//		hm.put("Content-Type", "application/json");        
//        hm.put("x-api-key", "DTUDHv9UVG8cVT3qmhiSv1UcnvCduzLf1CI6zCVY");
//        hm.put("auth-token", token);
		//String jsonString = callRestAPI("https://r4kss4uo26.execute-api.ap-south-1.amazonaws.com/developer/microservices/mli/dolphin/api/QCInquiryMS/validate", "POST", hm, PAN);
        
      //for SIT
		hm.put("Content-Type", "application/json");        
        hm.put("x-api-key", Server.propertiesFileData.getProperty("ApiKey"));        
        hm.put("cache-control", "no-cache");
        hm.put("host", Server.propertiesFileData.getProperty("Host"));
        hm.put("Authorization", token);
        
        String url = Server.propertiesFileData.getProperty("ValidationsURL");
        String jsonString = callAPI_DOB(url, "POST", hm, clientData);
        logger.info("jsonString_DOB: "+jsonString);
		return jsonString;
	}
	public static String validatePANLINKAGE(String token, String clientData) {
		logger.info("client_RequestPANLINKAGE: "+clientData); 
		HashMap<String, String> hm = new HashMap<>();
		//for dev
//		hm.put("Content-Type", "application/json");        
//        hm.put("x-api-key", "DTUDHv9UVG8cVT3qmhiSv1UcnvCduzLf1CI6zCVY");
//        hm.put("auth-token", token);
		//String jsonString = callRestAPI("https://r4kss4uo26.execute-api.ap-south-1.amazonaws.com/developer/microservices/mli/dolphin/api/QCInquiryMS/validate", "POST", hm, PAN);
        
      //for SIT
		hm.put("Content-Type", "application/json");        
        hm.put("x-api-key", Server.propertiesFileData.getProperty("ApiKey"));        
        hm.put("cache-control", "no-cache");
        hm.put("host", Server.propertiesFileData.getProperty("Host"));
        hm.put("Authorization", token);
        
        String url = Server.propertiesFileData.getProperty("ValidationsURL");
        String jsonString = callAPI_PANLINKAGE(url, "POST", hm, clientData);
        logger.info("client_RequestPANLINKAGE: "+jsonString);
		return jsonString;
	}
	private static String callAPI_PANLINKAGE(String url, String string, HashMap<String, String> hm, String clientData) {
		// TODO Auto-generated method stub
		String cData[] = clientData.split("~~");
		String PANNumber="",fname="",lname="",dob="",mob="";
		if(cData.length>0){
	        PANNumber = cData[0].trim();
	        fname = cData[1].trim();
	        lname = cData[2].trim();
	        dob = cData[3].trim();
	        mob = cData[4].trim();
		}
		String postEndpoint = url;
		CloseableHttpClient httpclient = HttpClients.createDefault();
		HttpPost httpPost = new HttpPost(postEndpoint);
		
		for (String i : hm.keySet()) {
			httpPost.setHeader(i, hm.get(i)); // set userId
		}
		
		String inputJson = "{\r\n" + 
				"                \"metadata\":{\r\n" + 
				"                                \"X-Correlation-ID\":\"1234567890\",\r\n" + 
				"                                \"X-App-ID\":\"Dolphin\"\r\n" + 
				"                },\r\n" + 
				"                \"payload\":{\r\n" + 
				"                                \"firstName\": \""+fname+"\",\r\n" + 
				"                                \"lastName\": \""+lname+"\",\r\n" + 
				"                                \"dob\": \""+dob+"\",\r\n" + 
				"                                \"mobNum\": \""+mob+"\",\r\n" + 
				"                                \"panNum\": \""+PANNumber+"\",\r\n" + 
				"                                \"targetService\": \"panAadharLink\"\r\n" + 
				"                }\r\n" + 
				"}";
		logger.info("inputJson_PANLINKAGE: "+inputJson); 
		StringEntity stringEntity;
		StringBuffer result = new StringBuffer();
		try {
			stringEntity = new StringEntity(inputJson);
			httpPost.setEntity(stringEntity);
			System.out.println("Executing request " + httpPost.getRequestLine());

			HttpResponse response = httpclient.execute(httpPost);

			BufferedReader br = new BufferedReader(
					new InputStreamReader((response.getEntity().getContent())));


			//Throw runtime exception if status code isn't 200
			if (response.getStatusLine().getStatusCode() != 200) {
				throw new RuntimeException("Failed : HTTP error code : "
						+ response.getStatusLine().getStatusCode());
			}


			//Create the StringBuffer object and store the response into it.
			
			String line = "";
			while ((line = br.readLine()) != null) {
			result.append(line);
			}

			logger.info("OutputJson_PANLINKAGE: "+result); 
			//Lets validate if a text 'employee_salary' is present in the response 
			//System.out.println( result.toString());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	return result.toString();
	}


	
	private static String callAPI_DOB(String url, String string, HashMap<String, String> hm, String clientData) {
		String cData[] = clientData.split("~~");
		String PANNumber="",fname="",lname="",dob="",mob="";
		if(cData.length>0){
	        PANNumber = cData[0].trim();
	        fname = cData[1].trim();
	        lname = cData[2].trim();
	        dob = cData[3].trim();
	        mob = cData[4].trim();
		}
		
		String postEndpoint = url;
		CloseableHttpClient httpclient = HttpClients.createDefault();
		HttpPost httpPost = new HttpPost(postEndpoint);
		
		for (String i : hm.keySet()) {
			httpPost.setHeader(i, hm.get(i)); // set userId
		}
		
		String inputJson = "{\r\n" + 
				"                \"metadata\":{\r\n" + 
				"                                \"X-Correlation-ID\":\"1234567890\",\r\n" + 
				"                                \"X-App-ID\":\"Dolphin\"\r\n" + 
				"                },\r\n" + 
				"                \"payload\":{\r\n" + 
				"                                \"firstName\": \""+fname+"\",\r\n" + 
				"                                \"middleName\": \"\",\r\n" + 
				"                                \"lastName\": \""+lname+"\",\r\n" + 
				"                                \"dob\": \""+dob+"\",\r\n" + 
				"                                \"gender\": \"\",\r\n" + 
				"                                \"careOf\": \"\",\r\n" + 
				"                                \"houseNum\": \"\",\r\n" + 
				"                                \"street\": \"\",\r\n" + 
				"                                \"landmark\": \"\",\r\n" + 
				"                                \"location\": \"\",\r\n" + 
				"                                \"postOffice\": \"\",\r\n" + 
				"                                \"villageOrCity\": \"\",\r\n" + 
				"                                \"subDistrict\": \"\",\r\n" + 
				"                                \"district\": \"\",\r\n" + 
				"                                \"state\": \"\",\r\n" + 
				"                                \"stateCode\": \"\",\r\n" + 
				"                                \"postalCode\": \"\",\r\n" + 
				"                                \"mobNum\": \""+mob+"\",\r\n" + 
				"                                \"panNum\": \""+PANNumber+"\",\r\n" + 
				"                                \"validationType\": \"DOB\"\r\n" + 
				"                }\r\n" + 
				"}";
		logger.info("inputJson_DOB: "+inputJson); 
		StringEntity stringEntity;
		StringBuffer result = new StringBuffer();
		try {
			stringEntity = new StringEntity(inputJson);
			httpPost.setEntity(stringEntity);
			System.out.println("Executing request " + httpPost.getRequestLine());

			HttpResponse response = httpclient.execute(httpPost);

			BufferedReader br = new BufferedReader(
					new InputStreamReader((response.getEntity().getContent())));


			//Throw runtime exception if status code isn't 200
			if (response.getStatusLine().getStatusCode() != 200) {
				throw new RuntimeException("Failed : HTTP error code : "
						+ response.getStatusLine().getStatusCode());
			}
			String line = "";
			while ((line = br.readLine()) != null) {
			result.append(line);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	return result.toString();

	}
}
