package com.newgen.services;

import java.util.HashMap;

import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.newgen.gui.*;

public class MyAgent {
	static Logger logger = Logger.getLogger("MyAgent");

	public static String MyAgentService(String token, String inputJson) {

		logger.info("parameters: " + inputJson);

		HashMap<String, String> hm = new HashMap<>();
		String returnString = "", CorrelationID, AppID, url, response;
		/*String msgCode = "500", valid, agentCode1 = "", agentCode2 = "";
		String params[] = parameters.split("\\|",-1);
		JSONParser jsonParser = new JSONParser();
		JSONObject json;
		Object ulipStatus, contactNum, branchName, channelName, dtOfJoining, trainingStartingDtAMLCurr,
				trainingStartingDtAMLPrev, trainingStartingDtULCurr, trainingStartingDtULPrev,
				trainingCompletionDtAMLCurr, trainingCompletionDtAMLPrev, trainingCompletionDtULCurr,
				trainingCompletionDtULPrev, reportingTo, reportingToName, registrationNumber, solId, ssnCodes,
				applicationId, servBrId,agentStatus,agentName,agentEmailId;
		if (params[0].contains("^")) {
			String agentArr[] = params[0].split("\\^",-1);
			agentCode1 = agentArr[0];
			agentCode2 = agentArr[1];
		} else
			agentCode1 = params[0];*/

		hm.put("Content-Type", "application/json");
		hm.put("x-api-key", Server.propertiesFileData.getProperty("ApiKey"));
		hm.put("cache-control", "no-cache");
		hm.put("host", Server.propertiesFileData.getProperty("Host"));
		hm.put("Authorization", token);

		logger.info("token: " + token);

		url = Server.propertiesFileData.getProperty("MyAgentUrl");
		CorrelationID = Server.propertiesFileData.getProperty("CorrelationID");
		AppID = Server.propertiesFileData.getProperty("AppID");

		/*inputJson = "{\"metadata\":{\"X-Correlation-ID\":\"1234567890\",\"X-App-ID\":\"DOLPHIN\"},\"payload\":{\"agentId1\":\""
				+ agentCode1 + "\",\"spNo1\":\"" + params[1] + "\",\"agentId2\":\"" + agentCode2 + "\",\"spNo2\":\""
				+ params[1] + "\",\"twoAgents\":\"n\",\"channel\":\"" + params[2]
				+ "\",\"branchCode\":\"\",\"type\":\"CertificationDetailsRequest\",\"transTrackingId\":\"\",\"customerSignDate\":\""
				+ params[3] + "\",\"insuranceStatus\":\"" + params[4] + "\",\"splitRatio\":\"" + params[5]
				+ "\",\"productType\":\"" + params[6] + "\",\"customerPan\":\"" + params[7] + "\"}}";*/

		
		logger.info("URL ---" + url);
		logger.info("InputJson ---" + inputJson);
		response = MyMoney.callRestAPI(url, "POST", hm, inputJson);
		logger.info("response---------- " + response);

		/*try {
			json = (JSONObject) jsonParser.parse(response);

			JSONObject msginfoObj = (JSONObject) json.get("msgInfo");

			if (msginfoObj != null)
				msgCode = msginfoObj.get("msgCode").toString();

			if (msgCode.equalsIgnoreCase("200")) {
				JSONObject payload = (JSONObject) json.get("payload");
				valid = payload.get("valid").toString();
				if (valid.equalsIgnoreCase("true")) {
					ulipStatus = payload.get("ulipStatus");
					contactNum = payload.get("contactNum");
					branchName = payload.get("branchName");
					channelName = payload.get("channelName");
					dtOfJoining = payload.get("dtOfJoining");
					trainingStartingDtAMLCurr = payload.get("trainingStartingDtAMLCurr");
					trainingStartingDtAMLPrev = payload.get("trainingStartingDtAMLPrev");
					trainingStartingDtULCurr = payload.get("trainingStartingDtULCurr");
					trainingStartingDtULPrev = payload.get("trainingStartingDtULPrev");
					trainingCompletionDtAMLCurr = payload.get("trainingCompletionDtAMLCurr");
					trainingCompletionDtAMLPrev = payload.get("trainingCompletionDtAMLPrev");
					trainingCompletionDtULCurr = payload.get("trainingCompletionDtULCurr");
					trainingCompletionDtULPrev = payload.get("trainingCompletionDtULPrev");
					reportingTo = payload.get("reportingTo");
					reportingToName = payload.get("reportingToName");
					registrationNumber = payload.get("registrationNumber");
					solId = payload.get("solId");
					ssnCodes = payload.get("ssnCodes");
					applicationId = payload.get("applicationId");
					servBrId = payload.get("servBrId");
					agentStatus = payload.get("agentStatus");
					agentName = payload.get("agentName");
					agentEmailId = payload.get("agentEmailId");
					
					returnString = valid + "|" + ulipStatus + "|" + contactNum + "|" + branchName + "|" + channelName
							+ "|" + dtOfJoining + "|" + trainingStartingDtAMLCurr + "|" + trainingStartingDtAMLPrev
							+ "|" + trainingStartingDtULCurr + "|" + trainingStartingDtULPrev + "|"
							+ trainingCompletionDtAMLCurr + "|" + trainingCompletionDtAMLPrev + "|"
							+ trainingCompletionDtULCurr + "|" + trainingCompletionDtULPrev + "|" + reportingTo + "|"
							+ reportingToName + "|" + registrationNumber + "|" + solId + "|" + ssnCodes + "|"
							+ applicationId + "|" + servBrId+ "|" +agentStatus+ "|" +agentName+ "|" +agentEmailId;
				}
				else
					returnString="false";
				logger.info("returnString---------- " + returnString);
			}
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		return response;
	}
	public static String MyManagerService(String token, String inputJson) {

		logger.info("parameters: " + inputJson);

		HashMap<String, String> hm = new HashMap<>();
		String returnString = "", CorrelationID, AppID, url, response;
		/*String msgCode = "500", valid, agentCode1 = "", agentCode2 = "";
		String params[] = parameters.split("\\|",-1);
		JSONParser jsonParser = new JSONParser();
		JSONObject json;
		Object ulipStatus, contactNum, branchName, channelName, dtOfJoining, trainingStartingDtAMLCurr,
				trainingStartingDtAMLPrev, trainingStartingDtULCurr, trainingStartingDtULPrev,
				trainingCompletionDtAMLCurr, trainingCompletionDtAMLPrev, trainingCompletionDtULCurr,
				trainingCompletionDtULPrev, reportingTo, reportingToName, registrationNumber, solId, ssnCodes,
				applicationId, servBrId,agentStatus,agentName,agentEmailId;
		if (params[0].contains("^")) {
			String agentArr[] = params[0].split("\\^",-1);
			agentCode1 = agentArr[0];
			agentCode2 = agentArr[1];
		} else
			agentCode1 = params[0];*/

		hm.put("Content-Type", "application/json");
		hm.put("x-api-key", Server.propertiesFileData.getProperty("ApiKey"));
		hm.put("cache-control", "no-cache");
		hm.put("host", Server.propertiesFileData.getProperty("Host"));
		hm.put("Authorization", token);

		logger.info("token: " + token);

		url = Server.propertiesFileData.getProperty("MyManagerUrl");
		CorrelationID = Server.propertiesFileData.getProperty("CorrelationID");
		AppID = Server.propertiesFileData.getProperty("AppID");

		/*inputJson = "{\"metadata\":{\"X-Correlation-ID\":\"1234567890\",\"X-App-ID\":\"DOLPHIN\"},\"payload\":{\"agentId1\":\""
				+ agentCode1 + "\",\"spNo1\":\"" + params[1] + "\",\"agentId2\":\"" + agentCode2 + "\",\"spNo2\":\""
				+ params[1] + "\",\"twoAgents\":\"n\",\"channel\":\"" + params[2]
				+ "\",\"branchCode\":\"\",\"type\":\"CertificationDetailsRequest\",\"transTrackingId\":\"\",\"customerSignDate\":\""
				+ params[3] + "\",\"insuranceStatus\":\"" + params[4] + "\",\"splitRatio\":\"" + params[5]
				+ "\",\"productType\":\"" + params[6] + "\",\"customerPan\":\"" + params[7] + "\"}}";*/

		
		logger.info("URL ---" + url);
		logger.info("InputJson ---" + inputJson);
		response = MyMoney.callRestAPI(url, "POST", hm, inputJson);
		logger.info("response---------- " + response);

		/*try {
			json = (JSONObject) jsonParser.parse(response);

			JSONObject msginfoObj = (JSONObject) json.get("msgInfo");

			if (msginfoObj != null)
				msgCode = msginfoObj.get("msgCode").toString();

			if (msgCode.equalsIgnoreCase("200")) {
				JSONObject payload = (JSONObject) json.get("payload");
				valid = payload.get("valid").toString();
				if (valid.equalsIgnoreCase("true")) {
					ulipStatus = payload.get("ulipStatus");
					contactNum = payload.get("contactNum");
					branchName = payload.get("branchName");
					channelName = payload.get("channelName");
					dtOfJoining = payload.get("dtOfJoining");
					trainingStartingDtAMLCurr = payload.get("trainingStartingDtAMLCurr");
					trainingStartingDtAMLPrev = payload.get("trainingStartingDtAMLPrev");
					trainingStartingDtULCurr = payload.get("trainingStartingDtULCurr");
					trainingStartingDtULPrev = payload.get("trainingStartingDtULPrev");
					trainingCompletionDtAMLCurr = payload.get("trainingCompletionDtAMLCurr");
					trainingCompletionDtAMLPrev = payload.get("trainingCompletionDtAMLPrev");
					trainingCompletionDtULCurr = payload.get("trainingCompletionDtULCurr");
					trainingCompletionDtULPrev = payload.get("trainingCompletionDtULPrev");
					reportingTo = payload.get("reportingTo");
					reportingToName = payload.get("reportingToName");
					registrationNumber = payload.get("registrationNumber");
					solId = payload.get("solId");
					ssnCodes = payload.get("ssnCodes");
					applicationId = payload.get("applicationId");
					servBrId = payload.get("servBrId");
					agentStatus = payload.get("agentStatus");
					agentName = payload.get("agentName");
					agentEmailId = payload.get("agentEmailId");
					
					returnString = valid + "|" + ulipStatus + "|" + contactNum + "|" + branchName + "|" + channelName
							+ "|" + dtOfJoining + "|" + trainingStartingDtAMLCurr + "|" + trainingStartingDtAMLPrev
							+ "|" + trainingStartingDtULCurr + "|" + trainingStartingDtULPrev + "|"
							+ trainingCompletionDtAMLCurr + "|" + trainingCompletionDtAMLPrev + "|"
							+ trainingCompletionDtULCurr + "|" + trainingCompletionDtULPrev + "|" + reportingTo + "|"
							+ reportingToName + "|" + registrationNumber + "|" + solId + "|" + ssnCodes + "|"
							+ applicationId + "|" + servBrId+ "|" +agentStatus+ "|" +agentName+ "|" +agentEmailId;
				}
				else
					returnString="false";
				logger.info("returnString---------- " + returnString);
			}
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		return response;
	}

}
