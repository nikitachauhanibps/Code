package com.newgen.services;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.HashMap;

import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.newgen.gui.Server;

public class Test {
	public static void main(String[] args) {
		
		HashMap<String, String> hm = new HashMap<>();
		//for dev
//		hm.put("Content-Type", "application/json");        
//        hm.put("x-api-key", "DTUDHv9UVG8cVT3qmhiSv1UcnvCduzLf1CI6zCVY");
//        hm.put("auth-token", token);
		//String jsonString = callRestAPI("https://r4kss4uo26.execute-api.ap-south-1.amazonaws.com/developer/microservices/mli/qc/micrifsc/v1", "POST", hm);
		String jsonString = "";
		//for SIT
		hm.put("Content-Type", "application/json");        
        hm.put("x-api-key", "aOSXr7Ucv72I0vkNoRGCG1OUTEI2H2wy1auJ6443");        
        hm.put("cache-control", "no-cache");
        hm.put("host", "3ympjv2vhl.execute-api.ap-south-1.amazonaws.com");
        hm.put("Authorization", "eyJraWQiOiJ1Q2JoRnVpUENpWjZGNTNwcGNkaElub1FQTmQ5aExOd1wvS3QzcUFJa3FhVT0iLCJhbGciOiJSUzI1NiJ9.eyJzdWIiOiJiZDc1ZDVhNC1kN2I0LTRmNWUtYTY4NC1kYTFmYjhlNGI5ZWYiLCJhdWQiOiIyaGhvcGJsb2hrZ3ZodWNyM3ZkN3Q1aHB1bSIsImV2ZW50X2lkIjoiYmRiY2ViNmYtZTcyNy00NmI4LWI2OWMtMjQ0ODg1NThmM2ZkIiwidG9rZW5fdXNlIjoiaWQiLCJhdXRoX3RpbWUiOjE1OTY3MTQxMTQsImlzcyI6Imh0dHBzOlwvXC9jb2duaXRvLWlkcC5hcC1zb3V0aC0xLmFtYXpvbmF3cy5jb21cL2FwLXNvdXRoLTFfdTVrSE1LRFhOIiwiY29nbml0bzp1c2VybmFtZSI6ImRvbHBoaW5zaXQxIiwiZXhwIjoxNTk2NzE3NzE0LCJpYXQiOjE1OTY3MTQxMTR9.BRV7G-VEZGeKLCt5c_QRjpgr6AbJ4oE0j7TMMxihC0evTp5MIOU9EyTlC6Hm5SamS7ibVkicVEQM-zo5UO6Z1Y-Z5P4llAB0Vz3j4rI-joU58iPg6niXfjPZkAn3VpkLzdNSoK1rfh08W3somEB3tNATJnKxiBZ468BSu1dlNjAGtmvIZAAz368gyDnZKL-iAdUSzzmNKJT0jlGCHVPd4p2K-Gx4z7bA8hRlurXjIVHJwFJ1TD8YE5h4Zt--eXL-iSAdpWRj0sNiFncSMqGovDQoO7UsIe2_TaLZ2-ffInE7Er5oAe9dWVPpLGwgckJHxvJl9DmslP4iPt_As8UT-g");
        
        String url = "https://avpce-061adb3502e0c019f-9i6467l6.execute-api.ap-south-1.vpce.amazonaws.com/sit1/sit1-dolphin-validations";
        System.out.println("url: "+url);
        //jsonString = callRestAPI(url, "POST", hm, data);
        jsonString = callAPI(url, "POST", hm, "ICIC0000072");
		System.out.println("jsonString: "+jsonString);	
		
	}
	private static String callAPI(String url, String string, HashMap<String, String> hm, String ifscCode) {
		// TODO Auto-generated method stub
			String postEndpoint = url;
			CloseableHttpClient httpclient = HttpClients.createDefault();
			HttpPost httpPost = new HttpPost(postEndpoint);
			
			for (String i : hm.keySet()) {
				httpPost.setHeader(i, hm.get(i)); // set userId
			}
			
			String inputJson = "{\r\n" + 
							"    \"metadata\": {\r\n" + 
							"      \"X-App-ID\": \"IBPS\",\r\n" + 
							"      \"X-Correlation-ID\": \"1234567890\"\r\n" + 
							"    },\r\n" + 
							"    \"payload\": {\r\n" + 
							"      \"bankIfscCode\": \""+ifscCode+"\",                         \r\n" + 
							"      \"bankMicrCode\": \"\"\r\n" + 
							"    }\r\n" + 
							"}";
			
			StringEntity stringEntity;
			StringBuffer result = new StringBuffer();
			try {
				stringEntity = new StringEntity(inputJson);
				httpPost.setEntity(stringEntity);
				System.out.println("Executing request " + httpPost.getRequestLine());

				HttpResponse response = httpclient.execute(httpPost);

				BufferedReader br = new BufferedReader(
						new InputStreamReader((response.getEntity().getContent())));


				//Throw runtime exception if status code isn't 200
				if (response.getStatusLine().getStatusCode() != 200) {
					throw new RuntimeException("Failed : HTTP error code : "
							+ response.getStatusLine().getStatusCode());
				}


				//Create the StringBuffer object and store the response into it.
				
				String line = "";
				while ((line = br.readLine()) != null) {
				result.append(line);
				}


				//Lets validate if a text 'employee_salary' is present in the response 
				//System.out.println( result.toString());
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		return result.toString();
	}

}
