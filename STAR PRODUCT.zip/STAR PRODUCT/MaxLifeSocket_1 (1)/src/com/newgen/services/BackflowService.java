package com.newgen.services;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;

import org.apache.log4j.Logger;

public class BackflowService {
	static Logger logger = Logger.getLogger("BackflowService");
	public String maskAadhaar(String token, String data) {
		HashMap<String, String> hm = new HashMap<>();
		hm.put("Content-Type", "application/json");        
        hm.put("x-api-key", "DTUDHv9UVG8cVT3qmhiSv1UcnvCduzLf1CI6zCVY");
        hm.put("auth-token", token);
		//String jsonString = callRestAPI("https://r4kss4uo26.execute-api.ap-south-1.amazonaws.com/developer/microservices/mli/dolphin/api/LeMS/ftsp", "POST", hm);
		String jsonString = "";
		//to be removed later
		jsonString  = "{\r\n" + 
				"            \"metadata\": {\r\n" + 
				"                \"soaCorrelationId\": \"1234567890\",\r\n" + 
				"                \"appId\": \"IBPS\"\r\n" + 
				"            },\r\n" + 
				"            \"aadharResponse\": {\r\n" + 
				"                \"payload\": null,\r\n" + 
				"                \"msgInfo\": {\r\n" + 
				"                    \"msgCode\": \"500\",\r\n" + 
				"                    \"msg\": \"Failed\",\r\n" + 
				"                    \"msgDescription\": \"Some exception occured\"\r\n" + 
				"                }\r\n" + 
				"            },\r\n" + 
				"\"status\": true\r\n" + 
				"}";
		return jsonString;
	}
	public String callRestAPI(String url, String method, HashMap<String, String> request) {
		URL urlForGetRequest;
		String data = "";
		String readLine = null;
		String returnJSON = "", returnVal = null;
		HttpURLConnection conection;
		try {
			urlForGetRequest = new URL(url);
			conection = (HttpURLConnection) urlForGetRequest.openConnection();
			conection.setRequestMethod(method);

			// System.out.println(url);
			// System.out.println(method);
			for (String i : request.keySet()) {
				conection.setRequestProperty(i, request.get(i)); // set userId
																	// its a
																	// sample
																	// here
			}
			// conection.setRequestProperty("Authorization", "Basic
			// YzBiYThiNmYtZTNiMC00NjU5LTkwNDktNmNjOGVlYzhhYzRiOlhSY3B4ZWxZQVhHNnR3VFlQcmxRUXBhN1RFc1haY2lp");
			// // set userId its a sample here
			// conection.setRequestProperty("Content-Type",
			// "application/x-www-form-urlencoded"); // set userId its a sample
			// here

			conection.setDoOutput(true);

			if (method.equalsIgnoreCase("POST")) {
			
				
				
				//data = "{\"metadata\": {    \"appId\": \"IBPS\",    \"soaCorrelationId\": \"31873127329799381273192\"},\"payload\": {    \"username\": \"ibps\",    \"password\": \"Ibps@123\"}}";
				data = "{\r\n" + 
						"                \"metadata\":{\r\n" + 
						"                                \"soaCorrelationId\":\"1234567890\",\r\n" + 
						"                                \"appId\":\"IBPS\"\r\n" + 
						"                },\r\n" + 
						"                \"aadharRequest\":{\r\n" + 
						"                                \"aadharNumber\":\"390560404695\"\r\n" + 
						"                }\r\n" + 
						"}";
				OutputStreamWriter obj = new OutputStreamWriter(conection.getOutputStream());
				obj.write(data);
				obj.close();

			}
			/*
			 * else if(method.equalsIgnoreCase("GET")) { apiCount++;
			 * logger.info("API Count " + apiCount); }
			 */

			int responseCode = conection.getResponseCode();
			System.out.println(responseCode);
			if (responseCode == HttpURLConnection.HTTP_OK) {
				BufferedReader in = new BufferedReader(new InputStreamReader(conection.getInputStream()));
				StringBuffer response = new StringBuffer();
				while ((readLine = in.readLine()) != null) {
					response.append(readLine);
				}
				in.close();

				returnJSON = response.toString();
				// System.out.println("JSON String Result " +
				// response.toString());
				returnVal = returnJSON;
			} else {
				// logger.info("responseCode " + responseCode);
				System.out.println("responseCode " + responseCode);
				// Ariba disconnectUser = new Ariba();
				// disconnectUser.disconnectUser();
				returnVal = "ERROR";
			}
		} catch (IOException ex) {
			// logger.error("Exception in calling RestAPI Method----" +
			// ex.toString());
			System.out.println("Exception in calling RestAPI Method----" + ex.toString());
			// new Ariba().runDbquery(Ariba.emailTriggerQuery);
			ex.printStackTrace();
		}
		return returnVal;
	}
}
