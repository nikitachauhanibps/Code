package com.newgen.services;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.Properties;

import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.newgen.gui.Server;

public class MICR_IFSC {
	static Logger logger = Logger.getLogger("MICR_IFSC");
	public static String generateResponse(String token, String data) {
		logger.info("data: "+data);
		HashMap<String, String> hm = new HashMap<>();
		//for dev
//		hm.put("Content-Type", "application/json");        
//        hm.put("x-api-key", "DTUDHv9UVG8cVT3qmhiSv1UcnvCduzLf1CI6zCVY");
//        hm.put("auth-token", token);
		//String jsonString = callRestAPI("https://r4kss4uo26.execute-api.ap-south-1.amazonaws.com/developer/microservices/mli/qc/micrifsc/v1", "POST", hm);
		String jsonString = "";
		//for SIT
		hm.put("Content-Type", "application/json");  
		
        hm.put("x-api-key", Server.propertiesFileData.getProperty("ApiKey"));
        logger.info("x-api-key"+ Server.propertiesFileData.getProperty("ApiKey"));
        
        hm.put("cache-control", "no-cache");
        hm.put("host", Server.propertiesFileData.getProperty("Host"));
        logger.info("host"+Server.propertiesFileData.getProperty("Host"));
        hm.put("Authorization", token);
        logger.info("Authorization"+ token);
        
        logger.info(hm.toString());
        
        String url = Server.propertiesFileData.getProperty("ValidationsURL");
        logger.info("url: "+url);
        //jsonString = callRestAPI(url, "POST", hm, data);
        jsonString = callAPI(url, "POST", hm, data);
        logger.info("jsonString: "+jsonString);	
		logger.info("jsonString: "+jsonString);
		return jsonString;
	}
	private static String callAPI(String url, String string, HashMap<String, String> hm, String ifscCode) {
	// TODO Auto-generated method stub
		logger.info("isnide callAPI");
		String postEndpoint = url;
		CloseableHttpClient httpclient = HttpClients.createDefault();
		HttpPost httpPost = new HttpPost(postEndpoint);
		
		logger.info("before for HM");
		for (String i : hm.keySet()) {
			httpPost.setHeader(i, hm.get(i)); // set userId
		}
		logger.info("after for HM");
		
		String inputJson = "{\r\n" + 
						"    \"metadata\": {\r\n" + 
						"      \"X-App-ID\": \"IBPS\",\r\n" + 
						"      \"X-Correlation-ID\": \"1234567890\"\r\n" + 
						"    },\r\n" + 
						"    \"payload\": {\r\n" + 
						"      \"bankIfscCode\": \""+ifscCode+"\",                         \r\n" + 
						"      \"bankMicrCode\": \"\"\r\n" + 
						"    }\r\n" + 
						"}";
		logger.info("inputJson: "+inputJson);
		StringEntity stringEntity;
		StringBuffer result = new StringBuffer();
		try {
			stringEntity = new StringEntity(inputJson);
			httpPost.setEntity(stringEntity);
			logger.info("before executing req");
			System.out.println("Executing request " + httpPost.getRequestLine());
			logger.info("after executing req");
			HttpResponse response = httpclient.execute(httpPost);

			BufferedReader br = new BufferedReader(
					new InputStreamReader((response.getEntity().getContent())));


			//Throw runtime exception if status code isn't 200
			if (response.getStatusLine().getStatusCode() != 200) {
				throw new RuntimeException("Failed : HTTP error code : "
						+ response.getStatusLine().getStatusCode());
			}

			
			
			//Create the StringBuffer object and store the response into it.
			
			String line = "";
			while ((line = br.readLine()) != null) {
			result.append(line);
			}

			logger.info("result--"+result.toString());
			//Lets validate if a text 'employee_salary' is present in the response 
			//System.out.println( result.toString());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.info("inside catch");
			logger.error(e.toString());
			
		}
		
	return result.toString();
}
	
}
