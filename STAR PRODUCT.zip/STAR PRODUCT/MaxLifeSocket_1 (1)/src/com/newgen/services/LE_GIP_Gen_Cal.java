package com.newgen.services;

import java.util.HashMap;
import org.apache.log4j.Logger;
import com.newgen.gui.Server;

public class LE_GIP_Gen_Cal {
	static Logger logger = Logger.getLogger("LE_GIP");
	public static String generateDOC(String token, String serverData, String flag,String planCode) {
		logger.info("planCode: "+planCode);
		logger.info("flag: "+flag);
		HashMap<String, String> hm = new HashMap<>();
		//for SIT
        hm.put("Content-Type", "application/json");        
        hm.put("x-api-key", Server.propertiesFileData.getProperty("ApiKey"));        
        hm.put("cache-control", "no-cache");
        hm.put("host", Server.propertiesFileData.getProperty("Host"));
        hm.put("Authorization", token);
        
        String url="";
        if(flag.equalsIgnoreCase("Generate"))	//illustration for document generation
        	url = Server.propertiesFileData.getProperty("LE_GenDocUrl");
        else        							//calculation of premium
        	url = Server.propertiesFileData.getProperty("LE_CalcPremiumUrl");
        
        logger.info("url---- "+url);	
        logger.info("inputJson ----"+serverData);
		String jsonString = "";
		jsonString = MyMoney.callRestAPI(url,"POST", hm, serverData);
		logger.info(" LE_GIP_Gen_Cal response----------: "+jsonString);		
		return jsonString;
	}	
}
