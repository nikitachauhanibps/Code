package com.newgen.services;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.HashMap;

import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.newgen.gui.*;

public class MyMoney {
	static Logger logger = Logger.getLogger("MyMoney");
	static Logger restLogger = Logger.getLogger("CallRestAPI");
	
	public static String MyMoneyService(String token, String parameters) {
		
		logger.info("parameters: " + parameters);
		
		HashMap<String, String> hm = new HashMap<>();
		String returnString = "", inputJson, CorrelationID, AppID, url, response;
		String msgCode = "500", moneySatatus, collectedAmount, clearAmount, bounceAmount,paymentdate;
		String params[] = parameters.split("\\|");
		JSONParser jsonParser = new JSONParser();
		JSONObject json;
		
		hm.put("Content-Type", "application/json");
		hm.put("x-api-key", Server.propertiesFileData.getProperty("ApiKey"));
		hm.put("cache-control", "no-cache");
		hm.put("host", Server.propertiesFileData.getProperty("Host"));
		hm.put("Authorization", token);
		
		logger.info("token: " + token);
		
		url = Server.propertiesFileData.getProperty("MyMoneyUrl");
		CorrelationID = Server.propertiesFileData.getProperty("CorrelationID");
		AppID = Server.propertiesFileData.getProperty("AppID");

		inputJson = "{\"metadata\":{\"X-Correlation-ID\":\"" + CorrelationID + "\",\"X-App-ID\":\"" + AppID
				+ "\",\"proposalNumber\":\""+params[0]+"\"},\"payload\":{\"policyNo\":\"" + params[0] + "\",\"premiumAmount\":\"" + params[1] + "\"}}";
		
		logger.info("url--------: " + url);
		logger.info("inputJson ------: " + inputJson);
		
		response = callRestAPI(url, "POST", hm, inputJson);
		logger.info("response: " + response);
		try {
			json = (JSONObject) jsonParser.parse(response);

			JSONObject msginfoObj = (JSONObject) json.get("msgInfo");
			
			if (msginfoObj != null)
				msgCode = msginfoObj.get("msgCode").toString();

			if (msgCode.equalsIgnoreCase("200")) {
				JSONObject payload = (JSONObject) json.get("payload");
				moneySatatus = payload.get("status").toString();
				collectedAmount = payload.get("collectedAmount").toString();
				clearAmount = payload.get("clearAmount").toString();
				bounceAmount = payload.get("bounceAmount").toString();
				paymentdate = payload.get("paymentDate").toString();
				returnString=moneySatatus+"|"+collectedAmount+"|"+clearAmount+"|"+bounceAmount+"|"+paymentdate;
			}
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return returnString;
	}

	public static String callRestAPI(String url, String method, HashMap<String, String> request, String inputJson) {
		String resultValue = "";
		try {
			restLogger.info("URL ---" + url);
			restLogger.info("InputJson ---" + inputJson);

			String postEndpoint = url;

			CloseableHttpClient httpclient = HttpClients.createDefault();

			HttpPost httpPost = new HttpPost(postEndpoint);

			/*
			 * httpPost.setHeader("Accept", "application/json");
			 * httpPost.setHeader("Content-type", "application/json");
			 */

			for (String i : request.keySet()) {
				httpPost.setHeader(i, request.get(i));
				restLogger.info("Header  ---" + i + ":" + request.get(i));
			}

			StringEntity stringEntity = new StringEntity(inputJson);
			httpPost.setEntity(stringEntity);

			restLogger.info("Executing request " + httpPost.getRequestLine());

			HttpResponse response = httpclient.execute(httpPost);

			BufferedReader br = new BufferedReader(new InputStreamReader((response.getEntity().getContent())));

			// Throw runtime exception if status code isn't 200
			if (response.getStatusLine().getStatusCode() != 200) {
				throw new RuntimeException("Failed : HTTP error code : " + response.getStatusLine().getStatusCode());
			}

			// Create the StringBuffer object and store the response into it.
			StringBuffer result = new StringBuffer();
			String line = "";
			while ((line = br.readLine()) != null) {
				System.out.println("Response : \n" + result.append(line));
			}
			resultValue = result.toString();
		} catch (Exception e) {
			restLogger.info("Error in calling restAPI" + e);
		}
		return resultValue;
	}
}