package com.newgen.gui;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;
import java.util.Properties;

import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.newgen.services.AadhaarMasking;
import com.newgen.services.CreateClient_API;
import com.newgen.services.Dedupe_API;
import com.newgen.services.EDCValidateService;
import com.newgen.services.GovernanceValidateService;
import com.newgen.services.LE_FGEP_Gen_Cal;
import com.newgen.services.LE_FTSP_Gen_Cal;
import com.newgen.services.LE_FWP_Gen_Cal;
import com.newgen.services.LE_FYPP_Gen_Cal;
import com.newgen.services.LE_GenerateDocument;
import com.newgen.services.LE_LPPS_Gen_Cal;
import com.newgen.services.LE_MIAP_Gen_Cal;
import com.newgen.services.LE_OSP_Gen_Cal;
import com.newgen.services.LE_OTP_Gen_Cal;
import com.newgen.services.LE_PWP_Gen_Cal;
import com.newgen.services.LE_SAP_Gen_Cal;
import com.newgen.services.LE_SPS_Gen_Cal;
import com.newgen.services.LE_STP_Gen_Cal;
import com.newgen.services.LE_SWP_Gen_Cal;
import com.newgen.services.LE_SJB_Gen_Cal;
import com.newgen.services.LE_WLS_Gen_Cal;
import com.newgen.services.MICR_IFSC;
import com.newgen.services.MyAgent;
import com.newgen.services.MyMoney;
import com.newgen.services.PSM_API;
import com.newgen.services.PolicySplitAPI;
import com.newgen.services.validatePAN_DOB;
import com.newgen.services.LE_GIP_Gen_Cal;
import com.newgen.services.LE_SSP_Gen_Cal;
import com.newgen.services.CLIENT_LEVEL_CHECK_API;
import com.newgen.services.LE_GLIP_Gen_Cal;
import com.newgen.services.LE_SPP_Gen_Cal;
import com.newgen.services.LE_SWIP_Gen_Cal;
import com.newgen.services.LE_FWAP_Gen_Cal;
import com.newgen.services.LE_SGPP_Gen_Cal;
import com.newgen.services.LE_CIP_Gen_Cal;
import com.newgen.services.LE_CG_Gen_Cal;
import com.newgen.services.LE_SFRD_Gen_Cal;
import com.newgen.services.LE_SWAGP_Gen_Cal;
import com.newgen.services.LE_SEWA_Gen_Cal;
import com.newgen.services.LE_STEP_Gen_Cal;
import com.newgen.services.LE_CG1_Gen_Cal;
import com.newgen.services.LE_CG3_Gen_Cal;
import com.newgen.services.LE_SWAGPP_Gen_Cal;
import com.newgen.services.LE_SWAGE_Gen_Cal;
import com.newgen.services.LE_CG4_Gen_Cal;
import com.newgen.services.LE_STPP_Gen_Cal;
import com.newgen.services.LE_STAR_Gen_Cal;

//Server class 
public class Server {
	public static Properties propertiesFileData;
	public static String token;
	static Logger logger = Logger.getLogger("Server");
	public static void main(String[] args) {
		try {
			propertiesFileData = new Properties();
			Properties props = new Properties();
			
			String configPath = System.getProperty("user.dir") + File.separator + "log4j.properties";
			try {
				props.load(new FileInputStream(configPath));
			} catch (FileNotFoundException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			PropertyConfigurator.configure(props);		
			
			configPath = System.getProperty("user.dir") + File.separator + "SocketProperties.properties";
	        FileReader reader = null;
			try {
				reader = new FileReader(configPath);
			} catch (FileNotFoundException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
	        
	         logger.info("configPath: "+configPath);
	        
	        propertiesFileData = new Properties();
			try {
				propertiesFileData.load(reader);
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}		 
			
			// server is listening on port 5056
			ServerSocket ss = new ServerSocket(Integer.parseInt(propertiesFileData.getProperty("port")));			
			System.out.println("server is running......");
			while (true) {
				System.out.println("waiting for new request");
				Socket s = null;
				try {
					// socket object to receive incoming client requests
					s = ss.accept();

					System.out.println("A new client is connected : " + s);
					s.setSoTimeout(Integer.parseInt(propertiesFileData.getProperty("timeout"))*1000);
					// obtaining input and out streams
					DataInputStream dis = new DataInputStream(s.getInputStream());
					DataOutputStream dos = new DataOutputStream(s.getOutputStream());
					
					//bug 1081029
					System.out.println("Assigning new thread for this client");

					// create a new thread object
					Thread t = new ClientHandler(s, dis, dos,logger);

					// Invoking the start() method
					t.start();

				} catch (Exception e) {
					s.close();
					e.printStackTrace();
				}

			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}

// ClientHandler class
class ClientHandler extends Thread {
	final DataInputStream dis;
	final DataOutputStream dos;
	final Socket s;	
	final Logger logger;
	//private Properties props;
	
	// Constructor
	public ClientHandler(Socket s, DataInputStream dis, DataOutputStream dos,Logger logger) {
		this.s = s;
		this.dis = dis;
		this.dos = dos;
		this.logger = logger;
	}

	@Override
	public void run() {
		//validatePAN_DOB VPD = new validatePAN_DOB();
		//LE_GenerateDocument LGD = new LE_GenerateDocument();
		//MICR_IFSC MICR = new MICR_IFSC();
		//AadhaarMasking MaskAadhaar = new AadhaarMasking();		
		try {
			//Validate PAN DOB
			//to be uncomment later
			//String token = generateToken();
			
			//propertiesFileData = new Properties();
//			props = new Properties();
			
			//configPath = System.getProperty("user.dir") + File.separator + "SocketProperties.properties";
	        //FileReader reader = new FileReader(configPath);
	        //propertiesFileData.load(reader);	        
	        
			//String token=propertiesFileData.getProperty("token");
			String token = generateToken();
			logger.info("token: "+token);
			String ClientMessage="";
			
			ObjectInputStream ois = new ObjectInputStream(s.getInputStream());
			ClientMessage = (String) ois.readObject();
			logger.info("message: "+ClientMessage);
			
			String[] clientMessageArr = ClientMessage.split("##");
			logger.info("afterSplit");
			logger.info("1 element"+clientMessageArr[1]);
			
			if(clientMessageArr[1].equalsIgnoreCase("PAN")) {
				String clientData = clientMessageArr[0];
	            String isValidPAN = validatePAN_DOB.validatePAN(token,clientData);             
	            
				dos.writeUTF(isValidPAN);
	            logger.info("isValidPAN: "+isValidPAN);
	
				// receive the answer from client
				// received = dis.readUTF();
	
				logger.info("Client " + this.s + " sends exit...");			
				
				logger.info("Closing this connection.");
				this.s.close();
				logger.info("Connection closed");
			}
			
			else				
			if(clientMessageArr[1].equalsIgnoreCase("DOB")){
				String DOB = clientMessageArr[0];
	            String isValidDOB = validatePAN_DOB.validateDOB(token,DOB);             
	            
				dos.writeUTF(isValidDOB);
	            logger.info("isValidPAN: "+isValidDOB);

				// receive the answer from client
				// received = dis.readUTF();

				logger.info("Client " + this.s + " sends exit...");			
				
				logger.info("Closing this connection.");
				this.s.close();
				logger.info("Connection closed");	
			}
			else
				if(clientMessageArr[1].equalsIgnoreCase("PANLINKAGE")) {
					String clientData = clientMessageArr[0];
		            String isPANLinked = validatePAN_DOB.validatePANLINKAGE(token,clientData);             
		            
					dos.writeUTF(isPANLinked);
		            logger.info("isPANLinked: "+isPANLinked);
		
					// receive the answer from client
					// received = dis.readUTF();
		
					logger.info("Client " + this.s + " sends exit...");			
					
					logger.info("Closing this connection.");
					this.s.close();
					logger.info("Connection closed");
				}
			
			else				
				if(clientMessageArr[1].equalsIgnoreCase("LEDoc")){
					String data = clientMessageArr[0];
					String planCode=clientMessageArr[3];
					
					logger.info("data"+data);
					logger.info("planCode"+clientMessageArr[3]);
					
					String returnData="";

					if(planCode.equalsIgnoreCase("LPPS")) {
						returnData = LE_LPPS_Gen_Cal.generateDOC(token,data,clientMessageArr[2],planCode); 
					}
					else						
					if(planCode.equalsIgnoreCase("AWP")) {
						returnData = LE_GenerateDocument.generateDOC(token,data,clientMessageArr[2],planCode);     
					}
					else
						if(planCode.equalsIgnoreCase("FTSP")) {
							logger.info("Inside FTSP");
							returnData = LE_FTSP_Gen_Cal.generateDOC(token,data,clientMessageArr[2],planCode);
						}
						else
							if(planCode.equalsIgnoreCase("PWP")) {
								returnData = LE_PWP_Gen_Cal.generateDOC(token,data,clientMessageArr[2],planCode);
							}
							else
								if(planCode.equalsIgnoreCase("FYPP")) {
									returnData = LE_FYPP_Gen_Cal.generateDOC(token,data,clientMessageArr[2],planCode);
								}
								else
									if(planCode.equalsIgnoreCase("SPS")) {
										returnData = LE_SPS_Gen_Cal.generateDOC(token,data,clientMessageArr[2],planCode);
									}
									else
										if(planCode.equalsIgnoreCase("OSP")) {
											returnData = LE_OSP_Gen_Cal.generateDOC(token,data,clientMessageArr[2],planCode);
										}
										else
											if(planCode.equalsIgnoreCase("MIAP")) {
												returnData = LE_MIAP_Gen_Cal.generateDOC(token,data,clientMessageArr[2],planCode);
											}
											else
												if(planCode.equalsIgnoreCase("WLS")) {
													returnData = LE_WLS_Gen_Cal.generateDOC(token,data,clientMessageArr[2],planCode);
												}
												else
													if(planCode.equalsIgnoreCase("GIP"))
														returnData = LE_GIP_Gen_Cal.generateDOC(token,data,clientMessageArr[2],planCode);
													else
														if(planCode.equalsIgnoreCase("FGEP"))
															returnData = LE_FGEP_Gen_Cal.generateDOC(token,data,clientMessageArr[2],planCode);
														else
															if(planCode.equalsIgnoreCase("FWP"))
																returnData = LE_FWP_Gen_Cal.generateDOC(token,data,clientMessageArr[2],planCode);
															else
																if(planCode.equalsIgnoreCase("STP"))
																	returnData = LE_STP_Gen_Cal.generateDOC(token,data,clientMessageArr[2],planCode);
																else
																	if(planCode.equalsIgnoreCase("OTP"))
																		returnData = LE_OTP_Gen_Cal.generateDOC(token,data,clientMessageArr[2],planCode);
																	else
																		if(planCode.equalsIgnoreCase("SAP"))
																			returnData = LE_SAP_Gen_Cal.generateDOC(token,data,clientMessageArr[2],planCode);
																		else
																			if(planCode.equalsIgnoreCase("SWP"))
																				returnData = LE_SWP_Gen_Cal.generateDOC(token,data,clientMessageArr[2],planCode);
																			else
																				if(planCode.equalsIgnoreCase("SJB"))
																					returnData = LE_SJB_Gen_Cal.generateDOC(token,data,clientMessageArr[2],planCode);
																				else
																					if(planCode.equalsIgnoreCase("SSP"))
																						returnData = LE_SSP_Gen_Cal.generateDOC(token,data,clientMessageArr[2],planCode);
																					else
																						if(planCode.equalsIgnoreCase("GLIP"))
																							returnData = LE_GLIP_Gen_Cal.generateDOC(token,data,clientMessageArr[2],planCode);
																						else
																							if(planCode.equalsIgnoreCase("SPP"))
																								returnData = LE_SPP_Gen_Cal.generateDOC(token,data,clientMessageArr[2],planCode);
																							else
																								if(planCode.equalsIgnoreCase("SWIP"))
																									returnData = LE_SWIP_Gen_Cal.generateDOC(token,data,clientMessageArr[2],planCode);
																								else
																									if(planCode.equalsIgnoreCase("FWAP"))
																										returnData = LE_FWAP_Gen_Cal.generateDOC(token,data,clientMessageArr[2],planCode);
																									else
																										if(planCode.equalsIgnoreCase("SGPP"))
																											returnData = LE_SGPP_Gen_Cal.generateDOC(token,data,clientMessageArr[2],planCode);
																										else
																											if(planCode.equalsIgnoreCase("CIP"))
																												returnData = LE_CIP_Gen_Cal.generateDOC(token,data,clientMessageArr[2],planCode);
																											else
																												if(planCode.equalsIgnoreCase("CG"))
																													returnData = LE_CG_Gen_Cal.generateDOC(token,data,clientMessageArr[2],planCode);
																												else
																													if(planCode.equalsIgnoreCase("SFRD"))
																														returnData = LE_SFRD_Gen_Cal.generateDOC(token,data,clientMessageArr[2],planCode);
																													else
																														if(planCode.equalsIgnoreCase("SWAGP"))
																															returnData = LE_SWAGP_Gen_Cal.generateDOC(token,data,clientMessageArr[2],planCode);
																														else
																															if(planCode.equalsIgnoreCase("SEWA"))
																																returnData = LE_SEWA_Gen_Cal.generateDOC(token,data,clientMessageArr[2],planCode);
																															else
																																if(planCode.equalsIgnoreCase("STEP"))
																																	returnData = LE_STEP_Gen_Cal.generateDOC(token,data,clientMessageArr[2],planCode);
																																else
																																	if(planCode.equalsIgnoreCase("CG1"))
																																		returnData = LE_CG1_Gen_Cal.generateDOC(token,data,clientMessageArr[2],planCode);
																																	else
																																		if(planCode.equalsIgnoreCase("CG3"))
																																			returnData = LE_CG3_Gen_Cal.generateDOC(token,data,clientMessageArr[2],planCode);
																																		else
																																			if(planCode.equalsIgnoreCase("SWAGPP"))
																																				returnData = LE_SWAGPP_Gen_Cal.generateDOC(token,data,clientMessageArr[2],planCode);
																																			else
																																				if(planCode.equalsIgnoreCase("SWAGE"))
																																					returnData = LE_SWAGE_Gen_Cal.generateDOC(token,data,clientMessageArr[2],planCode);
																																				else
																																					if(planCode.equalsIgnoreCase("CG4"))
																																						returnData = LE_CG4_Gen_Cal.generateDOC(token,data,clientMessageArr[2],planCode);
																																					else
																																						if(planCode.equalsIgnoreCase("STPP"))
																																							returnData = LE_STPP_Gen_Cal.generateDOC(token,data,clientMessageArr[2],planCode);
																																						else
																																							if(planCode.equalsIgnoreCase("STAR"))
																																								returnData = LE_STAR_Gen_Cal.generateDOC(token,data,clientMessageArr[2],planCode);
				
																																	
										
						
					
		            
		            logger.info("returnData: "+returnData);
					//dos.writeUTF(returnData);
					dos.writeBytes(returnData);
		            logger.info("returnData: "+returnData);

					// receive the answer from client
					// received = dis.readUTF();

					logger.info("Client " + this.s + " sends exit...");			
					
					logger.info("Closing this connection.");
					this.s.close();
					logger.info("Connection closed");	
				}
			else
				if(clientMessageArr[1].equalsIgnoreCase("MICR_IFSC")) {
					String data = clientMessageArr[0];
		            String returnData = MICR_IFSC.generateResponse(token,data);             
		            logger.info("returnData: "+returnData);
					//dos.writeUTF(returnData);
					dos.writeBytes(returnData);
		            logger.info("returnData: "+returnData);

					// receive the answer from client
					// received = dis.readUTF();

					logger.info("Client " + this.s + " sends exit...");			
					
					logger.info("Closing this connection.");
					this.s.close();
					logger.info("Connection closed");
				}
				else
					if(clientMessageArr[1].equalsIgnoreCase("AadhaarMask")) {
						String aadhaarNumber = clientMessageArr[0];
			            String returnData = AadhaarMasking.maskAadhaar(token,aadhaarNumber);             
			            logger.info("returnData: "+returnData);
						//dos.writeUTF(returnData);
						dos.writeBytes(returnData);
			            logger.info("returnData: "+returnData);

						// receive the answer from client
						// received = dis.readUTF();

						logger.info("Client " + this.s + " sends exit...");			
						
						logger.info("Closing this connection.");
						this.s.close();
						logger.info("Connection closed");
					}
				else if(clientMessageArr[1].equalsIgnoreCase("MyMoneyService")) {
						String parameters = clientMessageArr[0];
			            String returnData = MyMoney.MyMoneyService(token,parameters);             
			            logger.info("MyMoneyService returnData: "+returnData);
						//dos.writeUTF(returnData);
						dos.writeBytes(returnData);
			            // receive the answer from client
						// received = dis.readUTF();

						logger.info("Client " + this.s + " sends exit...");			
						
						logger.info("Closing this connection.");
						this.s.close();
						logger.info("Connection closed");
					}
				else if(clientMessageArr[1].equalsIgnoreCase("MyAgentService")) {
					String parameters = clientMessageArr[0];
		            String returnData = MyAgent.MyAgentService(token, parameters);             
		            logger.info("MyAgentService returnData: "+returnData);
					//dos.writeUTF(returnData);
					dos.writeBytes(returnData);
		            // receive the answer from client
					// received = dis.readUTF();

					logger.info("Client " + this.s + " sends exit...");			
					
					logger.info("Closing this connection.");
					this.s.close();
					logger.info("Connection closed");
				}
			//added by Prakhar
				else if(clientMessageArr[1].equalsIgnoreCase("policySplittingAPI")) {
					String parameters = clientMessageArr[0];//requestJSON
		            String returnData = PolicySplitAPI.callAPI_REST(token, parameters);             
		            logger.info("MyAgentService returnData: "+returnData);
					//dos.writeUTF(returnData);
					dos.writeBytes(returnData);
		            // receive the answer from client
					// received = dis.readUTF();

					logger.info("Client " + this.s + " sends exit...");			
					
					logger.info("Closing this connection.");
					this.s.close();
					logger.info("Connection closed");
				}
				else if(clientMessageArr[1].equalsIgnoreCase("PSM_API")) {
					String parameters = clientMessageArr[0];//requestJSON
		            String returnData = PSM_API.callAPI_REST(token, parameters);             
		            logger.info("MyAgentService returnData: "+returnData);
					//dos.writeUTF(returnData);
					dos.writeBytes(returnData);
		            // receive the answer from client
					// received = dis.readUTF();

					logger.info("Client " + this.s + " sends exit...");			
					
					logger.info("Closing this connection.");
					this.s.close();
					logger.info("Connection closed");
				}else if(clientMessageArr[1].equalsIgnoreCase("CLIENT_LEVEL_CHECK_API")) {
					String parameters = clientMessageArr[0];//requestJSON
		            String returnData = CLIENT_LEVEL_CHECK_API.callAPI_REST(token, parameters);             
		            logger.info("MyAgentService returnData: "+returnData);
					//dos.writeUTF(returnData);
					dos.writeBytes(returnData);
		            // receive the answer from client
					// received = dis.readUTF();

					logger.info("Client " + this.s + " sends exit...");			
					
					logger.info("Closing this connection.");
					this.s.close();
					logger.info("Connection closed");
				}
				else if(clientMessageArr[1].equalsIgnoreCase("callDedupe_API")) {
					String parameters = clientMessageArr[0];//requestJSON
		            String returnData = Dedupe_API.callAPI_REST(token, parameters);             
		            logger.info("MyAgentService returnData: "+returnData);
					//dos.writeUTF(returnData);
					dos.writeBytes(returnData);
		            // receive the answer from client
					// received = dis.readUTF();

					logger.info("Client " + this.s + " sends exit...");			
					
					logger.info("Closing this connection.");
					this.s.close();
					logger.info("Connection closed");
				}
				else if(clientMessageArr[1].equalsIgnoreCase("creatClientID_API")) {
					String token2 = generateToken2();
					logger.info("token2: "+token2);
					String parameters = clientMessageArr[0];//requestJSON
					String returnData = CreateClient_API.callAPI_REST(token2, parameters);     
					logger.info("CreateClient_API returnData: "+returnData);
					dos.writeBytes(returnData);
					logger.info("Client " + this.s + " sends exit...");			
					logger.info("Closing this connection.");
					this.s.close();
					logger.info("Connection closed");
				}
			// DR-16954
				else if(clientMessageArr[1].equalsIgnoreCase("EDCValidateService")) {
					String parameters = clientMessageArr[0];
				     logger.info("EDCValidateService parameters: "+parameters);
						
		            String returnData = EDCValidateService.callAPI_REST(token, parameters);             
		            logger.info("EDCValidateService returnData: "+returnData);
					//dos.writeUTF(returnData);
					dos.writeBytes(returnData);
		            // receive the answer from client
					// received = dis.readUTF();

					logger.info("Client " + this.s + " sends exit...");			
					
					logger.info("Closing this connection.");
					this.s.close();
					logger.info("Connection closed");
				}
			// DR-21511
				else if(clientMessageArr[1].equalsIgnoreCase("UWGovernanceService")) {
					String parameters = clientMessageArr[0];
				     logger.info("UWGovernanceService parameters: "+parameters);
						
		            String returnData = GovernanceValidateService.callAPI_REST(token, parameters);             
		            logger.info("UWGovernanceService returnData: "+returnData);
					//dos.writeUTF(returnData);
					dos.writeBytes(returnData);
		            // receive the answer from client
					// received = dis.readUTF();

					logger.info("Client " + this.s + " sends exit...");			
					
					logger.info("Closing this connection.");
					this.s.close();
					logger.info("Connection closed");
				}
				else if(clientMessageArr[1].equalsIgnoreCase("generateToken")) {
			        logger.info("generateToken: "+token);
			        dos.writeBytes(token);
					logger.info("Client " + this.s + " sends exit...");			
					logger.info("Closing this connection.");
					this.s.close();
					logger.info("Connection closed");

				}
			
		} catch (IOException e) {
			logger.error(e.toString());
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			logger.error(e.toString());
			e.printStackTrace();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			logger.error(e.toString());
			e.printStackTrace();
		}

		try {
			// closing resources
			this.dis.close();
			this.dos.close();

		} catch (IOException e) {
			logger.error(e.toString());
			e.printStackTrace();
		}
		
		
		
	}
	
	private String generateToken() throws ParseException {
		String token="";
		
		HashMap<String, String> hm = new HashMap<>();
		//hm.put("accept", "application/json");
		//hm.put("Authorization", propertiesFileData.getProperty("TokenAuthorization"));
		//         hm.put("Content-Type", "application/json");
		//         hm.put("x-client-id", "53jt873l753mcudrhqmuh3g5u8");
		//         hm.put("x-api-key", "DTUDHv9UVG8cVT3qmhiSv1UcnvCduzLf1CI6zCVY");
         
        //for SIT
		
		hm.put("Content-Type", "application/json");        
		hm.put("x-api-key", Server.propertiesFileData.getProperty("ApiKey"));        
		hm.put("cache-control", "no-cache");
		hm.put("host", Server.propertiesFileData.getProperty("Host"));
		hm.put("x-client-id", Server.propertiesFileData.getProperty("x-client-id"));
		hm.put("user-pool-id", Server.propertiesFileData.getProperty("user-pool-id"));
		
		String url=Server.propertiesFileData.getProperty("auth_url");
		
		String jsonString = callAPI(url, "POST", hm);
		logger.info("jsonString: "+jsonString);
		Object obj = null,tokenObj=null;
		try {
			obj = new JSONParser().parse(jsonString);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        JSONObject jo = (JSONObject) obj;
        //String payload = (String) jo.get("payload").toString();
        
        tokenObj = new JSONParser().parse(jo.get("payload").toString());
        JSONObject joToken = (JSONObject) tokenObj;
        token = (String) joToken.get("token").toString();
		logger.info("token generated: "+token);
		return token;
	}

	private String generateToken2() throws ParseException {
		String token="";
		
		HashMap<String, String> hm = new HashMap<>();
		
		hm.put("Content-Type", "application/json");        
		hm.put("x-api-key", Server.propertiesFileData.getProperty("ApiKey2"));        
//		hm.put("cache-control", "no-cache");
		hm.put("host", Server.propertiesFileData.getProperty("Host2"));
//		hm.put("x-client-id", Server.propertiesFileData.getProperty("x-client-id"));
//		hm.put("user-pool-id", Server.propertiesFileData.getProperty("user-pool-id"));
		
		String url=Server.propertiesFileData.getProperty("auth_url2");
		
		String jsonString = callAPI2(url, "POST", hm);
		logger.info("jsonString: "+jsonString);
		
		JSONParser jsonParser = new JSONParser();
		JSONObject json = (JSONObject) jsonParser .parse(jsonString);
		
		String response = json.get("response").toString();
		JSONObject responseObj = new JSONObject();
		responseObj = (JSONObject) jsonParser .parse(response);
		
		String payload = responseObj.get("payload").toString();
		JSONObject payloadObj = new JSONObject();
		payloadObj = (JSONObject) jsonParser .parse(payload);
		
		token = payloadObj.get("accessToken").toString();
		
//        token = (String) joToken.get("token").toString();
		logger.info("token 2 generated: "+token);
		return token;
	}
	
	
	/*
	
public String callRestAPI(String url, String method, HashMap<String, String> request) {
		URL urlForGetRequest;
		String data = "";
		String readLine = null;
		String returnJSON = "", returnVal = null;
		HttpURLConnection conection;
		try {
			urlForGetRequest = new URL(url);
			conection = (HttpURLConnection) urlForGetRequest.openConnection();
			conection.setRequestMethod(method);

			// logger.info(url);
			// logger.info(method);
			for (String i : request.keySet()) {
				conection.setRequestProperty(i, request.get(i)); // set userId
																	// its a
																	// sample
																	// here
			}
			// conection.setRequestProperty("Authorization", "Basic
			// YzBiYThiNmYtZTNiMC00NjU5LTkwNDktNmNjOGVlYzhhYzRiOlhSY3B4ZWxZQVhHNnR3VFlQcmxRUXBhN1RFc1haY2lp");
			// // set userId its a sample here
			// conection.setRequestProperty("Content-Type",
			// "application/x-www-form-urlencoded"); // set userId its a sample
			// here

			conection.setDoOutput(true);

			if (method.equalsIgnoreCase("POST")) {

				data = "{\"metadata\":{\r\n" + 
						"  \"X-App-ID\":\"IBPS\",                  \r\n" + 
						"  \"X-Correlation-ID\":\"31873127329799381273192\"\r\n" + 
						"},\"payload\":{\r\n" + 
						"  \"username\":\"ibps\",                           \r\n" + 
						"  \"password\": \"QWRtaW5AMTIzNDU=\"}}";
				OutputStreamWriter obj = new OutputStreamWriter(conection.getOutputStream());
				obj.write(data);
				obj.close();
				logger.info("data: "+data);
			}
			

			int responseCode = conection.getResponseCode();
			logger.info(responseCode);
			if (responseCode == HttpURLConnection.HTTP_OK) {
				BufferedReader in = new BufferedReader(new InputStreamReader(conection.getInputStream()));
				StringBuffer response = new StringBuffer();
				while ((readLine = in.readLine()) != null) {
					response.append(readLine);
				}
				in.close();

				returnJSON = response.toString();
				// logger.info("JSON String Result " +
				// response.toString());
				returnVal = returnJSON;
			} else {
				// logger.info("responseCode " + responseCode);
				logger.info("responseCode " + responseCode);
				// Ariba disconnectUser = new Ariba();
				// disconnectUser.disconnectUser();
				returnVal = "ERROR";
			}
		} catch (IOException ex) {
			// logger.error("Exception in calling RestAPI Method----" +
			// ex.toString());
			logger.info("Exception in calling RestAPI Method----" + ex.toString());
			// new Ariba().runDbquery(Ariba.emailTriggerQuery);
			ex.printStackTrace();
		}
		return returnVal;
	}
	*/
	private String callAPI(String url, String string, HashMap<String, String> hm) {
		// TODO Auto-generated method stub
			String postEndpoint = url;
			CloseableHttpClient httpclient = HttpClients.createDefault();
			HttpPost httpPost = new HttpPost(postEndpoint);
			
			for (String i : hm.keySet()) {
				httpPost.setHeader(i, hm.get(i)); // set userId
																	// its a
																	// sample
																	// here
			}
			
			String inputJson = "{\"metadata\":{\r\n" + 
					"  \"X-App-ID\":\"IBPS\",                  \r\n" + 
					"  \"X-Correlation-ID\":\"31873127329799381273192\"\r\n" + 
					"},\"payload\":{\r\n" + 
					"  \"username\":\""+Server.propertiesFileData.getProperty("username")+"\",                           \r\n" + 
					"  \"password\": \""+Server.propertiesFileData.getProperty("password")+"\"}}";
			
			StringEntity stringEntity;
			StringBuffer result = new StringBuffer();
			try {
				stringEntity = new StringEntity(inputJson);
				httpPost.setEntity(stringEntity);
				System.out.println("Executing request " + httpPost.getRequestLine());

				HttpResponse response = httpclient.execute(httpPost);

				BufferedReader br = new BufferedReader(
						new InputStreamReader((response.getEntity().getContent())));


				//Throw runtime exception if status code isn't 200
				if (response.getStatusLine().getStatusCode() != 200) {
					throw new RuntimeException("Failed : HTTP error code : "
							+ response.getStatusLine().getStatusCode());
				}


				//Create the StringBuffer object and store the response into it.
				
				String line = "";
				while ((line = br.readLine()) != null) {
				result.append(line);
				}


				//Lets validate if a text 'employee_salary' is present in the response 
				//System.out.println( result.toString());
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		return result.toString();
	}
	
	private String callAPI2(String url, String string, HashMap<String, String> hm) {
		// TODO Auto-generated method stub
			String postEndpoint = url;
			CloseableHttpClient httpclient = HttpClients.createDefault();
			HttpPost httpPost = new HttpPost(postEndpoint);
			
			for (String i : hm.keySet()) {
				httpPost.setHeader(i, hm.get(i)); // set userId
			}
			
			String inputJson = "{\r\n" + 
					"	\"request\": {\r\n" + 
					"		\"header\": {\r\n" + 
					"			\"soaCorrelationId\": \"aa668900111\",\r\n" + 
					"			\"soaAppId\": \"DOLPHIN\"\r\n" + 
					"		},\r\n" + 
					"		\"payload\": {\r\n" + 
					"			\"clientId\": \""+Server.propertiesFileData.getProperty("clientId")+"\",\r\n" + 
					"			\"clientSecret\": \""+Server.propertiesFileData.getProperty("clientSecret")+"\",\r\n" + 
					"			\"grantType\": \""+Server.propertiesFileData.getProperty("grantType")+"\"\r\n" + 
					"		}\r\n" + 
					"	}\r\n" + 
					"}";
			
			StringEntity stringEntity;
			StringBuffer result = new StringBuffer();
			try {
				stringEntity = new StringEntity(inputJson);
				httpPost.setEntity(stringEntity);
				System.out.println("Executing request " + httpPost.getRequestLine());

				HttpResponse response = httpclient.execute(httpPost);

				BufferedReader br = new BufferedReader(
						new InputStreamReader((response.getEntity().getContent())));


				//Throw runtime exception if status code isn't 200
				if (response.getStatusLine().getStatusCode() != 200) {
					throw new RuntimeException("Failed : HTTP error code : "
							+ response.getStatusLine().getStatusCode());
				}


				//Create the StringBuffer object and store the response into it.
				
				String line = "";
				while ((line = br.readLine()) != null) {
				result.append(line);
				}


				//Lets validate if a text 'employee_salary' is present in the response 
				//System.out.println( result.toString());
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		return result.toString();
	}

	public void test() {
		//validatePAN_DOB VPD = new validatePAN_DOB();
		//LE_GenerateDocument LGD = new LE_GenerateDocument();
		//MICR_IFSC MICR = new MICR_IFSC();
		//AadhaarMasking MaskAadhaar = new AadhaarMasking();		
		try {
			//Validate PAN DOB
			//to be uncomment later
			//String token = generateToken();
			
			//propertiesFileData = new Properties();
//			props = new Properties();
			
			//configPath = System.getProperty("user.dir") + File.separator + "SocketProperties.properties";
	        //FileReader reader = new FileReader(configPath);
	        //propertiesFileData.load(reader);	        
	        
			//String token=propertiesFileData.getProperty("token");
			String token = generateToken();
			logger.info("token: "+token);
			String ClientMessage="";
			
			ObjectInputStream ois = new ObjectInputStream(s.getInputStream());
			ClientMessage = (String) ois.readObject();
			logger.info("message: "+ClientMessage);
			
			String[] clientMessageArr = ClientMessage.split("##");
			
			if(clientMessageArr[1].equalsIgnoreCase("PAN")) {
				String clientData = clientMessageArr[0];
	            String isValidPAN = validatePAN_DOB.validatePAN(token,clientData);             
	            
				dos.writeUTF(isValidPAN);
	            logger.info("isValidPAN: "+isValidPAN);
	
				// receive the answer from client
				// received = dis.readUTF();
	
				logger.info("Client " + this.s + " sends exit...");			
				
				logger.info("Closing this connection.");
				this.s.close();
				logger.info("Connection closed");
			}
			
			else				
			if(clientMessageArr[1].equalsIgnoreCase("DOB")){
				String DOB = clientMessageArr[0];
	            String isValidDOB = validatePAN_DOB.validateDOB(token,DOB);             
	            
				dos.writeUTF(isValidDOB);
	            logger.info("isValidPAN: "+isValidDOB);

				// receive the answer from client
				// received = dis.readUTF();

				logger.info("Client " + this.s + " sends exit...");			
				
				logger.info("Closing this connection.");
				this.s.close();
				logger.info("Connection closed");	
			}
			
			else				
				if(clientMessageArr[1].equalsIgnoreCase("LEDoc")){
					String data = clientMessageArr[0];
					String planCode=clientMessageArr[3];
					String returnData="";

					if(planCode.equalsIgnoreCase("LPPS")) {
						returnData = LE_LPPS_Gen_Cal.generateDOC(token,data,clientMessageArr[2],planCode); 
					}
					else						
					if(planCode.equalsIgnoreCase("AWP")) {
						returnData = LE_GenerateDocument.generateDOC(token,data,clientMessageArr[2],planCode);     
					}
					else
						if(planCode.equalsIgnoreCase("FTSP")) {
							returnData = LE_FTSP_Gen_Cal.generateDOC(token,data,clientMessageArr[2],planCode);
						}
						else
							if(planCode.equalsIgnoreCase("PWP")) {
								returnData = LE_PWP_Gen_Cal.generateDOC(token,data,clientMessageArr[2],planCode);
							}
							else
								if(planCode.equalsIgnoreCase("FYPP")) {
									returnData = LE_FYPP_Gen_Cal.generateDOC(token,data,clientMessageArr[2],planCode);
								}
								else
									if(planCode.equalsIgnoreCase("SPS")) {
										returnData = LE_SPS_Gen_Cal.generateDOC(token,data,clientMessageArr[2],planCode);
									}
									else
										if(planCode.equalsIgnoreCase("OSP")) {
											returnData = LE_OSP_Gen_Cal.generateDOC(token,data,clientMessageArr[2],planCode);
										}
										else
											if(planCode.equalsIgnoreCase("MIAP")) {
												returnData = LE_MIAP_Gen_Cal.generateDOC(token,data,clientMessageArr[2],planCode);
											}
											else
												if(planCode.equalsIgnoreCase("WLS")) {
													returnData = LE_WLS_Gen_Cal.generateDOC(token,data,clientMessageArr[2],planCode);
												}
												else
													if(planCode.equalsIgnoreCase("GIP"))
														returnData = LE_GIP_Gen_Cal.generateDOC(token,data,clientMessageArr[2],planCode);
													else
														if(planCode.equalsIgnoreCase("FGEP"))
															returnData = LE_FGEP_Gen_Cal.generateDOC(token,data,clientMessageArr[2],planCode);
														else
															if(planCode.equalsIgnoreCase("FWP"))
																returnData = LE_FWP_Gen_Cal.generateDOC(token,data,clientMessageArr[2],planCode);
															else
																if(planCode.equalsIgnoreCase("STP"))
																	returnData = LE_STP_Gen_Cal.generateDOC(token,data,clientMessageArr[2],planCode);
		            
		            logger.info("returnData: "+returnData);
					//dos.writeUTF(returnData);
					dos.writeBytes(returnData);
		            logger.info("returnData: "+returnData);

					// receive the answer from client
					// received = dis.readUTF();

					logger.info("Client " + this.s + " sends exit...");			
					
					logger.info("Closing this connection.");
					this.s.close();
					logger.info("Connection closed");	
				}
			else
				if(clientMessageArr[1].equalsIgnoreCase("MICR_IFSC")) {
					String data = clientMessageArr[0];
		            String returnData = MICR_IFSC.generateResponse(token,data);             
		            logger.info("returnData: "+returnData);
					//dos.writeUTF(returnData);
					dos.writeBytes(returnData);
		            logger.info("returnData: "+returnData);

					// receive the answer from client
					// received = dis.readUTF();

					logger.info("Client " + this.s + " sends exit...");			
					
					logger.info("Closing this connection.");
					this.s.close();
					logger.info("Connection closed");
				}
				else
					if(clientMessageArr[1].equalsIgnoreCase("AadhaarMask")) {
						String aadhaarNumber = clientMessageArr[0];
			            String returnData = AadhaarMasking.maskAadhaar(token,aadhaarNumber);             
			            logger.info("returnData: "+returnData);
						//dos.writeUTF(returnData);
						dos.writeBytes(returnData);
			            logger.info("returnData: "+returnData);

						// receive the answer from client
						// received = dis.readUTF();

						logger.info("Client " + this.s + " sends exit...");			
						
						logger.info("Closing this connection.");
						this.s.close();
						logger.info("Connection closed");
					}
				else if(clientMessageArr[1].equalsIgnoreCase("MyMoneyService")) {
						String parameters = clientMessageArr[0];
			            String returnData = MyMoney.MyMoneyService(token,parameters);             
			            logger.info("MyMoneyService returnData: "+returnData);
						//dos.writeUTF(returnData);
						dos.writeBytes(returnData);
			            // receive the answer from client
						// received = dis.readUTF();

						logger.info("Client " + this.s + " sends exit...");			
						
						logger.info("Closing this connection.");
						this.s.close();
						logger.info("Connection closed");
					}
				else if(clientMessageArr[1].equalsIgnoreCase("MyAgentService")) {
					String parameters = clientMessageArr[0];
		            String returnData = MyAgent.MyAgentService(token, parameters);             
		            logger.info("MyAgentService returnData: "+returnData);
					//dos.writeUTF(returnData);
					dos.writeBytes(returnData);
		            // receive the answer from client
					// received = dis.readUTF();

					logger.info("Client " + this.s + " sends exit...");			
					
					logger.info("Closing this connection.");
					this.s.close();
					logger.info("Connection closed");
				}
				else if(clientMessageArr[1].equalsIgnoreCase("MyManagerService")) {
					String parameters = clientMessageArr[0];
		            String returnData = MyAgent.MyManagerService(token, parameters);             
		            logger.info("MyMANAGER returnData: "+returnData);
					//dos.writeUTF(returnData);
					dos.writeBytes(returnData);
		            // receive the answer from client
					// received = dis.readUTF();

					logger.info("Client " + this.s + " sends exit...");			
					
					logger.info("Closing this connection.");
					this.s.close();
					logger.info("Connection closed");
				}
			//added by Prakhar
				else if(clientMessageArr[1].equalsIgnoreCase("policySplittingAPI")) {
					String parameters = clientMessageArr[0];//requestJSON
		            String returnData = PolicySplitAPI.callAPI_REST(token, parameters);             
		            logger.info("MyAgentService returnData: "+returnData);
					//dos.writeUTF(returnData);
					dos.writeBytes(returnData);
		            // receive the answer from client
					// received = dis.readUTF();

					logger.info("Client " + this.s + " sends exit...");			
					
					logger.info("Closing this connection.");
					this.s.close();
					logger.info("Connection closed");
				}
				else if(clientMessageArr[1].equalsIgnoreCase("PSM_API")) {
					String parameters = clientMessageArr[0];//requestJSON
		            String returnData = PSM_API.callAPI_REST(token, parameters);             
		            logger.info("MyAgentService returnData: "+returnData);
					//dos.writeUTF(returnData);
					dos.writeBytes(returnData);
		            // receive the answer from client
					// received = dis.readUTF();

					logger.info("Client " + this.s + " sends exit...");			
					
					logger.info("Closing this connection.");
					this.s.close();
					logger.info("Connection closed");
				}
				else if(clientMessageArr[1].equalsIgnoreCase("generateToken")) {
			        logger.info("generateToken: "+token);
			        dos.writeBytes(token);
					logger.info("Client " + this.s + " sends exit...");			
					logger.info("Closing this connection.");
					this.s.close();
					logger.info("Connection closed");

				}
			
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {
			// closing resources
			this.dis.close();
			this.dos.close();

		} catch (IOException e) {
			e.printStackTrace();
		}
		
		
		
	}
	
	
}

