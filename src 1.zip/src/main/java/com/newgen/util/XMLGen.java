package com.newgen.util;

public class XMLGen {

    public static String get_WMConnect_Input(String cabinetName,
            String userName, String password,
            String forceful) {
        return "<WMConnect_Input>\r\n" + 
        		"    <Option>WMConnect</Option>\r\n" + 
        		"    <EngineName>"+cabinetName+"</EngineName>   \r\n" + 
        		"    <Participant>\r\n" + 
        		"        <Name>"+userName+"</Name>\r\n" + 
        		"        <Password>"+password+"</Password>\r\n" + 
        		"        <Scope></Scope>\r\n" + 
        		"        <UserExist>"+forceful+"</UserExist>\r\n" + 
        		"        <ParticipantType>U</ParticipantType>\r\n" + 
        		"    </Particpant>\r\n" + 
        		"</WMConnect_Input>";
    }

    public static String get_WMDisConnect_Input(String cabinetName,
            String sessionID) {
        return "<? Xml Version=\"1.0\"?>"
                + "<WMDisConnect_Input>"
                + "<Option>WMDisConnect</Option>"
                + "<EngineName>" + cabinetName
                + "</EngineName>"
                + "<SessionID>" + sessionID
                + "</SessionID>"
                + "</WMDisConnect_Input>";
    }

    public static String APProcedureWithColumnNames(
            String sessionID, String cabinetName, String procName, String params) {
        return "<?xml version=\\\"1.0\\\"?>"
                + "<APProcedure_Input>"
                + "<Option>APProcedureWithColumnNames</Option>"
                + "<Status>0</Status>"
                + "<SessionId>" + sessionID + "</SessionId>"
                + "<EngineName>" + cabinetName + "</EngineName>"
                + "<ProcName>" + procName + "</ProcName>"
                + "<Params>" + params + "</Params>"
                + "</APProcedure_Input>";
    }
    
    public static String APSelectWithColumnNames(
            String cabinetName, String query, String sessionID) {
        return"<?xml version=\"1.0\"?>"
                + "<APSelect_Input>"
                + "<Option>APSelectWithColumnNames</Option>"
                + "<Query>"+query+"</Query>"
                + "<Status>0</Status>"                
                + "<EngineName>"+cabinetName+"</EngineName>"
                + "<SessionId>"+sessionID+"</SessionId>"
                + "</APSelect_Input>";
    }
    
    
    //OD SOAP Calls
    public static String NGMoveDocument(String cabName, String sessionID,String destFolderIndex, String documentIndex,
    		String parentFolderIndex) {
    	return "<soapenv:Envelope xmlns:soapenv=\\\"http://schemas.xmlsoap.org/soap/envelope/\\\" xmlns:ngo=\\\"http://bdo.ws.jts.omni.newgen.com/NGOExecuteAPIService/\\\">\\r\\n\" + \r\n" + 
    			"    			\"   <soapenv:Header/>\\r\\n\" + \r\n" + 
    			"    			\"   <soapenv:Body>\\r\\n\" + \r\n" + 
    			"    			\"      <ngo:NGOExecuteAPIBDO>\\r\\n\" + \r\n" + 
    			"    			\"         <inputXML>\"\r\n" + 
    			"    			+ \"<![CDATA[<NGOMoveDocumentExt_Input>\r\n" + 
    			"<Option>NGOMoveDocumentExt</Option>\r\n" + 
    			"<CabinetName>"+cabName+"</CabinetName>\r\n" + 
    			"<UserDBId>"+sessionID+"</UserDBId>\r\n" + 
    			"<CurrentDateTime></CurrentDateTime>\r\n" + 
    			"<DestFolderIndex>"+destFolderIndex+"</DestFolderIndex>\r\n" + 
    			"<NameLength>100</NameLength>                              \r\n" + 
    			"<DeleteReferenceAlsoFlag>Y</DeleteReferenceAlsoFlag>              \r\n" + 
    			"<DuplicateName>Y</DuplicateName>\r\n" + 
    			"<Documents>\r\n" + 
    			"\r\n" + 
    			"                <Document>\r\n" + 
    			"                                <DocumentIndex>"+documentIndex+"</DocumentIndex>\r\n" + 
    			"                                <ParentFolderIndex>"+parentFolderIndex+"</ParentFolderIndex>\r\n" + 
    			"                </Document>\r\n" + 
    			"</Documents>\r\n" + 
    			"</NGOMoveDocumentExt_Input>]]>\"\r\n" + 
    			"    			+ \"</inputXML>\\r\\n\" + \r\n" + 
    			"    			\"         <base64Encoded>N</base64Encoded>\\r\\n\" + \r\n" + 
    			"    			\"      </ngo:NGOExecuteAPIBDO>\\r\\n\" + \r\n" + 
    			"    			\"   </soapenv:Body>\\r\\n\" + \r\n" + 
    			"    			\"</soapenv:Envelope>";
    }
    
    public static String NGAddFolder(String cabinetName,String sessionID,String parentFolderIndex,String folderName) {
    	return "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:ngo=\"http://bdo.ws.jts.omni.newgen.com/NGOExecuteAPIService/\">\r\n" + 
    			"   <soapenv:Header/>\r\n" + 
    			"   <soapenv:Body>\r\n" + 
    			"      <ngo:NGOExecuteAPIBDO>\r\n" + 
    			"         <inputXML>"
    			+ "<![CDATA[<NGOAddFolder_Input>\r\n" + 
    			"<Option>NGOAddFolder</Option>\r\n" + 
    			"<CabinetName>"+cabinetName+"</CabinetName>\r\n" + 
    			"<UserDBId>"+sessionID+"</UserDBId>\r\n" + 
    			"<Folder>\r\n" + 
    			"<ParentFolderIndex>"+parentFolderIndex+"</ParentFolderIndex>\r\n" + 
    			"<FolderName>"+folderName+"</FolderName>\r\n" + 
    			"<AccessType>S</AccessType>\r\n" + 
    			"<ImageVolumeIndex>1</ImageVolumeIndex>\r\n" + 
    			"<FolderType>G</FolderType>\r\n" + 
    			"<MappedDirectory>\r\n" + 
    			"</MappedDirectory>\r\n" + 
    			"<Location>G</Location>\r\n" + 
    			"<Comment>\r\n" + 
    			"</Comment>\r\n" + 
    			"<FinalizedFlag>N</FinalizedFlag>\r\n" + 
    			"<FinalizedBy>\r\n" + 
    			"</FinalizedBy>\r\n" + 
    			"<LogGeneration>Y</LogGeneration>\r\n" + 
    			"<EnableFTSFlag>N</EnableFTSFlag>\r\n" + 
    			"<DuplicateName>N</DuplicateName>"+
    			"</Folder>\r\n" + 
    			"</NGOAddFolder_Input>]]>"
    			+ "</inputXML>\r\n" + 
    			"         <base64Encoded>N</base64Encoded>\r\n" + 
    			"      </ngo:NGOExecuteAPIBDO>\r\n" + 
    			"   </soapenv:Body>\r\n" + 
    			"</soapenv:Envelope>";
    }
    
    public static String NGDeleteFolder(String cabName, String sessionID, String parentFolderIndex, String folderIndex) {
    	return "<soapenv:Envelope xmlns:soapenv=\\\"http://schemas.xmlsoap.org/soap/envelope/\\\" xmlns:ngo=\\\"http://bdo.ws.jts.omni.newgen.com/NGOExecuteAPIService/\\\">\\r\\n\" + \r\n" + 
    			"    			\"   <soapenv:Header/>\\r\\n\" + \r\n" + 
    			"    			\"   <soapenv:Body>\\r\\n\" + \r\n" + 
    			"    			\"      <ngo:NGOExecuteAPIBDO>\\r\\n\" + \r\n" + 
    			"    			\"         <inputXML>\"\r\n" + 
    			"    			+ \"<![CDATA[<NGODeleteFolder_Input>\r\n" + 
    			"  <Option>NGODeleteFolder</Option>\r\n" + 
    			"  <CabinetName>"+cabName+"</CabinetName>\r\n" + 
    			"  <UserDBId>"+sessionID+"</UserDBId>\r\n" + 
    			"  <FolderIndex>"+folderIndex+"</FolderIndex>\r\n" + 
    			"  <ParentFolderIndex>"+parentFolderIndex+"<ParentFolderIndex>\r\n" + 
    			"  <ReferenceFlag>Y</ReferenceFlag>\r\n" + 
    			"  <CheckOutFlag>Y</CheckOutFlag>\r\n" + 
    			"  <LockFlag>Y</LockFlag>\r\n" + 
    			"  <LogGeneration>Y</LogGeneration>\r\n" + 
    			"</NGODeleteFolder_Input>]]>\"\r\n" + 
    			"    			+ \"</inputXML>\\r\\n\" + \r\n" + 
    			"    			\"         <base64Encoded>N</base64Encoded>\\r\\n\" + \r\n" + 
    			"    			\"      </ngo:NGOExecuteAPIBDO>\\r\\n\" + \r\n" + 
    			"    			\"   </soapenv:Body>\\r\\n\" + \r\n" + 
    			"    			\"</soapenv:Envelope>";
    }
}
