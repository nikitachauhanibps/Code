package com.newgen.services;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import javax.xml.parsers.*;
import org.xml.sax.InputSource;
import org.w3c.dom.*;
import java.io.*;


import com.newgen.util.*;

/**
 * 
 * @author aanchal.gupta
 *
 */
public class AXISDOCGEN {
	public static Properties propertiesFileData;
	static Logger logger = Logger.getLogger(CommonFunctions.class.getName()); 
	
	public String AXISDOCGEN(String sessionId) throws FileNotFoundException, IOException {
		
		propertiesFileData = new Properties();
		Properties props = new Properties();
		String Result="";
		
		String configPath = System.getProperty("user.dir") + File.separator + "CreateWorkitemService\\log4j.properties";
		props.load(new FileInputStream(configPath));
		PropertyConfigurator.configure(props);		
		
		configPath = System.getProperty("user.dir") + File.separator + "CreateWorkitemService\\config.properties";
        FileReader reader = new FileReader(configPath);
        
         logger.info("configPath: "+configPath);
        
        propertiesFileData = new Properties();
		propertiesFileData.load(reader);		 
		
		String cabinetName = propertiesFileData.getProperty("cabinetName");		
		
		String winame = "";
		
		logger.info("sessionID: " + sessionId);
        
        String query1 = "EXEC NG_SP_NB_AXIS_DOCUMENT_SHARING";
        logger.info("query: " + query1);
        
        String inputXML = XMLGen.APSelectWithColumnNames(cabinetName, query1, sessionId);
        logger.info("inputXML:" + inputXML);
        String outputXML = CommonFunctions.callRestAPI_JTS(inputXML);
        logger.info("outputXML:" + outputXML);
		
        String Response = outputXML.substring(outputXML.indexOf("<MainCode>")+10, outputXML.indexOf("</MainCode>"));
		
    	if(Response.equals("0")){
		String query = "EXEC NG_SP_NB_AXIS_FETCH";
		String inputXML1 = XMLGen.APSelectWithColumnNames(cabinetName,query,sessionId);
		logger.info("APSelectWithColumnNames_Input_inputXML: "+inputXML1);
		String outputXML1 = CommonFunctions.callRestAPI_JTS(inputXML1);
		logger.info("APSelectWithColumnNames_Output_outputXML: ");
		
		logger.info("aanchal: ");
		
		
		JSONObject resultObj = new JSONObject();
		 JSONArray docArray = new JSONArray();
		 logger.info("array axisdocsahring");
		
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		 try {
			 logger.info("try lin1");
			
        DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
        Document doc = dBuilder.parse(new InputSource(new StringReader(outputXML1)));
        logger.info("try lin2");
        doc.getDocumentElement().normalize();
        logger.info("try lin3");
        logger.info("Root element :" + doc.getDocumentElement().getNodeName());
        NodeList nList = doc.getElementsByTagName("Record");
        logger.info("try lin3"+nList);
        int   Count=0;
        
        
        for (int temp = 0; temp < nList.getLength(); temp++) {
            Node nNode = nList.item(temp);
            logger.info("\nCurrent Element :" + nNode.getNodeName());
            
            // add by sparsh
            String policyno="", JSON="", channel="";
            
            if (nNode.getNodeType() == Node.ELEMENT_NODE) {
               Element eElement = (Element) nNode;
               logger.info("policyno : " 
                  + eElement.getElementsByTagName("POLICYNO").item(0)
                  .getTextContent());
               logger.info("json : " 
                  + eElement
                  .getElementsByTagName("JSON")
                  .item(0)
                  .getTextContent());
               logger.info("Channel : " 
                       + eElement.getElementsByTagName("CHANNEL").item(0)
                       .getTextContent());
                    
               policyno=  eElement.getElementsByTagName("POLICYNO").item(0)
                       .getTextContent();
               // add by sparsh
               channel=  eElement.getElementsByTagName("CHANNEL").item(0)
                       .getTextContent();
               JSON=eElement
                       .getElementsByTagName("JSON")
                       .item(0)
                       .getTextContent();
               
               JSONObject row = new JSONObject();
               row.put("PolicyNo", policyno);
               row.put("DocDetails", JSON);
               row.put("Channel", channel);  // add by sparsh
               docArray.add(Count, row);
               Count++;
               
            
           
		 }
          

        }
        resultObj.put("DocDetails", docArray);
		 }
		 catch (Exception e) {
			 logger.info("incatch");
	         e.printStackTrace();
	         logger.info(e);
	      }
     
        
		  Result=resultObj.toJSONString();
    	}
		
		
		return Result;
	}
}
