package com.newgen.services;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.newgen.util.CommonFunctions;
import com.newgen.util.XMLGen;

public class InsertDetailsAfterMraWorkstep {
	private static Properties propertiesFileData;
	private String sessionID = "";
	private static Logger logger = Logger.getLogger("CreateWI");
	
	public String mraBackFlowService(InputStream incomingData,String sessionId) {
		     String Result = "";
		try {
			
			propertiesFileData = new Properties();
            Properties props = new Properties();

            String configPath = System.getProperty("user.dir") + File.separator
					+ "CreateWorkitemService\\log4j.properties";
            props.load(new FileInputStream(configPath));
            PropertyConfigurator.configure(props);

            configPath = System.getProperty("user.dir") + File.separator + "CreateWorkitemService\\config.properties";
            FileReader reader = new FileReader(configPath);

            logger.info("configPath: " + configPath);

            propertiesFileData = new Properties();
            propertiesFileData.load(reader);

            JSONObject erroObj = createErrorJson("400", "Validation");
            String cabinetName = propertiesFileData.getProperty("cabinetName");
            String ipAddress = propertiesFileData.getProperty("ipAddress");
            String username = propertiesFileData.getProperty("username");
            String password = propertiesFileData.getProperty("password");
            String port = propertiesFileData.getProperty("port");
            String query = "";
            StringBuilder inputJSON = new StringBuilder();
            
            try {
                BufferedReader in = new BufferedReader(new InputStreamReader(incomingData));
                String line = null;
                while ((line = in.readLine()) != null) {
                    inputJSON.append(line);
                }
            } catch (Exception e) {
                logger.info("Error Parsing: - ");
            }

            logger.info("Data Received: " + inputJSON.toString());

            String wiData = inputJSON.toString();
            wiData = wiData.replaceAll("'", "''''");
            wiData = wiData.replaceAll("&", "&amp;");
          
            logger.info("widata: " + wiData);
            
            JSONParser jsonParser = new JSONParser();
            JSONObject json = (JSONObject) jsonParser.parse(wiData);
            JSONObject PayloadTagsObj =null;
            JSONObject metadatTagsObj =null;
            String PROPOSAL_NO="", INPUT_XML="", STATUS="", X_Correlation_ID="",medicalType="";
            String X_App_ID="";
            
            if(json.containsKey("metadata")) {
            	logger.info("into if for metadata");
				metadatTagsObj = (JSONObject) jsonParser.parse(json.get("metadata").toString());
		    
             X_Correlation_ID = (String)metadatTagsObj.getOrDefault("X-Correlation-ID","");
             X_App_ID = (String)metadatTagsObj.getOrDefault("X-App-ID","");
            
            }
            
            if (json.containsKey("payload")) {
            	logger.info("into if for payload");
        		PayloadTagsObj = (JSONObject) jsonParser.parse(json.get("payload").toString());
        			
        		PROPOSAL_NO = (String)PayloadTagsObj.getOrDefault("PolicyNo","");
        		STATUS = (String)PayloadTagsObj.getOrDefault("Status","");
        		medicalType = (String)PayloadTagsObj.getOrDefault("medicalType","");	// by mansi DR-51306
        		
        		logger.info("PROPOSAL_NO: " + PROPOSAL_NO);
        		logger.info("INPUT_XML: " + INPUT_XML);
        		logger.info("OUTPUT: " + wiData);
        		logger.info("STATUS: " + STATUS);
        		logger.info("medicalType: " + medicalType);
        		
        		query = "EXEC NG_SP_NB_NPS_PROC '" + PROPOSAL_NO + "' , '" +STATUS+"' , '"+medicalType+"'";
                
        		logger.info("query: " + query);
        		
        		 String inputXML = XMLGen.APSelectWithColumnNames(cabinetName, query, sessionId);
                 logger.info("inputXML:" + inputXML);
                 String outputXML = CommonFunctions.callRestAPI_JTS(inputXML);
                 logger.info("outputXML:" + outputXML);
     			
                 String Response = outputXML.substring(outputXML.indexOf("<MainCode>")+10, outputXML.indexOf("</MainCode>"));
     			JSONObject resultObj = new JSONObject();
     			
     			JSONObject metadataObj = new JSONObject();
     		    JSONObject msgInfoObj = new JSONObject();
     			JSONObject payloadObj = new JSONObject();
     			
     			if(Response.equals("0")){
     				
     		        metadataObj.put("X-Correlation-ID", X_Correlation_ID);
     		        metadataObj.put("X-App-ID", X_App_ID);
     		       
     		       
     		        msgInfoObj.put("Status" ,"Success");
     		        
     		       
     		        resultObj.put("metadata", metadataObj);
     		        resultObj.put("msgInfo", msgInfoObj);
     		        
     			Result=resultObj.toJSONString();
     			}else {
     			    metadataObj.put("X-Correlation-ID", X_Correlation_ID);
     		        metadataObj.put("X-App-ID", X_App_ID);
     		       
     		        msgInfoObj.put("Status" ,"Failure");
     		        
     		     
     		        resultObj.put("metadata", metadataObj);
     		        resultObj.put("msgInfo", msgInfoObj);
     		        
     			Result=resultObj.toJSONString();
     			}
            }
        		
		}catch(Exception e) {
			
		}
		
		return Result;
	}
	  public JSONObject createErrorJson(String msgCode, String msg) {
	        JSONObject error = new JSONObject();
	        error.put("msgCode", msgCode);
	        error.put("msg", msg);
	        return error;
	    }
}
