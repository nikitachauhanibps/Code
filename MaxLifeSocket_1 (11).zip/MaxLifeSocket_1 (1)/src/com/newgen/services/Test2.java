package com.newgen.services;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.util.HashMap;
import java.util.Properties;

import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.newgen.gui.Server;

public class Test2 {
	public static Properties propertiesFileData;
	public static String token;
	static Logger logger = Logger.getLogger("Test2");
public static void main(String[] args) {
	String input="{\"metadata\":{\"X-App-ID\":\"IBPS\",\"X-Correlation-ID\":\"31873127329799381273192\"},\"payload\":{\"agentId\":\"100766\",\"genderOfPayer\":\"F\",\"policyTerm\":\"10\",\"coverMultiple\":\"10\",\"committedPremium\":\"200000.0\",\"isSurrenderRequired\":\"No\",\"channel\":\"A\",\"emrRate\":\"\",\"flatExtraBaseDuration\":\"\",\"productName\":\"Max Life Fast Track Super Plan\",\"isLIEqualsPH\":\"N\",\"growthFund\":\"\",\"policyHolderStateName\":\"DELHI\",\"secureFund\":\"\",\"ageOfPayer\":\"\",\"ageOfInsured\":\"30\",\"channelId\":\"9094\",\"surrenderOptionAmountArray\":[],\"growthSuperFund\":\"100\",\"maxLifeRegisteredStateName\":\"HARYANA\",\"isNri\":\"No\",\"premiumPayingTerm\":\"5\",\"highGrowthFund\":\"\",\"emrDuration\":\"\",\"dfaOption\":\"No\",\"stpOption\":\"No\",\"emrRequired\":\"No\",\"nameOfPayer\":\"Hkjhkjhk\",\"productCode\":\"34\",\"genderOfInsured\":\"M\",\"balancedFund\":\"\",\"productGroup\":\"ULIP\",\"objectiveOfInsurance\":\"IP\",\"flatExtraBaseRate\":\"\",\"flatExtraBaseRequired\":\"No\",\"nameOfInsured\":\"WWW\",\"paymentModeName\":\"12\",\"conservativeFund\":\"\"}}##LEDoc##Calculate##FTSP";
	try {
		//Validate PAN DOB
		//to be uncomment later
		//String token = generateToken();
		
		//propertiesFileData = new Properties();
//		props = new Properties();
		
		//configPath = System.getProperty("user.dir") + File.separator + "SocketProperties.properties";
        //FileReader reader = new FileReader(configPath);
        //propertiesFileData.load(reader);	        
        
		//String token=propertiesFileData.getProperty("token");
		
	
			propertiesFileData = new Properties();
			Properties props = new Properties();
			
			String configPath = System.getProperty("user.dir") + File.separator + "log4j.properties";
			try {
				props.load(new FileInputStream(configPath));
			} catch (FileNotFoundException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			PropertyConfigurator.configure(props);		
			
			configPath = System.getProperty("user.dir") + File.separator + "SocketProperties.properties";
	        FileReader reader = null;
			try {
				reader = new FileReader(configPath);
			} catch (FileNotFoundException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
	        
	         logger.info("configPath: "+configPath);
	        
	        propertiesFileData = new Properties();
			try {
				propertiesFileData.load(reader);
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}		 
			
		String token = generateToken();
		logger.info("token: "+token);
		String ClientMessage="";
		
		
		String[] clientMessageArr = ClientMessage.split("##");
		
		
		
			
						
			if(clientMessageArr[1].equalsIgnoreCase("LEDoc")){
				String data = clientMessageArr[0];
				String planCode=clientMessageArr[3];
				String returnData="";

				if(planCode.equalsIgnoreCase("LPPS")) {
					returnData = LE_LPPS_Gen_Cal.generateDOC(token,data,clientMessageArr[2],planCode); 
				}
				else						
				if(planCode.equalsIgnoreCase("AWP")) {
					returnData = LE_GenerateDocument.generateDOC(token,data,clientMessageArr[2],planCode);     
				}
				else
					if(planCode.equalsIgnoreCase("FTSP")) {
						returnData = LE_FTSP_Gen_Cal.generateDOC(token,data,clientMessageArr[2],planCode);
					}
					else
						if(planCode.equalsIgnoreCase("PWP")) {
							returnData = LE_PWP_Gen_Cal.generateDOC(token,data,clientMessageArr[2],planCode);
						}
						else
							if(planCode.equalsIgnoreCase("FYPP")) {
								returnData = LE_FYPP_Gen_Cal.generateDOC(token,data,clientMessageArr[2],planCode);
							}
							else
								if(planCode.equalsIgnoreCase("SPS")) {
									returnData = LE_SPS_Gen_Cal.generateDOC(token,data,clientMessageArr[2],planCode);
								}
								else
									if(planCode.equalsIgnoreCase("OSP")) {
										returnData = LE_OSP_Gen_Cal.generateDOC(token,data,clientMessageArr[2],planCode);
									}
									else
										if(planCode.equalsIgnoreCase("MIAP")) {
											returnData = LE_MIAP_Gen_Cal.generateDOC(token,data,clientMessageArr[2],planCode);
										}
										else
											if(planCode.equalsIgnoreCase("WLS")) {
												returnData = LE_WLS_Gen_Cal.generateDOC(token,data,clientMessageArr[2],planCode);
											}
											else
												if(planCode.equalsIgnoreCase("GIP"))
													returnData = LE_GIP_Gen_Cal.generateDOC(token,data,clientMessageArr[2],planCode);
												else
													if(planCode.equalsIgnoreCase("FGEP"))
														returnData = LE_FGEP_Gen_Cal.generateDOC(token,data,clientMessageArr[2],planCode);
													else
														if(planCode.equalsIgnoreCase("FWP"))
															returnData = LE_FWP_Gen_Cal.generateDOC(token,data,clientMessageArr[2],planCode);
														else
															if(planCode.equalsIgnoreCase("STP"))
																returnData = LE_STP_Gen_Cal.generateDOC(token,data,clientMessageArr[2],planCode);
	            
			}}
			catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
			}
}

private static String callAPI(String url, String string, HashMap<String, String> hm) {
	// TODO Auto-generated method stub
		String postEndpoint = url;
		CloseableHttpClient httpclient = HttpClients.createDefault();
		HttpPost httpPost = new HttpPost(postEndpoint);
		
		for (String i : hm.keySet()) {
			httpPost.setHeader(i, hm.get(i)); // set userId
																// its a
																// sample
																// here
		}
		
		String inputJson = "{\"metadata\":{\r\n" + 
				"  \"X-App-ID\":\"IBPS\",                  \r\n" + 
				"  \"X-Correlation-ID\":\"31873127329799381273192\"\r\n" + 
				"},\"payload\":{\r\n" + 
				"  \"username\":\""+Server.propertiesFileData.getProperty("username")+"\",                           \r\n" + 
				"  \"password\": \""+Server.propertiesFileData.getProperty("password")+"\"}}";
		
		StringEntity stringEntity;
		StringBuffer result = new StringBuffer();
		try {
			stringEntity = new StringEntity(inputJson);
			httpPost.setEntity(stringEntity);
			System.out.println("Executing request " + httpPost.getRequestLine());

			HttpResponse response = httpclient.execute(httpPost);

			BufferedReader br = new BufferedReader(
					new InputStreamReader((response.getEntity().getContent())));


			//Throw runtime exception if status code isn't 200
			if (response.getStatusLine().getStatusCode() != 200) {
				throw new RuntimeException("Failed : HTTP error code : "
						+ response.getStatusLine().getStatusCode());
			}


			//Create the StringBuffer object and store the response into it.
			
			String line = "";
			while ((line = br.readLine()) != null) {
			result.append(line);
			}


			//Lets validate if a text 'employee_salary' is present in the response 
			//System.out.println( result.toString());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	return result.toString();
}


private static String generateToken() throws ParseException {
	String token="";
	
	HashMap<String, String> hm = new HashMap<>();
	//hm.put("accept", "application/json");
	//hm.put("Authorization", propertiesFileData.getProperty("TokenAuthorization"));
	//         hm.put("Content-Type", "application/json");
	//         hm.put("x-client-id", "53jt873l753mcudrhqmuh3g5u8");
	//         hm.put("x-api-key", "DTUDHv9UVG8cVT3qmhiSv1UcnvCduzLf1CI6zCVY");
     
    //for SIT
	
	hm.put("Content-Type", "application/json");        
	hm.put("x-api-key", Server.propertiesFileData.getProperty("ApiKey"));        
	hm.put("cache-control", "no-cache");
	hm.put("host", Server.propertiesFileData.getProperty("Host"));
	hm.put("x-client-id", Server.propertiesFileData.getProperty("x-client-id"));
	hm.put("user-pool-id", Server.propertiesFileData.getProperty("user-pool-id"));
	
	String url=Server.propertiesFileData.getProperty("auth_url");
	
	String jsonString = callAPI(url, "POST", hm);
	logger.info("jsonString: "+jsonString);
	Object obj = null,tokenObj=null;
	try {
		obj = new JSONParser().parse(jsonString);
	} catch (ParseException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
    JSONObject jo = (JSONObject) obj;
    //String payload = (String) jo.get("payload").toString();
    
    tokenObj = new JSONParser().parse(jo.get("payload").toString());
    JSONObject joToken = (JSONObject) tokenObj;
    token = (String) joToken.get("token").toString();
	logger.info("token generated: "+token);
	return token;
}



}
